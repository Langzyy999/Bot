global.prefa = ['','!','.',',','🐤','🗿']

global.owner = ['6285700483489']
global.namaowner = ['Lanz']
global.botname = 'Lanz-Bot'
global.baileys1 = require('@whiskeysockets/baileys') 
global.sticker1 = "Bot Gacor"
global.sticker2 = "🌜"
global.adana = '6283149155870'
global.aqris = 'https://telegra.ph/file/4a91a47bd04a409454aa0.jpg   '
global.aovo = 'gada'
global.agopay = 'gada'