module.exports = {
    apiId: 38615348,
    apiHash: "c26b6e06220d986e3148c1ac74904596",
    sessionFile: "session.json"
};
