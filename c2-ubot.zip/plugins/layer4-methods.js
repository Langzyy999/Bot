const os = require("os");
const { formatSize } = require("../utils/fungsion");
const { performance } = require("perf_hooks");

const totalMem = os.totalmem();
const freeMem = os.freemem();
const usedMem = totalMem - freeMem;
const formattedUsedMem = formatSize(usedMem);
const formattedTotalMem = formatSize(totalMem);

function formatRuntime(ms) {
  let seconds = Math.floor(ms / 1000) % 60;
  let minutes = Math.floor(ms / (1000 * 60)) % 60;
  let hours = Math.floor(ms / (1000 * 60 * 60)) % 24;
  let days = Math.floor(ms / (1000 * 60 * 60 * 24));
  return `${days}d ${hours}h ${minutes}m ${seconds}s`;
}

let botStartTime = performance.now();

// ID kamu
const allowedId = [6044526334];

module.exports = {
  command: ["layer4-methods"],
  run: async ({ client, message, reply }) => {
    if (parseInt(message.senderId) !== allowedId) return;

    const user = await client.getEntity(message.senderId);
    const username = user.username ? `@${user.username}` : "";
    const fullName = user.firstName + (user.lastName ? ` ${user.lastName}` : "");
    const mention = username || fullName;
    const userId = user.id;
    const runtime = formatRuntime(performance.now() - botStartTime);

    const caption = `<blockquote>
┏━━ ( Informations ) ━━⭓
┃  𝐃𝐞𝐯𝐞𝐥𝐨𝐩𝐞𝐝 : @XinyouXD
┃  𝐍𝐚𝐦𝐞 : XinL7
┃  𝐔𝐬𝐞𝐫 : ${mention}
┃  𝐕𝐞𝐫𝐬𝐢𝐨𝐧 : VIP
┃  𝐑𝐮𝐧𝐓𝐢𝐦𝐞 : ${runtime}
┗━━━━━━━━━━━━━⭓
┏━ 【 Layer4 Methods🕊】 ━━⊱
┃⭓ kill-tcp
┃⭓ kill-udp
┃⭓ kill-icmp
┃⭓ kill-dns
┗━━━━━━━━⊱ 
</blockquote>`;

    await client.sendFile(message.chatId, {
      file: "https://files.catbox.moe/l138g9.mp4",
      caption: caption,
      parseMode: "html",
      replyTo: message.id,
    });
  },
};